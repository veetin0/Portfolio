//
//  Models.swift
//  Command Center
//
//  All persisted data models. Everything is Codable and value-typed so the
//  whole configuration serialises to a single JSON document.
//

import Foundation
import SwiftUI

// MARK: - Action types

/// Every kind of action a tile can trigger.
///
/// Extensibility: adding a new action type means
///   1. adding a case here,
///   2. writing an `ActionExecutor` for it (see Core/Executors.swift),
///   3. registering it in `ActionRegistry.registerBuiltIns()`.
/// Nothing else in the app needs to change.
enum ActionType: String, Codable, CaseIterable, Identifiable {
    case launchApp      // Open an application by path or bundle id
    case shellCommand   // Run a shell command (zsh)
    case openPath       // Reveal / open a file or folder
    case appleScript    // Execute an AppleScript source string
    case openURL        // Open a URL (web, custom schemes, GitHub repos…)
    case workflow       // Ordered list of other actions
    case newsSummary

    var id: String { rawValue }

    var displayName: String {
        switch self {
        case .launchApp:    return "Launch App"
        case .shellCommand: return "Shell Command"
        case .openPath:     return "Open File / Folder"
        case .appleScript:  return "AppleScript"
        case .openURL:      return "Open URL"
        case .workflow:     return "Workflow"
        case .newsSummary:  return "News Summary"
        }
    }

    var symbol: String {
        switch self {
        case .launchApp:    return "app.badge"
        case .shellCommand: return "terminal"
        case .openPath:     return "folder"
        case .appleScript:  return "applescript"
        case .openURL:      return "link"
        case .workflow:     return "arrow.triangle.branch"
        case .newsSummary:  return "newspaper"
        }
    }
}

/// A single executable action. `payload` is interpreted by the executor for
/// the given `type`:
///   launchApp    → app path ("/Applications/Visual Studio Code.app") or bundle id
///   shellCommand → the command string
///   openPath     → absolute path
///   appleScript  → script source
///   openURL      → URL string
///   workflow     → uses `steps`, payload ignored
struct TileAction: Codable, Hashable, Identifiable {
    var id = UUID()
    var type: ActionType = .launchApp
    var payload: String = ""
    /// For `.workflow`: sub-actions executed sequentially.
    var steps: [TileAction] = []
    /// Extra key/value options an executor may use (e.g. "arguments",
    /// "workingDirectory", "runInTerminal"). Keeps the model open-ended
    /// for future plugins without schema changes.
    var options: [String: String] = [:]
}

// MARK: - Keyboard shortcuts

/// A user-recordable keyboard shortcut, stored as Carbon key code + modifier
/// flags so it can be registered as a system-wide hotkey.
struct KeyShortcut: Codable, Hashable {
    var keyCode: UInt32          // Carbon virtual key code
    var modifiers: UInt32        // Carbon modifier mask (cmdKey, optionKey…)
    var display: String          // Human readable, e.g. "⌘⇧K"
}

// MARK: - Tiles, pages, profiles

/// A dashboard button.
struct Tile: Codable, Hashable, Identifiable {
    var id = UUID()
    var label: String = "New Tile"
    /// SF Symbol name, or absolute image path when `iconIsImage == true`.
    var icon: String = "bolt.fill"
    var iconIsImage: Bool = false
    /// Accent color stored as hex so the model stays Codable.
    var colorHex: String = "#4F8EF7"
    var action: TileAction = TileAction()
    var shortcut: KeyShortcut? = nil

    var color: Color { Color(hex: colorHex) ?? .accentColor }
}

/// A page (a.k.a. category) of tiles inside a profile.
struct Page: Codable, Hashable, Identifiable {
    var id = UUID()
    var name: String = "Page"
    var symbol: String = "square.grid.2x2"
    var tiles: [Tile] = []
}

/// A profile is a full workspace ("Work", "Personal"…), each with its own pages.
struct Profile: Codable, Hashable, Identifiable {
    var id = UUID()
    var name: String = "Default"
    var symbol: String = "person.crop.circle"
    var pages: [Page] = [Page(name: "Main")]
}

// MARK: - Root configuration

/// Root persisted object.
struct AppConfig: Codable {
    var profiles: [Profile] = [Profile()]
    var activeProfileID: UUID?
    var summonShortcut: KeyShortcut? = KeyShortcut.defaultSummon
    var showSystemPanel: Bool = true
    var tileSize: Double = 110
    var feedbackEnabled: Bool = true

    init() {}

    /// Tolerant decoding: every field falls back to its default when the
    /// key is missing, so configs saved by older versions of the app keep
    /// loading after new settings are added (instead of failing and
    /// wiping the user's layout).
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        profiles = try container.decodeIfPresent([Profile].self, forKey: .profiles)
            ?? [Profile()]
        activeProfileID = try container.decodeIfPresent(UUID.self, forKey: .activeProfileID)
        summonShortcut = try container.decodeIfPresent(KeyShortcut.self, forKey: .summonShortcut)
            ?? KeyShortcut.defaultSummon
        showSystemPanel = try container.decodeIfPresent(Bool.self, forKey: .showSystemPanel)
            ?? true
        tileSize = try container.decodeIfPresent(Double.self, forKey: .tileSize) ?? 110
        feedbackEnabled = try container.decodeIfPresent(Bool.self, forKey: .feedbackEnabled)
            ?? true
    }

    static func makeDefault() -> AppConfig {
        var config = AppConfig()
        config.profiles = [Profile.sampleWork(), Profile.samplePersonal()]
        config.activeProfileID = config.profiles.first?.id
        return config
    }
}

extension KeyShortcut {
    /// ⌥Space — chosen because ⌘Space is owned by Spotlight by default.
    static let defaultSummon = KeyShortcut(keyCode: 49, modifiers: 2048, display: "⌥Space")
}

// MARK: - Color helpers

extension Color {
    /// Init from "#RRGGBB" / "RRGGBB".
    init?(hex: String) {
        var value = hex.trimmingCharacters(in: .whitespaces)
        if value.hasPrefix("#") { value.removeFirst() }
        guard value.count == 6, let rgb = UInt64(value, radix: 16) else { return nil }
        self.init(
            red: Double((rgb >> 16) & 0xFF) / 255,
            green: Double((rgb >> 8) & 0xFF) / 255,
            blue: Double(rgb & 0xFF) / 255
        )
    }
}
