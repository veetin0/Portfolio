//
//  SampleData.swift
//  Command Center
//
//  Example profiles/tiles created on first launch, including the
//  "Code Setup" workflow described in the product brief.
//

import Foundation

extension Profile {

    static func sampleWork() -> Profile {
        var profile = Profile(name: "Work", symbol: "briefcase.fill")

        // "Code Setup":
        //   1. Open Visual Studio Code
        //   2. Create a fresh scratch file with template code
        //   3. Open that file in VS Code
        let template = """
        //
        //  scratch.swift — created by Command Center
        //
        import Foundation

        print("Hello from Command Center 👋")
        """
        let codeSetup = Tile(
            label: "Code Setup",
            icon: "chevron.left.forwardslash.chevron.right",
            colorHex: "#3B82F6",
            action: TileAction(
                type: .workflow,
                steps: [
                    TileAction(type: .launchApp,
                               payload: "/Applications/Visual Studio Code.app"),
                    TileAction(type: .shellCommand,
                               payload: #"mkdir -p ~/Scratch && printf '%s\n' "$CC_TEMPLATE" > ~/Scratch/scratch.swift"#,
                               options: ["env:CC_TEMPLATE": template]),
                    TileAction(type: .shellCommand,
                               payload: #"open -a "Visual Studio Code" ~/Scratch/scratch.swift"#)
                ]
            )
        )

        let terminal = Tile(
            label: "Terminal",
            icon: "terminal.fill",
            colorHex: "#111827",
            action: TileAction(type: .launchApp, payload: "/System/Applications/Utilities/Terminal.app")
        )

        let gitStatus = Tile(
            label: "Repo Status",
            icon: "arrow.triangle.pull",
            colorHex: "#F59E0B",
            action: TileAction(type: .shellCommand,
                               payload: "cd ~/Projects && git status",
                               options: ["runInTerminal": "true"])
        )

        let github = Tile(
            label: "GitHub PRs",
            icon: "tray.full.fill",
            colorHex: "#8B5CF6",
            action: TileAction(type: .openURL, payload: "https://github.com/pulls")
        )

        let projects = Tile(
            label: "Projects",
            icon: "folder.fill",
            colorHex: "#10B981",
            action: TileAction(type: .openPath, payload: "~/Projects")
        )

        let standup = Tile(
            label: "Focus Mode",
            icon: "moon.fill",
            colorHex: "#6366F1",
            action: TileAction(
                type: .appleScript,
                payload: #"display notification "Notifications muted — deep work time." with title "Command Center""#
            )
        )

        profile.pages = [
            Page(name: "Dev", symbol: "hammer.fill",
                 tiles: [codeSetup, terminal, gitStatus, projects]),
            Page(name: "Web", symbol: "globe",
                 tiles: [github, standup])
        ]
        return profile
    }

    static func samplePersonal() -> Profile {
        var profile = Profile(name: "Personal", symbol: "house.fill")
        profile.pages = [
            Page(name: "Main", symbol: "square.grid.2x2", tiles: [
                Tile(label: "Music",
                     icon: "music.note",
                     colorHex: "#EF4444",
                     action: TileAction(type: .launchApp, payload: "/System/Applications/Music.app")),
                Tile(label: "Downloads",
                     icon: "arrow.down.circle.fill",
                     colorHex: "#0EA5E9",
                     action: TileAction(type: .openPath, payload: "~/Downloads")),
                Tile(label: "Screenshot",
                     icon: "camera.viewfinder",
                     colorHex: "#64748B",
                     action: TileAction(type: .shellCommand,
                                        payload: "screencapture -i ~/Desktop/cc-shot-$(date +%s).png"))
            ])
        ]
        return profile
    }
}
