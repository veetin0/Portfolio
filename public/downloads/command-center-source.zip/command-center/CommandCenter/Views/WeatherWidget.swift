//
//  WeatherWidget.swift
//  Command Center
//
//  Compact weather cards for the cities configured in WeatherService
//  (Tampere & Vaasa by default). Lives in the system panel; owns its own
//  service instance since weather is independent of the rest of the app.
//

import SwiftUI

struct WeatherWidget: View {
    @StateObject private var service = WeatherService()

    var body: some View {
        VStack(spacing: 10) {
            if service.reports.isEmpty {
                placeholder
            } else {
                ForEach(service.reports) { report in
                    WeatherCard(report: report)
                }
            }
        }
        .contextMenu {
            Button("Refresh Now") {
                Task { await service.refresh() }
            }
        }
    }

    @ViewBuilder
    private var placeholder: some View {
        HStack(spacing: 8) {
            if let error = service.lastError {
                Image(systemName: "cloud.slash")
                    .foregroundStyle(.secondary)
                Text(error)
                    .font(.caption)
                    .foregroundStyle(.secondary)
            } else {
                ProgressView()
                    .controlSize(.small)
                Text("Loading weather…")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            Spacer()
        }
        .padding(12)
        .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 12))
    }
}

private struct WeatherCard: View {
    let report: CityWeather

    var body: some View {
        HStack(spacing: 10) {
            Image(systemName: report.symbol)
                .font(.system(size: 22))
                .symbolRenderingMode(.multicolor)
                .frame(width: 30)

            VStack(alignment: .leading, spacing: 2) {
                Text(report.city)
                    .font(.system(size: 13, weight: .semibold))
                Text(report.summary)
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            Spacer()

            VStack(alignment: .trailing, spacing: 2) {
                Text(String(format: "%.0f°", report.temperature))
                    .font(.system(size: 18, weight: .semibold, design: .rounded))
                    .contentTransition(.numericText())
                Label(String(format: "%.0f km/h", report.windSpeed),
                      systemImage: "wind")
                    .font(.system(size: 9))
                    .foregroundStyle(.secondary)
            }
        }
        .padding(12)
        .frame(maxWidth: .infinity)
        .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 12))
    }
}
