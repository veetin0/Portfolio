//
//  DashboardView.swift
//  Command Center
//
//  The main window: sidebar of profiles/pages, a Spotlight-style search bar,
//  the tile grid, and the live system panel on the trailing edge.
//

import SwiftUI

struct DashboardView: View {
    @EnvironmentObject private var viewModel: AppViewModel
    @State private var isAddingPage = false
    @State private var newPageName = ""
    @State private var showActivityLog = false

    var body: some View {
        NavigationSplitView {
            sidebar
        } detail: {
            detail
        }
        .navigationSplitViewStyle(.balanced)
        .background(.ultraThinMaterial)  // frosted, Raycast-like backdrop
        .sheet(item: $viewModel.editingTile) { tile in
            EditTileSheet(tile: tile)
                .environmentObject(viewModel)
        }
        .sheet(item: $viewModel.newsRequest) { request in
            NewsReportView(request: request)
        }
        .overlay(alignment: .bottom) { toastView }
        .alert("New Page", isPresented: $isAddingPage) {
            TextField("Name", text: $newPageName)
            Button("Add") {
                viewModel.addPage(named: newPageName.isEmpty ? "Page" : newPageName)
                newPageName = ""
            }
            Button("Cancel", role: .cancel) { newPageName = "" }
        }
    }

    // MARK: Sidebar

    private var sidebar: some View {
        List(selection: $viewModel.selectedPageID) {
            Section("Profile") {
                Picker("Profile", selection: Binding(
                    get: { viewModel.activeProfile.id },
                    set: { viewModel.selectProfile($0) }
                )) {
                    ForEach(viewModel.config.profiles) { profile in
                        Label(profile.name, systemImage: profile.symbol)
                            .tag(profile.id)
                    }
                }
                .pickerStyle(.inline)
                .labelsHidden()
            }

            Section("Pages") {
                ForEach(viewModel.activeProfile.pages) { page in
                    Label(page.name, systemImage: page.symbol)
                        .tag(page.id)
                        .contextMenu {
                            Button("Delete Page", role: .destructive) {
                                viewModel.deletePage(page.id)
                            }
                        }
                }
                Button {
                    isAddingPage = true
                } label: {
                    Label("Add Page", systemImage: "plus")
                        .foregroundStyle(.secondary)
                }
                .buttonStyle(.plain)
            }
        }
        .listStyle(.sidebar)
        .safeAreaInset(edge: .bottom, spacing: 0) {
            SystemControlsView()
        }
        .navigationSplitViewColumnWidth(min: 180, ideal: 200)
    }

    // MARK: Detail

    private var detail: some View {
        HStack(alignment: .top, spacing: 0) {
            VStack(spacing: 0) {
                SearchBarView(engine: viewModel.searchEngine)
                    .padding(.horizontal, 20)
                    .padding(.top, 16)

                TileGridView()
                    .padding(20)

                NowPlayingWidget()
                    .padding(.horizontal, 20)
                    .padding(.bottom, 14)
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .top)

            if viewModel.config.showSystemPanel {
                Divider()
                SystemInfoPanel()
                    .frame(width: 230)
                    .transition(.move(edge: .trailing).combined(with: .opacity))
            }
        }
        .animation(.easeInOut(duration: 0.2), value: viewModel.config.showSystemPanel)
        .toolbar {
            ToolbarItemGroup(placement: .primaryAction) {
                Button {
                    showActivityLog.toggle()
                } label: {
                    Label("Activity", systemImage: "clock.arrow.circlepath")
                }
                .help("Recent activity")
                .popover(isPresented: $showActivityLog, arrowEdge: .bottom) {
                    ActivityLogView()
                        .environmentObject(viewModel)
                }

                Button {
                    viewModel.beginAddingTile()
                } label: {
                    Label("New Tile", systemImage: "plus")
                }
                .help("Add a tile (⌘N)")

                Button {
                    viewModel.config.showSystemPanel.toggle()
                } label: {
                    Label("System Panel", systemImage: "gauge.medium")
                }
                .help("Toggle system panel")
            }
        }
    }

    // MARK: Toast

    @ViewBuilder
    private var toastView: some View {
        if let toast = viewModel.toast {
            HStack(spacing: 8) {
                Image(systemName: toast.isError
                      ? "exclamationmark.triangle.fill"
                      : "checkmark.circle.fill")
                    .foregroundStyle(toast.isError ? .yellow : .green)
                Text(toast.message)
                    .font(.callout)
                    .lineLimit(2)
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 10)
            .background(.regularMaterial, in: Capsule())
            .shadow(radius: 8, y: 4)
            .padding(.bottom, 20)
            .transition(.move(edge: .bottom).combined(with: .opacity))
        }
    }
}
