//
//  EditTileSheet.swift
//  Command Center
//
//  Sheet for creating/editing a tile: label, SF Symbol or image icon,
//  accent color, action configuration (incl. multi-step workflows) and a
//  live shortcut recorder.
//

import SwiftUI
import AppKit

struct EditTileSheet: View {
    @EnvironmentObject private var viewModel: AppViewModel
    @Environment(\.dismiss) private var dismiss

    @State var tile: Tile
    @State private var isRecordingShortcut = false

    private let suggestedSymbols = [
        "bolt.fill", "terminal.fill", "folder.fill", "globe", "hammer.fill",
        "chevron.left.forwardslash.chevron.right", "music.note", "envelope.fill",
        "calendar", "camera.viewfinder", "gearshape.fill", "book.fill",
        "paintbrush.fill", "tray.full.fill", "arrow.triangle.branch", "star.fill"
    ]
    private let suggestedColors = [
        "#3B82F6", "#8B5CF6", "#EF4444", "#F59E0B",
        "#10B981", "#0EA5E9", "#6366F1", "#64748B", "#111827"
    ]

    var body: some View {
        VStack(spacing: 0) {
            header

            Form {
                identitySection
                actionSection
                shortcutSection
            }
            .formStyle(.grouped)

            footer
        }
        .frame(width: 480, height: 620)
        .background(ShortcutRecorder(isRecording: $isRecordingShortcut) { shortcut in
            tile.shortcut = shortcut
        })
    }

    // MARK: Sections

    private var header: some View {
        HStack {
            // Live preview of the tile as configured.
            TilePreview(tile: tile)
            VStack(alignment: .leading) {
                Text(viewModel.isAddingTile ? "New Tile" : "Edit Tile")
                    .font(.title2.bold())
                Text(tile.action.type.displayName)
                    .foregroundStyle(.secondary)
            }
            Spacer()
        }
        .padding(20)
    }

    private var identitySection: some View {
        Section("Appearance") {
            TextField("Label", text: $tile.label)

            Picker("Icon type", selection: $tile.iconIsImage) {
                Text("SF Symbol").tag(false)
                Text("Image file").tag(true)
            }
            .pickerStyle(.segmented)

            if tile.iconIsImage {
                HStack {
                    TextField("Image path", text: $tile.icon)
                    Button("Choose…") { chooseImage() }
                }
            } else {
                TextField("SF Symbol name", text: $tile.icon)
                symbolPalette
            }

            colorPalette
        }
    }

    private var symbolPalette: some View {
        LazyVGrid(columns: [GridItem(.adaptive(minimum: 34))], spacing: 6) {
            ForEach(suggestedSymbols, id: \.self) { symbol in
                Button {
                    tile.icon = symbol
                } label: {
                    Image(systemName: symbol)
                        .frame(width: 30, height: 30)
                        .background(
                            RoundedRectangle(cornerRadius: 7)
                                .fill(tile.icon == symbol
                                      ? Color.accentColor.opacity(0.25)
                                      : Color.primary.opacity(0.05)))
                }
                .buttonStyle(.plain)
            }
        }
    }

    private var colorPalette: some View {
        HStack(spacing: 8) {
            ForEach(suggestedColors, id: \.self) { hex in
                Button {
                    tile.colorHex = hex
                } label: {
                    Circle()
                        .fill(Color(hex: hex) ?? .gray)
                        .frame(width: 22, height: 22)
                        .overlay(
                            Circle().strokeBorder(.white,
                                lineWidth: tile.colorHex == hex ? 2 : 0))
                        .shadow(radius: 1)
                }
                .buttonStyle(.plain)
            }
        }
    }

    private var actionSection: some View {
        Section("Action") {
            Picker("Type", selection: $tile.action.type) {
                ForEach(ActionType.allCases) { type in
                    Label(type.displayName, systemImage: type.symbol).tag(type)
                }
            }

            if tile.action.type == .workflow {
                workflowEditor
            } else {
                payloadField(for: $tile.action, type: tile.action.type)
            }

            if tile.action.type == .shellCommand {
                Toggle("Run visibly in Terminal", isOn: Binding(
                    get: { tile.action.options["runInTerminal"] == "true" },
                    set: { tile.action.options["runInTerminal"] = $0 ? "true" : nil }
                ))
            }
        }
    }

    /// Editable ordered list of workflow steps.
    private var workflowEditor: some View {
        VStack(alignment: .leading, spacing: 8) {
            ForEach($tile.action.steps) { $step in
                HStack(alignment: .top) {
                    Picker("", selection: $step.type) {
                        ForEach(ActionType.allCases.filter { $0 != .workflow }) { type in
                            Image(systemName: type.symbol).tag(type)
                        }
                    }
                    .labelsHidden()
                    .frame(width: 70)

                    payloadField(for: $step, type: step.type)

                    Button {
                        tile.action.steps.removeAll { $0.id == step.id }
                    } label: {
                        Image(systemName: "minus.circle.fill")
                            .foregroundStyle(.red)
                    }
                    .buttonStyle(.plain)
                }
            }
            Button {
                tile.action.steps.append(TileAction(type: .shellCommand))
            } label: {
                Label("Add Step", systemImage: "plus.circle.fill")
            }
            .buttonStyle(.plain)
        }
    }

    @ViewBuilder
    private func payloadField(for action: Binding<TileAction>, type: ActionType) -> some View {
        switch type {
        case .shellCommand, .appleScript:
            TextEditor(text: action.payload)
                .font(.system(.body, design: .monospaced))
                .frame(minHeight: 60)
                .overlay(RoundedRectangle(cornerRadius: 6)
                    .strokeBorder(.quaternary))
        case .launchApp:
            HStack {
                TextField("App path or bundle id", text: action.payload)
                Button("Choose…") { chooseApp(into: action) }
            }
        case .openPath:
            HStack {
                TextField("File or folder path", text: action.payload)
                Button("Choose…") { choosePath(into: action) }
            }
        case .openURL:
            TextField("URL or owner/repo", text: action.payload)
        case .workflow:
            EmptyView()
            
        case .newsSummary:
            VStack(alignment: .leading, spacing: 6) {
                TextField("RSS feed URLs, comma-separated (empty = Yle, BBC, Guardian)",
                    text: action.payload)
                SecureField("Anthropic API key (optional, enables AI digest)",
                            text: Binding(
                                get: { action.wrappedValue.options["anthropicKey"] ?? ""},
                                set: { action.wrappedValue.options["anthropicKey"] = $0.isEmpty ? nil : $0 }
                            ))
            
            }
            
        }
    }

    private var shortcutSection: some View {
        Section("Global Shortcut") {
            HStack {
                Text(tile.shortcut?.display ?? "None")
                    .font(.system(.body, design: .monospaced))
                    .padding(.horizontal, 10)
                    .padding(.vertical, 4)
                    .background(.quaternary.opacity(0.5),
                                in: RoundedRectangle(cornerRadius: 6))
                Spacer()
                Button(isRecordingShortcut ? "Press keys…" : "Record") {
                    isRecordingShortcut.toggle()
                }
                if tile.shortcut != nil {
                    Button("Clear", role: .destructive) { tile.shortcut = nil }
                }
            }
        }
    }

    private var footer: some View {
        HStack {
            if !viewModel.isAddingTile {
                Button("Delete", role: .destructive) {
                    viewModel.deleteTile(tile.id)
                    dismiss()
                }
            }
            Spacer()
            Button("Cancel") { dismiss() }
                .keyboardShortcut(.cancelAction)
            Button("Save") {
                viewModel.commit(tile)
                dismiss()
            }
            .keyboardShortcut(.defaultAction)
            .buttonStyle(.borderedProminent)
        }
        .padding(20)
    }

    // MARK: File pickers

    private func chooseApp(into action: Binding<TileAction>) {
        let panel = NSOpenPanel()
        panel.allowedContentTypes = [.application]
        panel.directoryURL = URL(fileURLWithPath: "/Applications")
        if panel.runModal() == .OK, let url = panel.url {
            action.wrappedValue.payload = url.path
        }
    }

    private func choosePath(into action: Binding<TileAction>) {
        let panel = NSOpenPanel()
        panel.canChooseDirectories = true
        panel.canChooseFiles = true
        if panel.runModal() == .OK, let url = panel.url {
            action.wrappedValue.payload = url.path
        }
    }

    private func chooseImage() {
        let panel = NSOpenPanel()
        panel.allowedContentTypes = [.image]
        if panel.runModal() == .OK, let url = panel.url {
            tile.icon = url.path
        }
    }
}

// MARK: - Preview thumbnail

private struct TilePreview: View {
    let tile: Tile

    var body: some View {
        VStack(spacing: 4) {
            Group {
                if tile.iconIsImage,
                   let image = NSImage(contentsOfFile: tile.icon.expandingTilde) {
                    Image(nsImage: image).resizable().scaledToFit()
                } else {
                    Image(systemName: tile.icon.isEmpty ? "questionmark" : tile.icon)
                }
            }
            .font(.system(size: 20, weight: .medium))
            .foregroundStyle(.white)
            .frame(height: 26)

            Text(tile.label)
                .font(.system(size: 9, weight: .semibold))
                .foregroundStyle(.white)
                .lineLimit(1)
        }
        .frame(width: 72, height: 72)
        .background(
            RoundedRectangle(cornerRadius: 14)
                .fill(LinearGradient(colors: [tile.color, tile.color.opacity(0.75)],
                                     startPoint: .topLeading,
                                     endPoint: .bottomTrailing)))
    }
}

// MARK: - Shortcut recorder (NSEvent local monitor)

/// Invisible helper that captures the next modifier+key combination while
/// `isRecording` is true.
private struct ShortcutRecorder: NSViewRepresentable {
    @Binding var isRecording: Bool
    var onCapture: (KeyShortcut) -> Void

    func makeNSView(context: Context) -> NSView { NSView() }

    func updateNSView(_ nsView: NSView, context: Context) {
        context.coordinator.setRecording(isRecording)
    }

    func makeCoordinator() -> Coordinator {
        Coordinator(parent: self)
    }

    final class Coordinator {
        private let parent: ShortcutRecorder
        private var monitor: Any?

        init(parent: ShortcutRecorder) { self.parent = parent }

        func setRecording(_ recording: Bool) {
            if recording, monitor == nil {
                monitor = NSEvent.addLocalMonitorForEvents(matching: .keyDown) { [weak self] event in
                    guard let self else { return event }
                    if let shortcut = KeyShortcut.from(event: event) {
                        DispatchQueue.main.async {
                            self.parent.onCapture(shortcut)
                            self.parent.isRecording = false
                        }
                        return nil // swallow the event
                    }
                    return event
                }
            } else if !recording, let monitor {
                NSEvent.removeMonitor(monitor)
                self.monitor = nil
            }
        }

        deinit {
            if let monitor { NSEvent.removeMonitor(monitor) }
        }
    }
}
