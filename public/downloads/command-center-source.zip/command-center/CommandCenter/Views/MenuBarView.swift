//
//  MenuBarView.swift
//  Command Center
//
//  Compact popover shown from the menu-bar icon: mini system stats,
//  the first tiles of the active page as quick actions, and a shortcut
//  to open the full dashboard.
//

import SwiftUI

struct MenuBarView: View {
    @EnvironmentObject private var viewModel: AppViewModel
    @Environment(\.openWindow) private var openWindow

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            MenuBarStats(monitor: viewModel.systemMonitor)

            Divider()

            // Quick actions — first 6 tiles of the current page.
            let tiles = Array((viewModel.selectedPage?.tiles ?? []).prefix(6))
            if tiles.isEmpty {
                Text("No tiles yet")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            } else {
                LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 8),
                                         count: 3),
                          spacing: 8) {
                    ForEach(tiles) { tile in
                        Button {
                            viewModel.run(tile)
                        } label: {
                            VStack(spacing: 4) {
                                Image(systemName: tile.iconIsImage ? "bolt.fill" : tile.icon)
                                    .font(.system(size: 16, weight: .medium))
                                    .foregroundStyle(.white)
                                Text(tile.label)
                                    .font(.system(size: 9, weight: .semibold))
                                    .foregroundStyle(.white)
                                    .lineLimit(1)
                            }
                            .frame(maxWidth: .infinity)
                            .frame(height: 54)
                            .background(
                                RoundedRectangle(cornerRadius: 10)
                                    .fill(tile.color.gradient))
                        }
                        .buttonStyle(.plain)
                    }
                }
            }

            Divider()

            HStack {
                Button("Open Command Center") {
                    openWindow(id: "main")
                    NSApp.activate(ignoringOtherApps: true)
                }
                Spacer()
                Button("Quit") { NSApp.terminate(nil) }
                    .foregroundStyle(.secondary)
            }
            .buttonStyle(.plain)
            .font(.caption)
        }
        .padding(14)
        .frame(width: 280)
    }
}

/// Tiny always-visible stats strip.
private struct MenuBarStats: View {
    @ObservedObject var monitor: SystemMonitor

    var body: some View {
        HStack(spacing: 14) {
            stat(symbol: "cpu",
                 text: String(format: "%.0f%%", monitor.cpuUsage * 100))
            stat(symbol: "memorychip",
                 text: ByteCountFormatter.string(
                    fromByteCount: Int64(monitor.memoryUsedBytes),
                    countStyle: .memory))
            if let battery = monitor.batteryPercent {
                stat(symbol: monitor.isCharging ? "battery.100.bolt" : "battery.75",
                     text: "\(battery)%")
            }
            stat(symbol: monitor.networkConnected ? "wifi" : "wifi.slash",
                 text: monitor.networkInterface)
        }
        .font(.system(size: 11, design: .monospaced))
    }

    private func stat(symbol: String, text: String) -> some View {
        HStack(spacing: 4) {
            Image(systemName: symbol)
                .font(.system(size: 10))
                .foregroundStyle(.secondary)
            Text(text)
        }
    }
}
