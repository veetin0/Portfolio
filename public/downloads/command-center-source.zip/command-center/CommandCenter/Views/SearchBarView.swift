//
//  SearchBarView.swift
//  Command Center
//
//  Spotlight-like search field with a floating results list.
//  Fully keyboard-driven: ↑/↓ to move, ↩ to run, ⎋ to dismiss.
//

import SwiftUI

struct SearchBarView: View {
    @EnvironmentObject private var viewModel: AppViewModel
    /// The engine is owned by the view model and passed in explicitly so this
    /// view re-renders whenever results change.
    @ObservedObject var engine: SearchEngine
    @FocusState private var isFocused: Bool
    @State private var selectionIndex = 0

    var body: some View {
        VStack(spacing: 0) {
            searchField
            resultsList
        }
    }

    // MARK: Field

    private var searchField: some View {
        HStack(spacing: 10) {
            Image(systemName: "magnifyingglass")
                .foregroundStyle(.secondary)

            TextField("Search apps, files and actions…",
                      text: $engine.query)
                .textFieldStyle(.plain)
                .font(.system(size: 16))
                .focused($isFocused)
                .onSubmit { runSelected() }
                .onKeyPress(.downArrow) { moveSelection(1); return .handled }
                .onKeyPress(.upArrow) { moveSelection(-1); return .handled }
                .onKeyPress(.escape) { clear(); return .handled }

            if !engine.query.isEmpty {
                Button(action: clear) {
                    Image(systemName: "xmark.circle.fill")
                        .foregroundStyle(.tertiary)
                }
                .buttonStyle(.plain)
            }
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 10)
        .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 12))
        .overlay(
            RoundedRectangle(cornerRadius: 12)
                .strokeBorder(isFocused ? Color.accentColor.opacity(0.6) : .clear,
                              lineWidth: 1.5)
        )
        .onReceive(viewModel.focusSearchRequested) { _ in isFocused = true }
        .onChange(of: engine.results) { _ in selectionIndex = 0 }
    }

    // MARK: Results

    @ViewBuilder
    private var resultsList: some View {
        let results = engine.results
        if !results.isEmpty {
            ScrollViewReader { proxy in
                ScrollView {
                    LazyVStack(spacing: 2) {
                        ForEach(Array(results.enumerated()), id: \.element.id) { index, result in
                            SearchResultRow(result: result,
                                            isSelected: index == selectionIndex)
                                .id(index)
                                .onTapGesture { run(result) }
                                .onHover { if $0 { selectionIndex = index } }
                        }
                    }
                    .padding(6)
                }
                .frame(maxHeight: 260)
                .onChange(of: selectionIndex) { index in
                    withAnimation(.easeOut(duration: 0.1)) {
                        proxy.scrollTo(index, anchor: .center)
                    }
                }
            }
            .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 12))
            .shadow(radius: 12, y: 6)
            .padding(.top, 6)
            .transition(.opacity.combined(with: .move(edge: .top)))
        }
    }

    // MARK: Keyboard actions

    private func moveSelection(_ delta: Int) {
        let count = engine.results.count
        guard count > 0 else { return }
        selectionIndex = (selectionIndex + delta + count) % count
    }

    private func runSelected() {
        let results = engine.results
        guard results.indices.contains(selectionIndex) else { return }
        run(results[selectionIndex])
    }

    private func run(_ result: SearchResult) {
        viewModel.run(result.action, label: result.title)
        clear()
    }

    private func clear() {
        engine.query = ""
        selectionIndex = 0
    }
}

// MARK: - Row

private struct SearchResultRow: View {
    let result: SearchResult
    let isSelected: Bool

    var body: some View {
        HStack(spacing: 10) {
            if let icon = result.icon {
                Image(nsImage: icon)
                    .resizable()
                    .frame(width: 24, height: 24)
            } else {
                Image(systemName: result.symbol)
                    .font(.system(size: 15))
                    .frame(width: 24, height: 24)
                    .foregroundStyle(isSelected ? .white : .secondary)
            }

            VStack(alignment: .leading, spacing: 1) {
                Text(result.title)
                    .font(.system(size: 13, weight: .medium))
                    .lineLimit(1)
                Text(result.subtitle)
                    .font(.system(size: 11))
                    .foregroundStyle(isSelected ? .white.opacity(0.8) : .secondary)
                    .lineLimit(1)
            }

            Spacer()

            if isSelected {
                Text("↩")
                    .font(.system(size: 11, design: .monospaced))
                    .foregroundStyle(.white.opacity(0.7))
            }
        }
        .padding(.horizontal, 10)
        .padding(.vertical, 6)
        .background(
            RoundedRectangle(cornerRadius: 8)
                .fill(isSelected ? Color.accentColor : .clear)
        )
        .foregroundStyle(isSelected ? .white : .primary)
        .contentShape(Rectangle())
    }
}
