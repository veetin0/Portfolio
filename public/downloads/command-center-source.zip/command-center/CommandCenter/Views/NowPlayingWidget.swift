//
//  NowPlayingWidget.swift
//  Command Center
//
//  Full-width player bar shown under the tile grid:
//  [artwork+badge] [title/artist + scrubbable timeline] [transport controls]
//  Collapses away entirely when nothing is playing.
//

import SwiftUI

struct NowPlayingWidget: View {
    @StateObject private var controller = MediaController()

    /// Local scrub position while dragging (nil = follow playback).
    @State private var scrubPosition: Double?

    var body: some View {
        Group {
            if let np = controller.nowPlaying {
                bar(for: np)
                    .transition(.move(edge: .bottom).combined(with: .opacity))
            }
        }
        .animation(.easeInOut(duration: 0.25), value: controller.nowPlaying == nil)
    }

    // MARK: Bar

    private func bar(for np: MediaController.NowPlaying) -> some View {
        HStack(spacing: 14) {
            artworkView(for: np)

            VStack(alignment: .leading, spacing: 4) {
                HStack(spacing: 6) {
                    Text(np.title)
                        .font(.system(size: 12, weight: .semibold))
                        .lineLimit(1)
                    Text("—")
                        .foregroundStyle(.tertiary)
                    Text(np.artist)
                        .font(.system(size: 12))
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                }
                timeline(for: np)
            }
            .frame(maxWidth: .infinity)

            transportControls(isPlaying: np.isPlaying)
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 10)
        .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 14))
    }

    // MARK: Artwork + app badge

    private func artworkView(for np: MediaController.NowPlaying) -> some View {
        ZStack(alignment: .bottomTrailing) {
            Group {
                if let artwork = controller.artwork {
                    Image(nsImage: artwork)
                        .resizable()
                        .scaledToFill()
                } else {
                    RoundedRectangle(cornerRadius: 8)
                        .fill(.quaternary)
                        .overlay(Image(systemName: "music.note")
                            .foregroundStyle(.secondary))
                }
            }
            .frame(width: 44, height: 44)
            .clipShape(RoundedRectangle(cornerRadius: 8))

            // Source app badge (e.g. the Spotify icon).
            if let icon = np.source.appIcon {
                Image(nsImage: icon)
                    .resizable()
                    .frame(width: 16, height: 16)
                    .shadow(radius: 1)
                    .offset(x: 4, y: 4)
            }
        }
    }

    // MARK: Timeline

    private func timeline(for np: MediaController.NowPlaying) -> some View {
        HStack(spacing: 8) {
            Text(format(scrubPosition ?? np.position))
                .font(.system(size: 9, design: .monospaced))
                .foregroundStyle(.secondary)
                .frame(width: 32, alignment: .trailing)

            Slider(
                value: Binding(
                    get: { scrubPosition ?? np.position },
                    set: { scrubPosition = $0 }
                ),
                in: 0...max(np.duration, 1),
                onEditingChanged: { editing in
                    controller.isScrubbing = editing
                    if !editing, let target = scrubPosition {
                        controller.seek(to: target)
                        scrubPosition = nil
                    }
                }
            )
            .controlSize(.mini)

            Text(format(np.duration))
                .font(.system(size: 9, design: .monospaced))
                .foregroundStyle(.secondary)
                .frame(width: 32, alignment: .leading)
        }
    }

    // MARK: Transport

    private func transportControls(isPlaying: Bool) -> some View {
        HStack(spacing: 12) {
            transportButton("gobackward.10", help: "Back 10 seconds") {
                controller.skip(by: -10)
            }
            transportButton("backward.fill", help: "Previous track") {
                controller.previousTrack()
            }
            transportButton(isPlaying ? "pause.fill" : "play.fill",
                            size: 17,
                            help: isPlaying ? "Pause" : "Play") {
                controller.togglePlayPause()
            }
            transportButton("forward.fill", help: "Next track") {
                controller.nextTrack()
            }
            transportButton("goforward.10", help: "Forward 10 seconds") {
                controller.skip(by: 10)
            }
        }
    }

    private func transportButton(_ symbol: String,
                                 size: CGFloat = 13,
                                 help: String,
                                 action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Image(systemName: symbol)
                .font(.system(size: size, weight: .medium))
                .frame(width: 26, height: 26)
                .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .help(help)
    }

    // MARK: Formatting

    private func format(_ seconds: Double) -> String {
        let total = Int(max(0, seconds))
        return String(format: "%d:%02d", total / 60, total % 60)
    }
}
