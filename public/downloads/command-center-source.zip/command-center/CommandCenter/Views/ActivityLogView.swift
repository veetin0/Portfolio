//
//  ActivityLogView.swift
//  Command Center
//
//  Popover listing recent action runs: what ran, when ("2 min ago"),
//  whether it succeeded, and the error message if not.
//

import SwiftUI

struct ActivityLogView: View {
    @EnvironmentObject private var viewModel: AppViewModel

    private static let relativeFormatter: RelativeDateTimeFormatter = {
        let formatter = RelativeDateTimeFormatter()
        formatter.unitsStyle = .abbreviated
        return formatter
    }()

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            HStack {
                Text("Activity")
                    .font(.headline)
                Spacer()
                if !viewModel.activityLog.isEmpty {
                    Button("Clear") { viewModel.clearActivityLog() }
                        .buttonStyle(.plain)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }
            .padding(12)

            Divider()

            if viewModel.activityLog.isEmpty {
                Text("No actions run yet")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 24)
            } else {
                ScrollView {
                    LazyVStack(alignment: .leading, spacing: 0) {
                        ForEach(viewModel.activityLog) { entry in
                            row(for: entry)
                            Divider().opacity(0.4)
                        }
                    }
                }
                .frame(maxHeight: 300)
            }
        }
        .frame(width: 290)
    }

    private func row(for entry: AppViewModel.ActivityEntry) -> some View {
        HStack(alignment: .top, spacing: 10) {
            Image(systemName: entry.success
                  ? "checkmark.circle.fill"
                  : "exclamationmark.triangle.fill")
                .foregroundStyle(entry.success ? .green : .yellow)
                .font(.system(size: 13))
                .padding(.top, 1)

            VStack(alignment: .leading, spacing: 1) {
                Text(entry.label)
                    .font(.system(size: 12, weight: .medium))
                    .lineLimit(1)
                if let message = entry.message, !entry.success {
                    Text(message)
                        .font(.system(size: 10))
                        .foregroundStyle(.secondary)
                        .lineLimit(2)
                }
            }

            Spacer()

            Text(Self.relativeFormatter.localizedString(
                for: entry.date, relativeTo: Date()))
                .font(.system(size: 10))
                .foregroundStyle(.tertiary)
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 7)
    }
}
