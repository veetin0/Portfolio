//
//  TileGridView.swift
//  Command Center
//
//  Adaptive grid of tiles. Drag & drop reordering uses the classic
//  DropDelegate "reorder on drag-over" pattern so tiles shuffle live
//  while dragging, Launchpad-style.
//

import SwiftUI
import UniformTypeIdentifiers

struct TileGridView: View {
    @EnvironmentObject private var viewModel: AppViewModel
    @State private var draggedTileID: UUID?

    var body: some View {
        ScrollView {
            let size = viewModel.config.tileSize
            LazyVGrid(
                columns: [GridItem(.adaptive(minimum: size, maximum: size + 30),
                                   spacing: 14)],
                spacing: 14
            ) {
                ForEach(viewModel.selectedPage?.tiles ?? []) { tile in
                    TileView(tile: tile, size: size)
                        .opacity(draggedTileID == tile.id ? 0.35 : 1)
                        .onDrag {
                            draggedTileID = tile.id
                            return NSItemProvider(object: tile.id.uuidString as NSString)
                        }
                        .onDrop(of: [.text],
                                delegate: TileReorderDelegate(
                                    targetID: tile.id,
                                    draggedID: $draggedTileID,
                                    viewModel: viewModel))
                }

                addTilePlaceholder(size: size)
            }
            .padding(.bottom, 20)
        }
        .scrollIndicators(.hidden)
    }

    private func addTilePlaceholder(size: Double) -> some View {
        Button {
            viewModel.beginAddingTile()
        } label: {
            VStack(spacing: 8) {
                Image(systemName: "plus")
                    .font(.title2)
                Text("Add")
                    .font(.caption)
            }
            .foregroundStyle(.secondary)
            .frame(width: size, height: size)
            .background(
                RoundedRectangle(cornerRadius: 18)
                    .strokeBorder(style: StrokeStyle(lineWidth: 1.5, dash: [6]))
                    .foregroundStyle(.quaternary)
            )
        }
        .buttonStyle(.plain)
    }
}

// MARK: - Reorder delegate

/// Moves the dragged tile into the hovered slot as the drag passes over it.
struct TileReorderDelegate: DropDelegate {
    let targetID: UUID
    @Binding var draggedID: UUID?
    let viewModel: AppViewModel

    func dropEntered(info: DropInfo) {
        guard let draggedID, draggedID != targetID else { return }
        viewModel.moveTile(withID: draggedID, before: targetID)
    }

    func dropUpdated(info: DropInfo) -> DropProposal? {
        DropProposal(operation: .move)
    }

    func performDrop(info: DropInfo) -> Bool {
        draggedID = nil
        return true
    }
}

// MARK: - Tile

struct TileView: View {
    @EnvironmentObject private var viewModel: AppViewModel
    let tile: Tile
    let size: Double

    @State private var isHovering = false
    @State private var isPressed = false

    var body: some View {
        Button(action: { viewModel.run(tile) }) {
            VStack(spacing: 8) {
                iconView
                    .font(.system(size: size * 0.26, weight: .medium))
                    .foregroundStyle(.white)
                    .frame(height: size * 0.36)

                Text(tile.label)
                    .font(.system(size: 12, weight: .semibold))
                    .foregroundStyle(.white)
                    .lineLimit(2)
                    .multilineTextAlignment(.center)

                if let shortcut = tile.shortcut {
                    Text(shortcut.display)
                        .font(.system(size: 9, weight: .medium, design: .monospaced))
                        .foregroundStyle(.white.opacity(0.7))
                        .padding(.horizontal, 6)
                        .padding(.vertical, 2)
                        .background(.white.opacity(0.15), in: Capsule())
                }
            }
            .padding(8)
            .frame(width: size, height: size)
            .background(
                RoundedRectangle(cornerRadius: 18)
                    .fill(
                        LinearGradient(
                            colors: [tile.color, tile.color.opacity(0.75)],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing)
                    )
                    .shadow(color: tile.color.opacity(isHovering ? 0.5 : 0.25),
                            radius: isHovering ? 10 : 5, y: 3)
            )
            .scaleEffect(isPressed ? 0.94 : (isHovering ? 1.04 : 1))
        }
        .buttonStyle(.plain)
        .onHover { hovering in
            withAnimation(.spring(response: 0.25, dampingFraction: 0.7)) {
                isHovering = hovering
            }
        }
        .pressEvents(
            onPress: { withAnimation(.easeOut(duration: 0.1)) { isPressed = true } },
            onRelease: { withAnimation(.easeOut(duration: 0.15)) { isPressed = false } }
        )
        .contextMenu {
            Button("Edit…") { viewModel.beginEditing(tile) }
            Button("Run") { viewModel.run(tile) }
            Divider()
            Button("Delete", role: .destructive) { viewModel.deleteTile(tile.id) }
        }
        .help(tile.action.type.displayName)
    }

    @ViewBuilder
    private var iconView: some View {
        if tile.iconIsImage,
           let image = NSImage(contentsOfFile: tile.icon.expandingTilde) {
            Image(nsImage: image)
                .resizable()
                .scaledToFit()
        } else {
            Image(systemName: tile.icon)
        }
    }
}

// MARK: - Press gesture helper

private struct PressEvents: ViewModifier {
    var onPress: () -> Void
    var onRelease: () -> Void

    func body(content: Content) -> some View {
        content.simultaneousGesture(
            DragGesture(minimumDistance: 0)
                .onChanged { _ in onPress() }
                .onEnded { _ in onRelease() }
        )
    }
}

extension View {
    func pressEvents(onPress: @escaping () -> Void,
                     onRelease: @escaping () -> Void) -> some View {
        modifier(PressEvents(onPress: onPress, onRelease: onRelease))
    }
}
