//
//  SystemInfoPanel.swift
//  Command Center
//
//  Real-time system dashboard fed by SystemMonitor (2s refresh).
//

import SwiftUI

struct SystemInfoPanel: View {
    @EnvironmentObject private var viewModel: AppViewModel

    var body: some View {
        SystemInfoContent(monitor: viewModel.systemMonitor)
    }
}

/// Split out so @ObservedObject binds to the shared monitor instance.
private struct SystemInfoContent: View {
    @ObservedObject var monitor: SystemMonitor

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                Text("System")
                    .font(.headline)
                    .foregroundStyle(.secondary)

                batteryCard
                meterCard(title: "CPU",
                          symbol: "cpu",
                          value: monitor.cpuUsage,
                          detail: String(format: "%.0f%%", monitor.cpuUsage * 100),
                          tint: tint(for: monitor.cpuUsage))
                memoryCard
                networkCard
                diskCard

                Text("Weather")
                    .font(.headline)
                    .foregroundStyle(.secondary)
                    .padding(.top, 4)
                WeatherWidget()
            }
            .padding(16)
        }
        .scrollIndicators(.hidden)
    }

    // MARK: Battery

    @ViewBuilder
    private var batteryCard: some View {
        card {
            HStack {
                Image(systemName: batterySymbol)
                    .foregroundStyle(monitor.isCharging ? .green : .primary)
                VStack(alignment: .leading, spacing: 2) {
                    Text(monitor.batteryPercent.map { "\($0)%" } ?? "No battery")
                        .font(.system(size: 20, weight: .semibold, design: .rounded))
                        .contentTransition(.numericText())
                    if let time = monitor.batteryTimeRemaining {
                        Text(time)
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                }
                Spacer()
            }
            if let percent = monitor.batteryPercent {
                ProgressView(value: Double(percent), total: 100)
                    .tint(percent <= 20 ? .red : (monitor.isCharging ? .green : .accentColor))
            }
        }
    }

    private var batterySymbol: String {
        guard let percent = monitor.batteryPercent else { return "powerplug" }
        if monitor.isCharging { return "battery.100.bolt" }
        switch percent {
        case ..<15:  return "battery.25"
        case ..<55:  return "battery.50"
        case ..<85:  return "battery.75"
        default:     return "battery.100"
        }
    }

    // MARK: Memory

    private var memoryCard: some View {
        let used = Double(monitor.memoryUsedBytes)
        let total = Double(monitor.memoryTotalBytes)
        let fraction = total > 0 ? used / total : 0
        return meterCard(
            title: "Memory",
            symbol: "memorychip",
            value: fraction,
            detail: "\(format(bytes: monitor.memoryUsedBytes)) / \(format(bytes: monitor.memoryTotalBytes))",
            tint: tint(for: fraction))
    }

    // MARK: Network

    private var networkCard: some View {
        card {
            HStack {
                Image(systemName: monitor.networkConnected ? "wifi" : "wifi.slash")
                    .foregroundStyle(monitor.networkConnected ? .green : .red)
                VStack(alignment: .leading, spacing: 2) {
                    Text(monitor.networkInterface)
                        .font(.system(size: 14, weight: .semibold))
                    Text(monitor.networkConnected ? "Connected" : "No connection")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                Spacer()
                Circle()
                    .fill(monitor.networkConnected ? .green : .red)
                    .frame(width: 8, height: 8)
            }
        }
    }

    // MARK: Disk

    private var diskCard: some View {
        let total = Double(monitor.diskTotalBytes)
        let used = total - Double(monitor.diskFreeBytes)
        let fraction = total > 0 ? used / total : 0
        return meterCard(
            title: "Disk",
            symbol: "internaldrive",
            value: fraction,
            detail: "\(format(bytes: UInt64(max(0, monitor.diskFreeBytes)))) free",
            tint: tint(for: fraction))
    }

    // MARK: Building blocks

    private func meterCard(title: String, symbol: String, value: Double,
                           detail: String, tint: Color) -> some View {
        card {
            HStack {
                Label(title, systemImage: symbol)
                    .font(.system(size: 13, weight: .medium))
                Spacer()
                Text(detail)
                    .font(.system(size: 12, design: .monospaced))
                    .foregroundStyle(.secondary)
                    .contentTransition(.numericText())
            }
            ProgressView(value: min(max(value, 0), 1))
                .tint(tint)
                .animation(.easeOut(duration: 0.4), value: value)
        }
    }

    private func card<Content: View>(@ViewBuilder content: () -> Content) -> some View {
        VStack(alignment: .leading, spacing: 8, content: content)
            .padding(12)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 12))
    }

    private func tint(for fraction: Double) -> Color {
        switch fraction {
        case ..<0.6: return .green
        case ..<0.85: return .orange
        default: return .red
        }
    }

    private func format(bytes: UInt64) -> String {
        ByteCountFormatter.string(fromByteCount: Int64(bytes), countStyle: .memory)
    }
}
