//
//  SettingsView.swift
//  Command Center
//
//  App preferences: summon hotkey, tile size, system panel visibility,
//  and profile management.
//

import SwiftUI
import AppKit

struct SettingsView: View {
    @EnvironmentObject private var viewModel: AppViewModel
    @State private var isRecording = false
    @State private var newProfileName = ""
    @State private var recorderMonitor: Any?

    var body: some View {
        Form {
            Section("Global Hotkey") {
                HStack {
                    Text("Summon Command Center")
                    Spacer()
                    Text(viewModel.config.summonShortcut?.display ?? "None")
                        .font(.system(.body, design: .monospaced))
                        .padding(.horizontal, 10)
                        .padding(.vertical, 4)
                        .background(.quaternary.opacity(0.5),
                                    in: RoundedRectangle(cornerRadius: 6))
                    Button(isRecording ? "Press keys…" : "Change") {
                        toggleRecorder()
                    }
                }
                Text("Tip: ⌘Space belongs to Spotlight — ⌥Space or ⌃Space work well.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            Section("Dashboard") {
                Slider(value: $viewModel.config.tileSize, in: 84...160, step: 4) {
                    Text("Tile size")
                }
                Toggle("Show system panel", isOn: $viewModel.config.showSystemPanel)
                Toggle("Sound & haptic feedback", isOn: $viewModel.config.feedbackEnabled)
            }

            Section("Profiles") {
                ForEach(viewModel.config.profiles) { profile in
                    HStack {
                        Label(profile.name, systemImage: profile.symbol)
                        Spacer()
                        if profile.id == viewModel.config.activeProfileID {
                            Text("Active")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                    }
                }
                HStack {
                    TextField("New profile name", text: $newProfileName)
                    Button("Add") {
                        guard !newProfileName.isEmpty else { return }
                        viewModel.addProfile(named: newProfileName)
                        newProfileName = ""
                    }
                }
            }

            Section("Data") {
                LabeledContent("Configuration file",
                               value: "~/Library/Application Support/CommandCenter/config.json")
                    .font(.caption)
            }
        }
        .formStyle(.grouped)
        .frame(width: 460, height: 460)
        .onDisappear { stopRecorder() }
    }

    // MARK: Summon hotkey recorder

    private func toggleRecorder() {
        isRecording ? stopRecorder() : startRecorder()
    }

    private func startRecorder() {
        isRecording = true
        recorderMonitor = NSEvent.addLocalMonitorForEvents(matching: .keyDown) { event in
            if let shortcut = KeyShortcut.from(event: event) {
                viewModel.config.summonShortcut = shortcut
                viewModel.syncHotkeys()
                DispatchQueue.main.async { stopRecorder() }
                return nil
            }
            return event
        }
    }

    private func stopRecorder() {
        isRecording = false
        if let recorderMonitor {
            NSEvent.removeMonitor(recorderMonitor)
        }
        recorderMonitor = nil
    }
}
