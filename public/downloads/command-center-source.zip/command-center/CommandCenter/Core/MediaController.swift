//
//  MediaController.swift
//  Command Center
//
//  Now-playing state + transport controls for Spotify and Apple Music.
//
//  Scripts run through /usr/bin/osascript in a subprocess rather than
//  NSAppleScript: NSAppleScript can raise uncatchable Objective-C
//  exceptions from inside the Apple Events layer (which abort the whole
//  app), while a subprocess isolates any failure and keeps the main
//  thread free. Polling is async and never overlaps itself.
//

import Foundation
import AppKit
import Combine

@MainActor
final class MediaController: ObservableObject {

    // MARK: State

    enum Source: String {
        case spotify = "Spotify"
        case music = "Music"

        var bundleID: String {
            switch self {
            case .spotify: return "com.spotify.client"
            case .music:   return "com.apple.Music"
            }
        }

        var appIcon: NSImage? {
            guard let url = NSWorkspace.shared
                .urlForApplication(withBundleIdentifier: bundleID) else { return nil }
            return NSWorkspace.shared.icon(forFile: url.path)
        }
    }

    struct NowPlaying: Equatable {
        var source: Source
        var title: String
        var artist: String
        var position: Double     // seconds
        var duration: Double     // seconds
        var isPlaying: Bool
        var artworkURL: String?  // Spotify only
        var trackKey: String { "\(source.rawValue)|\(title)|\(artist)" }
    }

    @Published private(set) var nowPlaying: NowPlaying?
    @Published private(set) var artwork: NSImage?

    /// Set by the UI while dragging the timeline.
    var isScrubbing = false

    private var timer: AnyCancellable?
    private var isPolling = false
    private var artworkKey: String?

    private static let musicArtworkPath =
        NSTemporaryDirectory() + "commandcenter_artwork"

    init() {
        Task { await poll() }
        timer = Timer.publish(every: 1, on: .main, in: .common)
            .autoconnect()
            .sink { [weak self] _ in
                Task { await self?.poll() }
            }
    }

    // MARK: Polling

    private func poll() async {
        // Never overlap polls (a stuck permission dialog would otherwise
        // stack up subprocesses), and don't fight the scrubber.
        guard !isPolling, !isScrubbing else { return }
        isPolling = true
        defer { isPolling = false }

        let info: NowPlaying?
        if isRunning(.spotify), let spotify = await pollSpotify() {
            info = spotify
        } else if isRunning(.music), let music = await pollMusic() {
            info = music
        } else {
            info = nil
        }

        nowPlaying = info

        guard let info else {
            artwork = nil
            artworkKey = nil
            return
        }
        if info.trackKey != artworkKey {
            artworkKey = info.trackKey
            await fetchArtwork(for: info)
        }
    }

    /// Spotify: duration arrives in milliseconds; artwork as an https URL.
    private func pollSpotify() async -> NowPlaying? {
        let script = """
        tell application "Spotify"
            if player state is playing or player state is paused then
                set t to current track
                set output to (name of t) & linefeed & (artist of t)
                set output to output & linefeed & (artwork url of t)
                set output to output & linefeed & ((player position) as text)
                set output to output & linefeed & ((duration of t) as text)
                set output to output & linefeed & ((player state) as text)
                return output
            end if
            return ""
        end tell
        """
        guard let parts = await runScriptLines(script), parts.count >= 6 else { return nil }
        return NowPlaying(
            source: .spotify,
            title: parts[0],
            artist: parts[1],
            position: parseDouble(parts[3]) ?? 0,
            duration: (parseDouble(parts[4]) ?? 0) / 1000.0,
            isPlaying: parts[5] == "playing",
            artworkURL: parts[2])
    }

    /// Apple Music: position and duration are both plain seconds.
    private func pollMusic() async -> NowPlaying? {
        let script = """
        tell application "Music"
            if player state is playing or player state is paused then
                set t to current track
                set output to (name of t) & linefeed & (artist of t)
                set output to output & linefeed & ((player position) as text)
                set output to output & linefeed & ((duration of t) as text)
                set output to output & linefeed & ((player state) as text)
                return output
            end if
            return ""
        end tell
        """
        guard let parts = await runScriptLines(script), parts.count >= 5 else { return nil }
        return NowPlaying(
            source: .music,
            title: parts[0],
            artist: parts[1],
            position: parseDouble(parts[2]) ?? 0,
            duration: parseDouble(parts[3]) ?? 0,
            isPlaying: parts[4] == "playing",
            artworkURL: nil)
    }

    // MARK: Artwork

    private func fetchArtwork(for info: NowPlaying) async {
        artwork = nil
        let key = info.trackKey

        switch info.source {
        case .spotify:
            guard let urlString = info.artworkURL,
                  let url = URL(string: urlString) else { return }
            guard let (data, _) = try? await URLSession.shared.data(from: url),
                  let image = NSImage(data: data) else { return }
            if artworkKey == key { artwork = image }

        case .music:
            // Have Music write the artwork bytes to a temp file — much safer
            // than pulling a big binary descriptor through Apple Events.
            let path = Self.musicArtworkPath
            let script = """
            tell application "Music"
                try
                    set d to raw data of artwork 1 of current track
                on error
                    return ""
                end try
            end tell
            set filePath to POSIX file "\(path)"
            try
                set f to open for access filePath with write permission
                set eof f to 0
                write d to f
                close access f
                return "ok"
            on error
                try
                    close access filePath
                end try
                return ""
            end try
            """
            guard await runScript(script) == "ok",
                  let image = NSImage(contentsOfFile: path) else { return }
            if artworkKey == key { artwork = image }
        }
    }

    // MARK: Transport commands

    func togglePlayPause() { command("playpause") }
    func nextTrack()       { command("next track") }
    func previousTrack()   { command("previous track") }

    func skip(by seconds: Double) {
        guard let np = nowPlaying else { return }
        seek(to: np.position + seconds)
    }

    func seek(to seconds: Double) {
        guard let np = nowPlaying else { return }
        let clamped = min(max(0, seconds), max(0, np.duration - 1))
        // AppleScript expects a dot decimal regardless of locale when the
        // number is written in source form.
        command("set player position to \(String(format: "%.1f", clamped))")
        nowPlaying?.position = clamped   // optimistic UI update
    }

    private func command(_ line: String) {
        guard let source = nowPlaying?.source else { return }
        Task {
            _ = await runScript("tell application \"\(source.rawValue)\" to \(line)")
            // Refresh soon after so the UI reflects the change quickly.
            try? await Task.sleep(nanoseconds: 200_000_000)
            await poll()
        }
    }

    // MARK: osascript subprocess runner

    /// Runs the script via /usr/bin/osascript on a background queue.
    /// Returns trimmed stdout, or nil on any failure.
    private func runScript(_ source: String) async -> String? {
        await withCheckedContinuation { continuation in
            DispatchQueue.global(qos: .userInitiated).async {
                let process = Process()
                process.executableURL = URL(fileURLWithPath: "/usr/bin/osascript")
                process.arguments = ["-e", source]

                let stdout = Pipe()
                process.standardOutput = stdout
                process.standardError = Pipe()   // discard; failures return nil

                do {
                    try process.run()
                } catch {
                    continuation.resume(returning: nil)
                    return
                }
                process.waitUntilExit()

                guard process.terminationStatus == 0 else {
                    continuation.resume(returning: nil)
                    return
                }
                let data = stdout.fileHandleForReading.readDataToEndOfFile()
                let text = String(data: data, encoding: .utf8)?
                    .trimmingCharacters(in: .whitespacesAndNewlines)
                continuation.resume(returning: (text?.isEmpty == false) ? text : nil)
            }
        }
    }

    private func runScriptLines(_ source: String) async -> [String]? {
        guard let text = await runScript(source) else { return nil }
        return text.components(separatedBy: "\n")
    }

    // MARK: Helpers

    private func isRunning(_ source: Source) -> Bool {
        NSWorkspace.shared.runningApplications
            .contains { $0.bundleIdentifier == source.bundleID }
    }

    /// AppleScript formats reals with the system locale — a Finnish Mac
    /// returns "12,5" — so normalise the decimal separator before parsing.
    private func parseDouble(_ text: String) -> Double? {
        Double(text.trimmingCharacters(in: .whitespaces)
            .replacingOccurrences(of: ",", with: "."))
    }
}
