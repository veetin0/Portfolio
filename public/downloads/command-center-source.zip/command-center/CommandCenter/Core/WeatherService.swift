//
//  WeatherService.swift
//  Command Center
//
//  Fetches current conditions for a fixed list of cities from the free
//  Open-Meteo API (no API key required) and refreshes every 15 minutes.
//
//  To change cities, edit `WeatherService.cities` below.
//
//  Note: WeatherKit would be the "most native" option but requires a paid
//  Apple Developer account + entitlement; Open-Meteo keeps the app
//  dependency-free and buildable by anyone.
//

import Foundation
import Combine

// MARK: - Models

struct CityWeather: Identifiable, Equatable {
    let id: String            // city name doubles as id
    let city: String
    let temperature: Double   // °C
    let windSpeed: Double     // km/h
    let weatherCode: Int      // WMO code
    let isDay: Bool

    /// SF Symbol for the WMO weather interpretation code.
    var symbol: String {
        switch weatherCode {
        case 0:            return isDay ? "sun.max.fill" : "moon.stars.fill"
        case 1, 2:         return isDay ? "cloud.sun.fill" : "cloud.moon.fill"
        case 3:            return "cloud.fill"
        case 45, 48:       return "cloud.fog.fill"
        case 51...57:      return "cloud.drizzle.fill"
        case 61...67:      return "cloud.rain.fill"
        case 71...77:      return "cloud.snow.fill"
        case 80...82:      return "cloud.heavyrain.fill"
        case 85, 86:       return "cloud.snow.fill"
        case 95...99:      return "cloud.bolt.rain.fill"
        default:           return "questionmark.circle"
        }
    }

    var summary: String {
        switch weatherCode {
        case 0:        return "Clear"
        case 1:        return "Mostly clear"
        case 2:        return "Partly cloudy"
        case 3:        return "Overcast"
        case 45, 48:   return "Fog"
        case 51...57:  return "Drizzle"
        case 61...67:  return "Rain"
        case 71...77:  return "Snow"
        case 80...82:  return "Showers"
        case 85, 86:   return "Snow showers"
        case 95...99:  return "Thunderstorm"
        default:       return "—"
        }
    }
}

// MARK: - Service

@MainActor
final class WeatherService: ObservableObject {

    struct City {
        let name: String
        let latitude: Double
        let longitude: Double
    }

    /// Edit this list to change which cities are shown.
    static let cities: [City] = [
        City(name: "Tampere", latitude: 61.4978, longitude: 23.7610),
        City(name: "Vaasa",   latitude: 63.0951, longitude: 21.6165)
    ]

    @Published private(set) var reports: [CityWeather] = []
    @Published private(set) var lastError: String?

    private var timer: AnyCancellable?

    init() {
        Task { await refresh() }
        // 15-minute refresh — Open-Meteo updates roughly that often anyway.
        timer = Timer.publish(every: 15 * 60, on: .main, in: .common)
            .autoconnect()
            .sink { _ in Task { [weak self] in await self?.refresh() } }
    }

    func refresh() async {
        var results: [CityWeather] = []
        for city in Self.cities {
            if let report = await fetch(city) {
                results.append(report)
            }
        }
        reports = results
        lastError = results.isEmpty ? "Weather unavailable" : nil
    }

    // MARK: Networking

    /// Minimal decode of the Open-Meteo "current" block.
    private struct APIResponse: Decodable {
        struct Current: Decodable {
            let temperature_2m: Double
            let weather_code: Int
            let wind_speed_10m: Double
            let is_day: Int
        }
        let current: Current
    }

    private func fetch(_ city: City) async -> CityWeather? {
        var components = URLComponents(string: "https://api.open-meteo.com/v1/forecast")!
        components.queryItems = [
            .init(name: "latitude", value: String(city.latitude)),
            .init(name: "longitude", value: String(city.longitude)),
            .init(name: "current",
                  value: "temperature_2m,weather_code,wind_speed_10m,is_day"),
            .init(name: "wind_speed_unit", value: "kmh")
        ]
        guard let url = components.url else { return nil }

        do {
            let (data, _) = try await URLSession.shared.data(from: url)
            let decoded = try JSONDecoder().decode(APIResponse.self, from: data)
            return CityWeather(
                id: city.name,
                city: city.name,
                temperature: decoded.current.temperature_2m,
                windSpeed: decoded.current.wind_speed_10m,
                weatherCode: decoded.current.weather_code,
                isDay: decoded.current.is_day == 1)
        } catch {
            NSLog("Weather fetch failed for \(city.name): \(error)")
            return nil
        }
    }
}
