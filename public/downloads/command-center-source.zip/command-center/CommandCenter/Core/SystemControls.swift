//
//  SystemControls.swift
//  Command Center
//
//  The bottom-left system control strip: volume slider + mute, dark mode
//  toggle, lock screen, sleep, and empty trash.
//
//  All state reads/writes go through osascript subprocesses (same
//  crash-safe pattern as MediaController). Dark mode uses System Events,
//  which triggers its own one-time Automation permission prompt.
//

import SwiftUI
import Combine

// MARK: - Model

@MainActor
final class SystemControlsModel: ObservableObject {

    @Published var volume: Double = 50        // 0…100
    @Published var isMuted = false
    @Published var isDarkMode = false

    /// True while the user drags the volume slider (pauses polling).
    var isAdjustingVolume = false

    private var timer: AnyCancellable?
    private var isPolling = false

    init() {
        Task { await poll() }
        timer = Timer.publish(every: 3, on: .main, in: .common)
            .autoconnect()
            .sink { [weak self] _ in Task { await self?.poll() } }
    }

    // MARK: Polling

    private func poll() async {
        guard !isPolling, !isAdjustingVolume else { return }
        isPolling = true
        defer { isPolling = false }

        let script = """
        set vs to (get volume settings)
        set v to (output volume of vs) as text
        set m to (output muted of vs) as text
        tell application "System Events"
            set d to (dark mode of appearance preferences) as text
        end tell
        return v & linefeed & m & linefeed & d
        """
        guard let output = await OSA.run(script) else { return }
        let parts = output.components(separatedBy: "\n")
        guard parts.count >= 3 else { return }

        if let value = Double(parts[0]) { volume = value }
        isMuted = parts[1] == "true"
        isDarkMode = parts[2] == "true"
    }

    // MARK: Actions

    func setVolume(_ value: Double) {
        volume = value
        Task { _ = await OSA.run("set volume output volume \(Int(value))") }
    }

    func toggleMute() {
        isMuted.toggle()
        FeedbackManager.shared.toggle()
        Task { _ = await OSA.run("set volume output muted \(isMuted)") }
    }

    func toggleDarkMode() {
        isDarkMode.toggle()
        FeedbackManager.shared.toggle()
        let script = """
        tell application "System Events"
            tell appearance preferences to set dark mode to not dark mode
        end tell
        """
        Task { _ = await OSA.run(script) }
    }

    nonisolated func lockScreen() {
        FeedbackManager.shared.tap()
        // Call the same routine as the Apple menu's "Lock Screen" item.
        // It lives in a private system framework, but unlike keystroke
        // synthesis it needs no Accessibility/Automation permission and
        // works regardless of how the app was launched.
        let path = "/System/Library/PrivateFrameworks/login.framework/Versions/Current/login"
        guard let handle = dlopen(path, RTLD_NOW),
              let symbol = dlsym(handle, "SACLockScreenImmediate") else {
            NSLog("Lock screen: login framework unavailable")
            return
        }
        typealias LockFunction = @convention(c) () -> Int32
        let lock = unsafeBitCast(symbol, to: LockFunction.self)
        _ = lock()
    }

    nonisolated func sleep() {
        FeedbackManager.shared.tap()
        runProcess("/usr/bin/pmset", arguments: ["sleepnow"])
    }

    func emptyTrash() {
        FeedbackManager.shared.toggle()
        Task {
            _ = await OSA.run(#"tell application "Finder" to empty trash"#)
        }
    }

    private nonisolated func runProcess(_ path: String, arguments: [String]) {
        let process = Process()
        process.executableURL = URL(fileURLWithPath: path)
        process.arguments = arguments
        try? process.run()
    }
}

// MARK: - Shared osascript runner

/// Reusable subprocess-based AppleScript execution (crash-isolated,
/// off-main-thread). MediaController keeps its own private copy; new code
/// should use this.
enum OSA {
    static func run(_ source: String) async -> String? {
        await withCheckedContinuation { continuation in
            DispatchQueue.global(qos: .userInitiated).async {
                let process = Process()
                process.executableURL = URL(fileURLWithPath: "/usr/bin/osascript")
                process.arguments = ["-e", source]
                let stdout = Pipe()
                process.standardOutput = stdout
                process.standardError = Pipe()
                do {
                    try process.run()
                } catch {
                    continuation.resume(returning: nil)
                    return
                }
                process.waitUntilExit()
                guard process.terminationStatus == 0 else {
                    continuation.resume(returning: nil)
                    return
                }
                let data = stdout.fileHandleForReading.readDataToEndOfFile()
                let text = String(data: data, encoding: .utf8)?
                    .trimmingCharacters(in: .whitespacesAndNewlines)
                continuation.resume(returning: text)
            }
        }
    }
}

// MARK: - View

struct SystemControlsView: View {
    @StateObject private var model = SystemControlsModel()
    @State private var confirmEmptyTrash = false

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("System")
                .font(.caption.weight(.semibold))
                .foregroundStyle(.secondary)

            // Volume row: mute toggle + slider.
            HStack(spacing: 8) {
                Button(action: model.toggleMute) {
                    Image(systemName: volumeSymbol)
                        .frame(width: 18)
                }
                .buttonStyle(.plain)
                .help(model.isMuted ? "Unmute" : "Mute")

                Slider(
                    value: Binding(
                        get: { model.volume },
                        set: { model.setVolume($0) }
                    ),
                    in: 0...100,
                    onEditingChanged: { model.isAdjustingVolume = $0 }
                )
                .controlSize(.mini)
                .disabled(model.isMuted)
            }

            // Control buttons row.
            HStack(spacing: 6) {
                controlButton(
                    symbol: model.isDarkMode ? "moon.fill" : "moon",
                    help: model.isDarkMode ? "Switch to light mode" : "Switch to dark mode",
                    isActive: model.isDarkMode
                ) { model.toggleDarkMode() }

                controlButton(symbol: "lock.fill", help: "Lock screen") {
                    model.lockScreen()
                }

                controlButton(symbol: "zzz", help: "Sleep") {
                    model.sleep()
                }

                controlButton(symbol: "trash", help: "Empty Trash") {
                    confirmEmptyTrash = true
                }
            }
        }
        .padding(12)
        .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 12))
        .padding(10)
        .confirmationDialog("Empty the Trash?",
                            isPresented: $confirmEmptyTrash) {
            Button("Empty Trash", role: .destructive) { model.emptyTrash() }
        } message: {
            Text("Items in the Trash will be permanently deleted.")
        }
    }

    private var volumeSymbol: String {
        if model.isMuted { return "speaker.slash.fill" }
        switch model.volume {
        case ..<5:   return "speaker.fill"
        case ..<40:  return "speaker.wave.1.fill"
        case ..<75:  return "speaker.wave.2.fill"
        default:     return "speaker.wave.3.fill"
        }
    }

    private func controlButton(symbol: String,
                               help: String,
                               isActive: Bool = false,
                               action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Image(systemName: symbol)
                .font(.system(size: 12, weight: .medium))
                .frame(maxWidth: .infinity)
                .frame(height: 26)
                .background(
                    RoundedRectangle(cornerRadius: 7)
                        .fill(isActive
                              ? AnyShapeStyle(Color.accentColor.opacity(0.3))
                              : AnyShapeStyle(.quaternary.opacity(0.5))))
        }
        .buttonStyle(.plain)
        .help(help)
    }
}
