//
//  Executors.swift
//  Command Center
//
//  Built-in ActionExecutor implementations.
//
//  ⚠️ Shell / AppleScript execution requires the App Sandbox to be
//  disabled (this is a personal power-user tool, like Raycast script
//  commands). See README → Sandbox notes.
//

import Foundation
import AppKit

// MARK: - Launch App

struct LaunchAppExecutor: ActionExecutor {
    let type: ActionType = .launchApp

    func execute(_ action: TileAction) async -> ActionResult {
        let payload = action.payload.expandingTilde

        // Accept either an absolute .app path or a bundle identifier.
        let url: URL?
        if payload.hasPrefix("/") {
            url = URL(fileURLWithPath: payload)
        } else {
            url = NSWorkspace.shared.urlForApplication(withBundleIdentifier: payload)
        }
        guard let appURL = url else {
            return .failure("App not found: \(action.payload)")
        }

        let configuration = NSWorkspace.OpenConfiguration()
        configuration.activates = true
        do {
            try await NSWorkspace.shared.openApplication(at: appURL, configuration: configuration)
            return .ok
        } catch {
            return .failure(error.localizedDescription)
        }
    }
}

// MARK: - Shell Command

struct ShellCommandExecutor: ActionExecutor {
    let type: ActionType = .shellCommand

    func execute(_ action: TileAction) async -> ActionResult {
        // Option: run visibly in Terminal.app instead of headless.
        if action.options["runInTerminal"] == "true" {
            return await runInTerminal(action.payload)
        }
        return await runHeadless(action)
    }

    /// Run via `zsh -lc` so PATH, aliases and ~ expansion behave as expected.
    private func runHeadless(_ action: TileAction) async -> ActionResult {
        await withCheckedContinuation { continuation in
            let process = Process()
            process.executableURL = URL(fileURLWithPath: "/bin/zsh")
            process.arguments = ["-lc", action.payload]

            // Inject "env:KEY" options as environment variables — this is how
            // workflows pass data (e.g. template code) into commands safely.
            var environment = ProcessInfo.processInfo.environment
            for (key, value) in action.options where key.hasPrefix("env:") {
                environment[String(key.dropFirst(4))] = value
            }
            process.environment = environment

            if let cwd = action.options["workingDirectory"] {
                process.currentDirectoryURL = URL(fileURLWithPath: cwd.expandingTilde)
            }

            let stderrPipe = Pipe()
            process.standardError = stderrPipe
            process.standardOutput = Pipe()

            process.terminationHandler = { proc in
                if proc.terminationStatus == 0 {
                    continuation.resume(returning: .ok)
                } else {
                    let data = stderrPipe.fileHandleForReading.readDataToEndOfFile()
                    let stderr = String(data: data, encoding: .utf8)?
                        .trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
                    continuation.resume(returning: .failure(
                        "Exit \(proc.terminationStatus)" + (stderr.isEmpty ? "" : ": \(stderr)")))
                }
            }
            do {
                try process.run()
            } catch {
                continuation.resume(returning: .failure(error.localizedDescription))
            }
        }
    }

    /// Open Terminal.app and type the command there (visible execution).
    private func runInTerminal(_ command: String) async -> ActionResult {
        let escaped = command
            .replacingOccurrences(of: "\\", with: "\\\\")
            .replacingOccurrences(of: "\"", with: "\\\"")
        let script = """
        tell application "Terminal"
            activate
            do script "\(escaped)"
        end tell
        """
        return await AppleScriptExecutor().execute(
            TileAction(type: .appleScript, payload: script))
    }
}

// MARK: - Open File / Folder

struct OpenPathExecutor: ActionExecutor {
    let type: ActionType = .openPath

    func execute(_ action: TileAction) async -> ActionResult {
        let path = action.payload.expandingTilde
        guard FileManager.default.fileExists(atPath: path) else {
            return .failure("Path not found: \(path)")
        }
        let url = URL(fileURLWithPath: path)
        if action.options["revealInFinder"] == "true" {
            NSWorkspace.shared.activateFileViewerSelecting([url])
        } else {
            NSWorkspace.shared.open(url)
        }
        return .ok
    }
}

// MARK: - AppleScript

struct AppleScriptExecutor: ActionExecutor {
    let type: ActionType = .appleScript

    func execute(_ action: TileAction) async -> ActionResult {
        let source = action.payload
        return await withCheckedContinuation { continuation in
            // NSAppleScript must run on the main thread.
            DispatchQueue.main.async {
                var errorInfo: NSDictionary?
                guard let script = NSAppleScript(source: source) else {
                    continuation.resume(returning: .failure("Invalid AppleScript"))
                    return
                }
                script.executeAndReturnError(&errorInfo)
                if let errorInfo,
                   let message = errorInfo[NSAppleScript.errorMessage] as? String {
                    continuation.resume(returning: .failure(message))
                } else {
                    continuation.resume(returning: .ok)
                }
            }
        }
    }
}

// MARK: - Open URL

struct OpenURLExecutor: ActionExecutor {
    let type: ActionType = .openURL

    func execute(_ action: TileAction) async -> ActionResult {
        var raw = action.payload.trimmingCharacters(in: .whitespaces)
        // Convenience: "owner/repo" opens the GitHub repository.
        if !raw.contains("://"), raw.contains("/"), !raw.hasPrefix("/") {
            raw = "https://github.com/\(raw)"
        } else if !raw.contains("://") {
            raw = "https://\(raw)"
        }
        guard let url = URL(string: raw) else {
            return .failure("Invalid URL: \(action.payload)")
        }
        NSWorkspace.shared.open(url)
        return .ok
    }
}

// MARK: - Workflow (composite)

struct WorkflowExecutor: ActionExecutor {
    let type: ActionType = .workflow

    func execute(_ action: TileAction) async -> ActionResult {
        for (index, step) in action.steps.enumerated() {
            let result = await ActionRegistry.shared.run(step)
            if !result.success {
                return .failure("Step \(index + 1) failed: \(result.message ?? "unknown error")")
            }
            // Small pause lets app launches settle before dependent steps.
            try? await Task.sleep(nanoseconds: 250_000_000)
        }
        return .ok
    }
}

// MARK: - Helpers

extension String {
    var expandingTilde: String { (self as NSString).expandingTildeInPath }
}
