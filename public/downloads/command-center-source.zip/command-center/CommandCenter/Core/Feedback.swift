//
//  Feedback.swift
//  Command Center
//
//  Centralised sound + haptic feedback. Sounds are the built-in macOS
//  system sounds (no bundled assets); haptics fire on Force Touch
//  trackpads and are silently ignored elsewhere.
//

import AppKit

final class FeedbackManager {

    static let shared = FeedbackManager()
    private init() {}

    /// Mirrors AppConfig.feedbackEnabled (kept in sync by AppViewModel).
    var isEnabled = true

    /// Tile pressed / action started.
    func tap() {
        haptic(.alignment)
    }

    /// Action completed successfully.
    func success() {
        play("Pop")
        haptic(.levelChange)
    }

    /// Action failed.
    func error() {
        play("Basso")
        haptic(.generic)
    }

    /// A switch/toggle changed state (system controls).
    func toggle() {
        play("Tink")
        haptic(.alignment)
    }

    // MARK: Private

    private func play(_ name: String) {
        guard isEnabled else { return }
        NSSound(named: name)?.play()
    }

    private func haptic(_ pattern: NSHapticFeedbackManager.FeedbackPattern) {
        guard isEnabled else { return }
        NSHapticFeedbackManager.defaultPerformer
            .perform(pattern, performanceTime: .default)
    }
}
