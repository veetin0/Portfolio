//
//  NewsSummary.swift
//  Command Center
//
//  "News Summary" action type: fetches today's headlines from RSS feeds
//  and presents a report sheet. If the tile has an Anthropic API key in
//  its options, an AI digest of the day is added on top.
//

import SwiftUI
import Foundation

// MARK: - Request plumbing

struct NewsRequest: Identifiable {
    let id = UUID()
    let feeds: [String]
    let apiKey: String?
}

/// Lets the executor ask the UI layer to present the report.
enum NewsPresenter {
    @MainActor static var handler: ((NewsRequest) -> Void)?
}

// MARK: - Executor

struct NewsSummaryExecutor: ActionExecutor {
    let type: ActionType = .newsSummary

    static let defaultFeeds = [
        "https://feeds.yle.fi/uutiset/v1/majorHeadlines/YLE_UUTISET.rss",
        "https://feeds.bbci.co.uk/news/rss.xml",
        "https://www.theguardian.com/world/rss"
    ]

    func execute(_ action: TileAction) async -> ActionResult {
        var feeds = action.payload
            .split(separator: ",")
            .map { $0.trimmingCharacters(in: .whitespaces) }
            .filter { !$0.isEmpty }
        if feeds.isEmpty { feeds = Self.defaultFeeds }

        let key = action.options["anthropicKey"]
        let request = NewsRequest(feeds: feeds,
                                  apiKey: (key?.isEmpty == false) ? key : nil)
        await MainActor.run { NewsPresenter.handler?(request) }
        return .ok
    }
}

// MARK: - Model

struct NewsItem: Identifiable {
    let id = UUID()
    let title: String
    let link: String
    let date: Date?
    let source: String
}

// MARK: - Fetching & RSS parsing

enum NewsService {

    /// Fetch all feeds concurrently, keep items from the last 24 hours,
    /// newest first.
    static func fetchHeadlines(feeds: [String]) async -> [NewsItem] {
        await withTaskGroup(of: [NewsItem].self) { group in
            for feed in feeds {
                group.addTask { await fetchFeed(feed) }
            }
            var all: [NewsItem] = []
            for await items in group { all.append(contentsOf: items) }

            let cutoff = Date().addingTimeInterval(-24 * 3600)
            return all
                .filter { ($0.date ?? Date()) >= cutoff }
                .sorted { ($0.date ?? .distantPast) > ($1.date ?? .distantPast) }
        }
    }

    private static func fetchFeed(_ urlString: String) async -> [NewsItem] {
        guard let url = URL(string: urlString),
              let (data, _) = try? await URLSession.shared.data(from: url)
        else { return [] }
        return RSSParser().parse(data: data)
    }
}

/// Minimal RSS 2.0 parser (title / link / pubDate per item, channel
/// title as the source name).
private final class RSSParser: NSObject, XMLParserDelegate {

    private var items: [NewsItem] = []
    private var channelTitle = ""
    private var insideItem = false
    private var currentElement = ""
    private var currentTitle = ""
    private var currentLink = ""
    private var currentDate = ""

    private static let dateFormats = [
        "EEE, dd MMM yyyy HH:mm:ss Z",
        "EEE, dd MMM yyyy HH:mm:ss zzz",
        "yyyy-MM-dd'T'HH:mm:ssZ"
    ]

    func parse(data: Data) -> [NewsItem] {
        let parser = XMLParser(data: data)
        parser.delegate = self
        parser.parse()
        return items
    }

    func parser(_ parser: XMLParser, didStartElement name: String,
                namespaceURI: String?, qualifiedName: String?,
                attributes: [String: String] = [:]) {
        currentElement = name
        if name == "item" {
            insideItem = true
            currentTitle = ""; currentLink = ""; currentDate = ""
        }
    }

    func parser(_ parser: XMLParser, foundCharacters string: String) {
        if insideItem {
            switch currentElement {
            case "title":   currentTitle += string
            case "link":    currentLink += string
            case "pubDate": currentDate += string
            default: break
            }
        } else if currentElement == "title", channelTitle.isEmpty {
            channelTitle += string.trimmingCharacters(in: .whitespacesAndNewlines)
        }
    }

    func parser(_ parser: XMLParser, didEndElement name: String,
                namespaceURI: String?, qualifiedName: String?) {
        currentElement = ""
        guard name == "item" else { return }
        insideItem = false

        let title = currentTitle.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !title.isEmpty else { return }
        items.append(NewsItem(
            title: title,
            link: currentLink.trimmingCharacters(in: .whitespacesAndNewlines),
            date: Self.parseDate(currentDate.trimmingCharacters(in: .whitespacesAndNewlines)),
            source: channelTitle.isEmpty ? "Feed" : channelTitle))
    }

    private static func parseDate(_ text: String) -> Date? {
        guard !text.isEmpty else { return nil }
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        for format in dateFormats {
            formatter.dateFormat = format
            if let date = formatter.date(from: text) { return date }
        }
        return nil
    }
}

// MARK: - Optional AI digest (Anthropic API)

enum NewsSummarizer {

    static func digest(items: [NewsItem], apiKey: String) async -> String? {
        let headlines = items.prefix(40)
            .map { "- [\($0.source)] \($0.title)" }
            .joined(separator: "\n")

        let prompt = """
        Here are today's news headlines from several outlets. Write a concise \
        digest of the day's news in 4-6 short paragraphs grouped by theme \
        (world, Finland, economy, etc. as applicable). Plain text only, \
        no markdown headers. Note where outlets cover the same story.

        \(headlines)
        """

        var request = URLRequest(url: URL(string: "https://api.anthropic.com/v1/messages")!)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue(apiKey, forHTTPHeaderField: "x-api-key")
        request.setValue("2023-06-01", forHTTPHeaderField: "anthropic-version")
        request.httpBody = try? JSONSerialization.data(withJSONObject: [
            "model": "claude-haiku-4-5",
            "max_tokens": 1000,
            "messages": [["role": "user", "content": prompt]]
        ])

        guard let (data, response) = try? await URLSession.shared.data(for: request),
              (response as? HTTPURLResponse)?.statusCode == 200,
              let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
              let content = json["content"] as? [[String: Any]]
        else { return nil }

        return content
            .compactMap { $0["text"] as? String }
            .joined(separator: "\n")
            .trimmingCharacters(in: .whitespacesAndNewlines)
    }
}

// MARK: - Report view

struct NewsReportView: View {
    let request: NewsRequest
    @Environment(\.dismiss) private var dismiss

    @State private var items: [NewsItem] = []
    @State private var digest: String?
    @State private var isLoading = true
    @State private var isDigesting = false

    var body: some View {
        VStack(spacing: 0) {
            HStack {
                Label("Today's News", systemImage: "newspaper.fill")
                    .font(.title3.bold())
                Spacer()
                Button("Done") { dismiss() }
                    .keyboardShortcut(.cancelAction)
            }
            .padding(16)

            Divider()

            if isLoading {
                Spacer()
                ProgressView("Fetching headlines…")
                Spacer()
            } else if items.isEmpty {
                Spacer()
                Text("Couldn't load any headlines — check the feed URLs and your connection.")
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
                    .padding(40)
                Spacer()
            } else {
                content
            }
        }
        .frame(width: 560, height: 620)
        .task { await load() }
    }

    private var content: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                if request.apiKey != nil {
                    VStack(alignment: .leading, spacing: 8) {
                        Label("Digest", systemImage: "sparkles")
                            .font(.headline)
                        if isDigesting {
                            HStack(spacing: 8) {
                                ProgressView().controlSize(.small)
                                Text("Summarising the day…")
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                            }
                        } else if let digest {
                            Text(digest)
                                .font(.callout)
                                .textSelection(.enabled)
                        } else {
                            Text("Digest unavailable (check the API key).")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                    }
                    .padding(14)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 12))
                }

                ForEach(groupedSources, id: \.self) { source in
                    VStack(alignment: .leading, spacing: 6) {
                        Text(source)
                            .font(.headline)
                        ForEach(items.filter { $0.source == source }.prefix(10)) { item in
                            headlineRow(item)
                        }
                    }
                }
            }
            .padding(16)
        }
    }

    private var groupedSources: [String] {
        var seen: [String] = []
        for item in items where !seen.contains(item.source) {
            seen.append(item.source)
        }
        return seen
    }

    private func headlineRow(_ item: NewsItem) -> some View {
        HStack(alignment: .top, spacing: 8) {
            Circle()
                .fill(.tertiary)
                .frame(width: 4, height: 4)
                .padding(.top, 6)
            VStack(alignment: .leading, spacing: 1) {
                if let url = URL(string: item.link), !item.link.isEmpty {
                    Link(item.title, destination: url)
                        .font(.system(size: 12))
                        .foregroundStyle(.primary)
                } else {
                    Text(item.title)
                        .font(.system(size: 12))
                }
                if let date = item.date {
                    Text(date.formatted(date: .omitted, time: .shortened))
                        .font(.system(size: 10))
                        .foregroundStyle(.tertiary)
                }
            }
        }
    }

    private func load() async {
        items = await NewsService.fetchHeadlines(feeds: request.feeds)
        isLoading = false
        if let key = request.apiKey, !items.isEmpty {
            isDigesting = true
            digest = await NewsSummarizer.digest(items: items, apiKey: key)
            isDigesting = false
        }
    }
}
