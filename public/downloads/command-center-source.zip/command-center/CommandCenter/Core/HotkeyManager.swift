//
//  HotkeyManager.swift
//  Command Center
//
//  System-wide hotkeys via the Carbon RegisterEventHotKey API — still the
//  sanctioned way to get true global shortcuts without the Accessibility
//  permission an CGEventTap would require.
//
//  One "summon" hotkey toggles the main window; any number of tile hotkeys
//  trigger their tile's action from anywhere in macOS.
//

import Foundation
import Carbon.HIToolbox
import AppKit

final class HotkeyManager {

    static let shared = HotkeyManager()

    /// Fired when the summon hotkey is pressed.
    var onSummon: (() -> Void)?
    /// Fired with the tile's UUID when a tile hotkey is pressed.
    var onTileHotkey: ((UUID) -> Void)?

    // Carbon bookkeeping.
    private var eventHandler: EventHandlerRef?
    private var hotkeyRefs: [UInt32: EventHotKeyRef] = [:]   // carbon id → ref
    private var tileForCarbonID: [UInt32: UUID] = [:]
    private var nextCarbonID: UInt32 = 1
    private let summonCarbonID: UInt32 = 0xC0FFEE

    private init() { installHandler() }

    // MARK: Registration

    func registerSummon(_ shortcut: KeyShortcut?) {
        unregister(carbonID: summonCarbonID)
        guard let shortcut else { return }
        register(shortcut, carbonID: summonCarbonID)
    }

    /// Replace all tile hotkeys with the given map in one pass.
    func registerTileHotkeys(_ shortcuts: [(UUID, KeyShortcut)]) {
        for id in tileForCarbonID.keys { unregister(carbonID: id) }
        tileForCarbonID.removeAll()

        for (tileID, shortcut) in shortcuts {
            let carbonID = nextCarbonID
            nextCarbonID += 1
            tileForCarbonID[carbonID] = tileID
            register(shortcut, carbonID: carbonID)
        }
    }

    private func register(_ shortcut: KeyShortcut, carbonID: UInt32) {
        var ref: EventHotKeyRef?
        let hotkeyID = EventHotKeyID(signature: OSType(0x43_43_4B_59) /* 'CCKY' */,
                                     id: carbonID)
        let status = RegisterEventHotKey(shortcut.keyCode,
                                         shortcut.modifiers,
                                         hotkeyID,
                                         GetApplicationEventTarget(),
                                         0,
                                         &ref)
        if status == noErr, let ref {
            hotkeyRefs[carbonID] = ref
        } else {
            NSLog("Hotkey registration failed (\(shortcut.display)) status=\(status)")
        }
    }

    private func unregister(carbonID: UInt32) {
        if let ref = hotkeyRefs.removeValue(forKey: carbonID) {
            UnregisterEventHotKey(ref)
        }
    }

    // MARK: Carbon event handler

    private func installHandler() {
        var eventType = EventTypeSpec(eventClass: OSType(kEventClassKeyboard),
                                      eventKind: UInt32(kEventHotKeyPressed))
        let selfPointer = Unmanaged.passUnretained(self).toOpaque()

        InstallEventHandler(GetApplicationEventTarget(), { _, event, userData in
            guard let event, let userData else { return noErr }
            var hotkeyID = EventHotKeyID()
            GetEventParameter(event,
                              EventParamName(kEventParamDirectObject),
                              EventParamType(typeEventHotKeyID),
                              nil,
                              MemoryLayout<EventHotKeyID>.size,
                              nil,
                              &hotkeyID)
            let manager = Unmanaged<HotkeyManager>.fromOpaque(userData).takeUnretainedValue()
            manager.handlePress(carbonID: hotkeyID.id)
            return noErr
        }, 1, &eventType, selfPointer, &eventHandler)
    }

    private func handlePress(carbonID: UInt32) {
        DispatchQueue.main.async { [self] in
            if carbonID == summonCarbonID {
                onSummon?()
            } else if let tileID = tileForCarbonID[carbonID] {
                onTileHotkey?(tileID)
            }
        }
    }
}

// MARK: - NSEvent → KeyShortcut conversion (used by the recorder UI)

extension KeyShortcut {

    /// Build a shortcut from a keyDown NSEvent, or nil if no modifier is held
    /// (bare keys would hijack normal typing system-wide).
    static func from(event: NSEvent) -> KeyShortcut? {
        let flags = event.modifierFlags.intersection(.deviceIndependentFlagsMask)
        guard !flags.isDisjoint(with: [.command, .option, .control, .shift]) else { return nil }

        var carbonModifiers: UInt32 = 0
        if flags.contains(.command) { carbonModifiers |= UInt32(cmdKey) }
        if flags.contains(.option)  { carbonModifiers |= UInt32(optionKey) }
        if flags.contains(.control) { carbonModifiers |= UInt32(controlKey) }
        if flags.contains(.shift)   { carbonModifiers |= UInt32(shiftKey) }

        var display = ""
        if flags.contains(.control) { display += "⌃" }
        if flags.contains(.option)  { display += "⌥" }
        if flags.contains(.shift)   { display += "⇧" }
        if flags.contains(.command) { display += "⌘" }
        display += Self.keyName(for: event)

        return KeyShortcut(keyCode: UInt32(event.keyCode),
                           modifiers: carbonModifiers,
                           display: display)
    }

    private static func keyName(for event: NSEvent) -> String {
        switch Int(event.keyCode) {
        case kVK_Space:  return "Space"
        case kVK_Return: return "↩"
        case kVK_Escape: return "⎋"
        case kVK_Tab:    return "⇥"
        case kVK_Delete: return "⌫"
        default:
            return event.charactersIgnoringModifiers?.uppercased() ?? "?"
        }
    }
}
