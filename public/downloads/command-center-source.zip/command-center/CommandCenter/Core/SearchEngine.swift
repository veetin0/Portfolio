//
//  SearchEngine.swift
//  Command Center
//
//  Spotlight-style unified search across three providers:
//    • Applications — scanned once from the standard app folders
//    • Files        — live Spotlight metadata query (NSMetadataQuery)
//    • Actions      — the user's own tiles across all profiles
//
//  Results are merged, ranked (prefix > word-start > substring) and
//  published for keyboard-first navigation in the UI.
//

import Foundation
import AppKit
import Combine

// MARK: - Result model

struct SearchResult: Identifiable, Hashable {
    enum Kind: Int { case action = 0, app = 1, file = 2 }   // sort priority

    let id = UUID()
    let kind: Kind
    let title: String
    let subtitle: String
    let symbol: String
    /// What to do when the result is chosen.
    let action: TileAction
    /// For apps/files: used to fetch the real Finder icon.
    let path: String?

    var icon: NSImage? {
        guard let path else { return nil }
        return NSWorkspace.shared.icon(forFile: path)
    }
}

// MARK: - Engine

@MainActor
final class SearchEngine: ObservableObject {

    @Published var query: String = ""
    @Published private(set) var results: [SearchResult] = []

    /// Provided by the view model so tiles are searchable.
    var tilesProvider: () -> [(tile: Tile, context: String)] = { [] }

    private var installedApps: [(name: String, path: String)] = []
    private var metadataQuery: NSMetadataQuery?
    private var cancellables: Set<AnyCancellable> = []

    init() {
        scanApplications()

        // Debounce keystrokes, then run all providers.
        $query
            .debounce(for: .milliseconds(120), scheduler: DispatchQueue.main)
            .removeDuplicates()
            .sink { [weak self] text in self?.search(text) }
            .store(in: &cancellables)

        NotificationCenter.default.publisher(
            for: .NSMetadataQueryDidFinishGathering)
            .sink { [weak self] note in self?.harvestFileResults(note) }
            .store(in: &cancellables)
    }

    // MARK: Applications provider

    private func scanApplications() {
        Task.detached(priority: .utility) {
            let folders = [
                "/Applications",
                "/System/Applications",
                "/System/Applications/Utilities",
                ("~/Applications" as NSString).expandingTildeInPath
            ]
            var found: [(String, String)] = []
            let fm = FileManager.default
            for folder in folders {
                guard let items = try? fm.contentsOfDirectory(atPath: folder) else { continue }
                for item in items where item.hasSuffix(".app") {
                    let name = (item as NSString).deletingPathExtension
                    found.append((name, "\(folder)/\(item)"))
                }
            }
            let apps = found.sorted { $0.0.localizedCaseInsensitiveCompare($1.0) == .orderedAscending }
            await MainActor.run { self.installedApps = apps }
        }
    }

    // MARK: Search

    private func search(_ text: String) {
        let trimmed = text.trimmingCharacters(in: .whitespaces)
        guard trimmed.count >= 1 else {
            results = []
            stopFileQuery()
            return
        }

        var merged: [SearchResult] = []

        // 1. Custom actions (highest priority — they're the user's own).
        for (tile, context) in tilesProvider() where tile.label.fuzzyMatches(trimmed) {
            merged.append(SearchResult(
                kind: .action,
                title: tile.label,
                subtitle: "Action · \(context)",
                symbol: tile.iconIsImage ? "bolt.fill" : tile.icon,
                action: tile.action,
                path: nil))
        }

        // 2. Installed apps.
        for app in installedApps where app.name.fuzzyMatches(trimmed) {
            merged.append(SearchResult(
                kind: .app,
                title: app.name,
                subtitle: "Application",
                symbol: "app.fill",
                action: TileAction(type: .launchApp, payload: app.path),
                path: app.path))
        }

        results = rank(merged, query: trimmed)

        // 3. Files arrive asynchronously via Spotlight.
        startFileQuery(trimmed)
    }

    /// Prefix matches beat word-start matches beat plain substrings;
    /// ties break by kind (actions > apps > files) then title length.
    private func rank(_ items: [SearchResult], query: String) -> [SearchResult] {
        func score(_ result: SearchResult) -> Int {
            let title = result.title.lowercased()
            let q = query.lowercased()
            if title.hasPrefix(q) { return 0 }
            if title.split(separator: " ").contains(where: { $0.hasPrefix(q) }) { return 1 }
            return 2
        }
        return items.sorted {
            let (a, b) = (score($0), score($1))
            if a != b { return a < b }
            if $0.kind != $1.kind { return $0.kind.rawValue < $1.kind.rawValue }
            return $0.title.count < $1.title.count
        }
    }

    // MARK: Files provider (Spotlight)

    private func startFileQuery(_ text: String) {
        stopFileQuery()
        guard text.count >= 3 else { return }   // avoid noisy 1–2 char file spam

        let query = NSMetadataQuery()
        query.searchScopes = [NSMetadataQueryUserHomeScope]
        query.predicate = NSPredicate(
            format: "kMDItemFSName CONTAINS[cd] %@", text)
        query.sortDescriptors = [
            NSSortDescriptor(key: NSMetadataItemFSContentChangeDateKey, ascending: false)
        ]
        metadataQuery = query
        query.start()
    }

    private func stopFileQuery() {
        metadataQuery?.stop()
        metadataQuery = nil
    }

    private func harvestFileResults(_ note: Notification) {
        guard let query = note.object as? NSMetadataQuery,
              query === metadataQuery else { return }
        query.disableUpdates()
        defer { query.enableUpdates() }

        let fileResults: [SearchResult] = query.results
            .prefix(8)
            .compactMap { $0 as? NSMetadataItem }
            .compactMap { item in
                guard let path = item.value(forAttribute: NSMetadataItemPathKey) as? String,
                      let name = item.value(forAttribute: NSMetadataItemFSNameKey) as? String
                else { return nil }
                return SearchResult(
                    kind: .file,
                    title: name,
                    subtitle: (path as NSString).deletingLastPathComponent
                        .replacingOccurrences(of: NSHomeDirectory(), with: "~"),
                    symbol: "doc",
                    action: TileAction(type: .openPath, payload: path),
                    path: path)
            }

        // Append after existing action/app results, avoiding duplicates.
        results = rank(results.filter { $0.kind != .file } + fileResults,
                       query: self.query)
    }
}

// MARK: - Matching helper

extension String {
    /// Case-insensitive subsequence match — "vsc" matches "Visual Studio Code".
    func fuzzyMatches(_ query: String) -> Bool {
        let target = lowercased()
        if target.contains(query.lowercased()) { return true }
        var iterator = target.makeIterator()
        for character in query.lowercased() {
            var found = false
            while let next = iterator.next() {
                if next == character { found = true; break }
            }
            if !found { return false }
        }
        return true
    }
}
