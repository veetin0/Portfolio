//
//  ActionRegistry.swift
//  Command Center
//
//  The extensibility backbone. Executors are small plugins keyed by
//  ActionType; the rest of the app only ever calls `ActionRegistry.run(_:)`.
//
//  To add a new action type (e.g. "HTTP Request"):
//    1. Add a case to ActionType.
//    2. Implement `ActionExecutor`.
//    3. Register it below (or from anywhere at startup).
//

import Foundation

/// Result of running an action — surfaced to the UI as a transient toast.
struct ActionResult {
    var success: Bool
    var message: String?

    static let ok = ActionResult(success: true, message: nil)
    static func failure(_ message: String) -> ActionResult {
        ActionResult(success: false, message: message)
    }
}

/// A plugin that knows how to execute one kind of action.
protocol ActionExecutor {
    var type: ActionType { get }
    func execute(_ action: TileAction) async -> ActionResult
}

/// Central registry + dispatcher.
@MainActor
final class ActionRegistry {

    static let shared = ActionRegistry()

    private var executors: [ActionType: ActionExecutor] = [:]

    private init() { registerBuiltIns() }

    func register(_ executor: ActionExecutor) {
        executors[executor.type] = executor
    }

    private func registerBuiltIns() {
        register(LaunchAppExecutor())
        register(ShellCommandExecutor())
        register(OpenPathExecutor())
        register(AppleScriptExecutor())
        register(OpenURLExecutor())
        register(WorkflowExecutor())   // recursively dispatches back into the registry
        register(NewsSummaryExecutor())
    }

    /// Dispatch an action to its executor.
    func run(_ action: TileAction) async -> ActionResult {
        guard let executor = executors[action.type] else {
            return .failure("No executor registered for \(action.type.rawValue)")
        }
        return await executor.execute(action)
    }
}
