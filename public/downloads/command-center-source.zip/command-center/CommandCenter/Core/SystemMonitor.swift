//
//  SystemMonitor.swift
//  Command Center
//
//  Publishes live system metrics every 2 seconds:
//    • Battery — IOKit power sources (IOPSCopyPowerSourcesInfo)
//    • CPU     — Mach host_processor_info tick deltas
//    • Memory  — host_statistics64 (vm_statistics64)
//    • Disk    — volumeAvailableCapacityForImportantUsage
//    • Network — Network framework NWPathMonitor
//

import Foundation
import Combine
import IOKit.ps
import Network

@MainActor
final class SystemMonitor: ObservableObject {

    // MARK: Published metrics

    @Published var batteryPercent: Int?          // nil on desktops without battery
    @Published var batteryTimeRemaining: String? // "3:42 remaining", "Charging"…
    @Published var isCharging = false

    @Published var cpuUsage: Double = 0          // 0…1
    @Published var memoryUsedBytes: UInt64 = 0
    @Published var memoryTotalBytes: UInt64 = ProcessInfo.processInfo.physicalMemory

    @Published var diskFreeBytes: Int64 = 0
    @Published var diskTotalBytes: Int64 = 0

    @Published var networkConnected = false
    @Published var networkInterface: String = "Offline"

    // MARK: Private state

    private var timer: AnyCancellable?
    private let pathMonitor = NWPathMonitor()
    private var previousCPUTicks: (used: UInt64, total: UInt64)?

    init() {
        startNetworkMonitor()
        refresh()
        // Combine timer drives the 2-second refresh cadence.
        timer = Timer.publish(every: 2, on: .main, in: .common)
            .autoconnect()
            .sink { [weak self] _ in self?.refresh() }
    }

    deinit { pathMonitor.cancel() }

    // MARK: Refresh cycle

    private func refresh() {
        refreshBattery()
        refreshCPU()
        refreshMemory()
        refreshDisk()
    }

    // MARK: Battery (IOKit)

    private func refreshBattery() {
        guard let snapshot = IOPSCopyPowerSourcesInfo()?.takeRetainedValue(),
              let sources = IOPSCopyPowerSourcesList(snapshot)?.takeRetainedValue() as? [CFTypeRef],
              let source = sources.first,
              let info = IOPSGetPowerSourceDescription(snapshot, source)?
                  .takeUnretainedValue() as? [String: Any]
        else {
            batteryPercent = nil
            batteryTimeRemaining = nil
            return
        }

        let current = info[kIOPSCurrentCapacityKey] as? Int ?? 0
        let max = info[kIOPSMaxCapacityKey] as? Int ?? 100
        batteryPercent = max > 0 ? Int((Double(current) / Double(max)) * 100) : nil

        isCharging = (info[kIOPSIsChargingKey] as? Bool) ?? false

        if isCharging {
            if let minutes = info[kIOPSTimeToFullChargeKey] as? Int, minutes > 0 {
                batteryTimeRemaining = "\(format(minutes: minutes)) to full"
            } else {
                batteryTimeRemaining = "Charging"
            }
        } else if let minutes = info[kIOPSTimeToEmptyKey] as? Int, minutes > 0 {
            batteryTimeRemaining = "\(format(minutes: minutes)) remaining"
        } else {
            batteryTimeRemaining = nil // macOS is still estimating
        }
    }

    private func format(minutes: Int) -> String {
        String(format: "%d:%02d", minutes / 60, minutes % 60)
    }

    // MARK: CPU (Mach)

    /// CPU usage is a delta between two tick snapshots, so the first reading
    /// after launch is 0 and every subsequent one is the true 2s average.
    private func refreshCPU() {
        var cpuCount: natural_t = 0
        var infoArray: processor_info_array_t?
        var infoCount: mach_msg_type_number_t = 0

        let result = host_processor_info(mach_host_self(),
                                         PROCESSOR_CPU_LOAD_INFO,
                                         &cpuCount,
                                         &infoArray,
                                         &infoCount)
        guard result == KERN_SUCCESS, let infoArray else { return }
        defer {
            vm_deallocate(mach_task_self_,
                          vm_address_t(bitPattern: infoArray),
                          vm_size_t(infoCount) * vm_size_t(MemoryLayout<integer_t>.size))
        }

        var used: UInt64 = 0
        var total: UInt64 = 0
        for cpu in 0..<Int32(cpuCount) {
            let offset = Int(cpu) * Int(CPU_STATE_MAX)
            let user   = UInt64(infoArray[offset + Int(CPU_STATE_USER)])
            let system = UInt64(infoArray[offset + Int(CPU_STATE_SYSTEM)])
            let nice   = UInt64(infoArray[offset + Int(CPU_STATE_NICE)])
            let idle   = UInt64(infoArray[offset + Int(CPU_STATE_IDLE)])
            used  += user + system + nice
            total += user + system + nice + idle
        }

        if let previous = previousCPUTicks {
            let deltaUsed = used &- previous.used
            let deltaTotal = total &- previous.total
            if deltaTotal > 0 {
                cpuUsage = Double(deltaUsed) / Double(deltaTotal)
            }
        }
        previousCPUTicks = (used, total)
    }

    // MARK: Memory (Mach)

    private func refreshMemory() {
        var stats = vm_statistics64()
        var count = mach_msg_type_number_t(
            MemoryLayout<vm_statistics64_data_t>.size / MemoryLayout<integer_t>.size)

        let result = withUnsafeMutablePointer(to: &stats) { pointer in
            pointer.withMemoryRebound(to: integer_t.self, capacity: Int(count)) {
                host_statistics64(mach_host_self(), HOST_VM_INFO64, $0, &count)
            }
        }
        guard result == KERN_SUCCESS else { return }

        let pageSize = UInt64(vm_kernel_page_size)
        // "Used" as Activity Monitor roughly shows it:
        // active + wired + compressed pages.
        let usedPages = UInt64(stats.active_count)
                      + UInt64(stats.wire_count)
                      + UInt64(stats.compressor_page_count)
        memoryUsedBytes = usedPages * pageSize
    }

    // MARK: Disk

    private func refreshDisk() {
        let home = URL(fileURLWithPath: NSHomeDirectory())
        if let values = try? home.resourceValues(forKeys: [
            .volumeAvailableCapacityForImportantUsageKey,
            .volumeTotalCapacityKey
        ]) {
            diskFreeBytes = values.volumeAvailableCapacityForImportantUsage ?? 0
            diskTotalBytes = Int64(values.volumeTotalCapacity ?? 0)
        }
    }

    // MARK: Network

    private func startNetworkMonitor() {
        pathMonitor.pathUpdateHandler = { [weak self] path in
            Task { @MainActor in
                guard let self else { return }
                self.networkConnected = (path.status == .satisfied)
                if path.usesInterfaceType(.wifi) {
                    self.networkInterface = "Wi-Fi"
                } else if path.usesInterfaceType(.wiredEthernet) {
                    self.networkInterface = "Ethernet"
                } else if path.usesInterfaceType(.cellular) {
                    self.networkInterface = "Cellular"
                } else if path.status == .satisfied {
                    self.networkInterface = "Connected"
                } else {
                    self.networkInterface = "Offline"
                }
            }
        }
        pathMonitor.start(queue: DispatchQueue(label: "cc.network"))
    }
}
