//
//  CommandCenterApp.swift
//  Command Center
//
//  App entry point. Owns the single shared AppViewModel, the main
//  dashboard window, and the menu-bar mini version.
//
//  Requires macOS 14+ (MenuBarExtra, onKeyPress, NavigationSplitView).
//

import SwiftUI
import AppKit

@main
struct CommandCenterApp: App {

    /// Single source of truth for the whole app.
    @StateObject private var viewModel = AppViewModel()

    /// Bridges AppKit lifecycle events (activation, hotkey window toggling).
    @NSApplicationDelegateAdaptor(AppDelegate.self) private var appDelegate

    var body: some Scene {
        // ── Main dashboard window ────────────────────────────────────────
        Window("Command Center", id: "main") {
            DashboardView()
                .environmentObject(viewModel)
                .frame(minWidth: 860, minHeight: 560)
                .onAppear { appDelegate.viewModel = viewModel }
        }
        .windowStyle(.hiddenTitleBar)
        .windowToolbarStyle(.unifiedCompact)
        .defaultSize(width: 1000, height: 660)
        .commands {
            CommandGroup(after: .newItem) {
                Button("New Tile…") { viewModel.beginAddingTile() }
                    .keyboardShortcut("n", modifiers: [.command])
                Button("Focus Search") { viewModel.focusSearchRequested.send() }
                    .keyboardShortcut("f", modifiers: [.command])
            }
        }

        // ── Menu-bar mini version ────────────────────────────────────────
        MenuBarExtra {
            MenuBarView()
                .environmentObject(viewModel)
        } label: {
            Image(systemName: "square.grid.2x2.fill")
        }
        .menuBarExtraStyle(.window)

        Settings {
            SettingsView()
                .environmentObject(viewModel)
        }
    }
}

// MARK: - AppDelegate

/// Handles global-hotkey → window toggling and app activation policy.
final class AppDelegate: NSObject, NSApplicationDelegate {

    weak var viewModel: AppViewModel?

    func applicationDidFinishLaunching(_ notification: Notification) {
        // Register the global "summon" hotkey (default ⌥Space) plus any
        // per-tile shortcuts stored in the configuration.
        HotkeyManager.shared.onSummon = { [weak self] in
            self?.toggleMainWindow()
        }
        HotkeyManager.shared.onTileHotkey = { [weak self] tileID in
            self?.viewModel?.runTile(withID: tileID)
        }
        // The view model registers concrete hotkeys once config is loaded.
    }

    /// Show + focus the main window, or hide it if it is already frontmost —
    /// the classic Spotlight/Raycast toggle behaviour.
    func toggleMainWindow() {
        guard let window = NSApp.windows.first(where: { $0.identifier?.rawValue == "main" })
                ?? NSApp.windows.first(where: { $0.title == "Command Center" }) else {
            NSApp.activate(ignoringOtherApps: true)
            return
        }
        if window.isKeyWindow {
            window.orderOut(nil)
            NSApp.hide(nil)
        } else {
            NSApp.activate(ignoringOtherApps: true)
            window.makeKeyAndOrderFront(nil)
            viewModel?.focusSearchRequested.send()
        }
    }

    func applicationShouldTerminateAfterLastWindowClosed(_ sender: NSApplication) -> Bool {
        false // Keep running in the menu bar.
    }
}
