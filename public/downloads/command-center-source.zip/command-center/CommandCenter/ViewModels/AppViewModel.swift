//
//  AppViewModel.swift
//  Command Center
//
//  Single observable source of truth. Owns:
//    • the persisted AppConfig (auto-saved, debounced)
//    • profile / page selection
//    • tile CRUD + drag-reorder
//    • hotkey (re)registration
//    • action execution + result toasts
//

import Foundation
import SwiftUI
import Combine

@MainActor
final class AppViewModel: ObservableObject {

    // MARK: Persisted state

    @Published var config: AppConfig {
        didSet {
            saveSubject.send()
            FeedbackManager.shared.isEnabled = config.feedbackEnabled
        }
    }

    // MARK: UI state

    @Published var selectedPageID: UUID?
    @Published var editingTile: Tile?          // non-nil → edit sheet is shown
    @Published var isAddingTile = false
    @Published var toast: Toast?
    @Published var newsRequest: NewsRequest?
    

    /// Views subscribe to focus the search field (⌘F / summon hotkey).
    let focusSearchRequested = PassthroughSubject<Void, Never>()

    let systemMonitor = SystemMonitor()
    let searchEngine = SearchEngine()

    private let saveSubject = PassthroughSubject<Void, Never>()
    private var cancellables: Set<AnyCancellable> = []

    struct Toast: Identifiable, Equatable {
        let id = UUID()
        let message: String
        let isError: Bool
    }

    /// One row in the activity log (in-memory, capped at 100 entries).
    struct ActivityEntry: Identifiable {
        let id = UUID()
        let date = Date()
        let label: String
        let success: Bool
        let message: String?
    }

    @Published private(set) var activityLog: [ActivityEntry] = []

    func clearActivityLog() { activityLog.removeAll() }

    // MARK: Init

    init() {
        config = ConfigStore.shared.load()
        selectedPageID = activeProfile.pages.first?.id
        FeedbackManager.shared.isEnabled = config.feedbackEnabled

        // Debounced autosave — every mutation persists 0.5s after it settles.
        saveSubject
            .debounce(for: .milliseconds(500), scheduler: DispatchQueue.main)
            .sink { [weak self] in
                guard let self else { return }
                ConfigStore.shared.save(self.config)
            }
            .store(in: &cancellables)

        // Feed tiles to the search engine (all profiles, so search spans everything).
        searchEngine.tilesProvider = { [weak self] in
            guard let self else { return [] }
            return self.config.profiles.flatMap { profile in
                profile.pages.flatMap { page in
                    page.tiles.map { ($0, "\(profile.name) › \(page.name)") }
                }
            }
        }
        NewsPresenter.handler = { [weak self] request in
            self?.newsRequest = request
        }

        syncHotkeys()
    }

    // MARK: Profile / page accessors

    var activeProfile: Profile {
        config.profiles.first { $0.id == config.activeProfileID }
            ?? config.profiles.first
            ?? Profile()
    }

    var activeProfileIndex: Int? {
        config.profiles.firstIndex { $0.id == config.activeProfileID }
    }

    var selectedPage: Page? {
        activeProfile.pages.first { $0.id == selectedPageID }
            ?? activeProfile.pages.first
    }

    func selectProfile(_ id: UUID) {
        config.activeProfileID = id
        selectedPageID = activeProfile.pages.first?.id
    }

    func addProfile(named name: String) {
        var profile = Profile(name: name)
        profile.symbol = "person.crop.circle.badge.plus"
        config.profiles.append(profile)
        selectProfile(profile.id)
    }

    func addPage(named name: String) {
        guard let index = activeProfileIndex else { return }
        let page = Page(name: name)
        config.profiles[index].pages.append(page)
        selectedPageID = page.id
    }

    func deletePage(_ id: UUID) {
        guard let index = activeProfileIndex,
              config.profiles[index].pages.count > 1 else { return }
        config.profiles[index].pages.removeAll { $0.id == id }
        selectedPageID = config.profiles[index].pages.first?.id
    }

    // MARK: Tile CRUD

    func beginAddingTile() {
        editingTile = Tile()
        isAddingTile = true
    }

    func beginEditing(_ tile: Tile) {
        editingTile = tile
        isAddingTile = false
    }

    /// Insert or update the tile in the selected page.
    func commit(_ tile: Tile) {
        guard let profileIndex = activeProfileIndex,
              let pageIndex = config.profiles[profileIndex].pages
                  .firstIndex(where: { $0.id == selectedPage?.id }) else { return }

        var tiles = config.profiles[profileIndex].pages[pageIndex].tiles
        if let existing = tiles.firstIndex(where: { $0.id == tile.id }) {
            tiles[existing] = tile
        } else {
            tiles.append(tile)
        }
        config.profiles[profileIndex].pages[pageIndex].tiles = tiles
        editingTile = nil
        syncHotkeys()
    }

    func deleteTile(_ id: UUID) {
        guard let profileIndex = activeProfileIndex else { return }
        for pageIndex in config.profiles[profileIndex].pages.indices {
            config.profiles[profileIndex].pages[pageIndex].tiles.removeAll { $0.id == id }
        }
        syncHotkeys()
    }

    /// Drag & drop reorder within the current page.
    func moveTile(withID draggedID: UUID, before targetID: UUID) {
        guard let profileIndex = activeProfileIndex,
              let pageIndex = config.profiles[profileIndex].pages
                  .firstIndex(where: { $0.id == selectedPage?.id }) else { return }

        var tiles = config.profiles[profileIndex].pages[pageIndex].tiles
        guard let from = tiles.firstIndex(where: { $0.id == draggedID }),
              let to = tiles.firstIndex(where: { $0.id == targetID }),
              from != to else { return }

        withAnimation(.spring(response: 0.3, dampingFraction: 0.8)) {
            tiles.move(fromOffsets: IndexSet(integer: from),
                       toOffset: to > from ? to + 1 : to)
            config.profiles[profileIndex].pages[pageIndex].tiles = tiles
        }
    }

    // MARK: Running actions

    func run(_ tile: Tile) {
        run(tile.action, label: tile.label)
    }

    func runTile(withID id: UUID) {
        for profile in config.profiles {
            for page in profile.pages {
                if let tile = page.tiles.first(where: { $0.id == id }) {
                    run(tile)
                    return
                }
            }
        }
    }

    func run(_ action: TileAction, label: String) {
        FeedbackManager.shared.tap()
        Task {
            let result = await ActionRegistry.shared.run(action)

            // Feedback + log + toast.
            result.success ? FeedbackManager.shared.success()
                           : FeedbackManager.shared.error()
            activityLog.insert(
                ActivityEntry(label: label,
                              success: result.success,
                              message: result.message),
                at: 0)
            if activityLog.count > 100 { activityLog.removeLast() }

            show(result.success
                 ? Toast(message: "\(label) ✓", isError: false)
                 : Toast(message: result.message ?? "\(label) failed", isError: true))
        }
    }

    private func show(_ toast: Toast) {
        withAnimation(.easeOut(duration: 0.2)) { self.toast = toast }
        Task {
            try? await Task.sleep(nanoseconds: 2_500_000_000)
            if self.toast?.id == toast.id {
                withAnimation(.easeIn(duration: 0.2)) { self.toast = nil }
            }
        }
    }

    // MARK: Hotkeys

    /// Re-register the summon hotkey and every tile shortcut.
    func syncHotkeys() {
        HotkeyManager.shared.registerSummon(config.summonShortcut)
        let tileShortcuts: [(UUID, KeyShortcut)] = config.profiles
            .flatMap(\.pages)
            .flatMap(\.tiles)
            .compactMap { tile in tile.shortcut.map { (tile.id, $0) } }
        HotkeyManager.shared.registerTileHotkeys(tileShortcuts)
    }
}
