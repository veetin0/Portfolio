//
//  ConfigStore.swift
//  Command Center
//
//  Loads and saves the whole AppConfig as pretty-printed JSON in
//  ~/Library/Application Support/CommandCenter/config.json.
//
//  JSON (over Core Data) keeps the config human-readable, diffable,
//  and trivially exportable/importable.
//

import Foundation
import Combine

final class ConfigStore {

    static let shared = ConfigStore()

    private let fileURL: URL
    private let encoder: JSONEncoder
    private let decoder = JSONDecoder()
    private let queue = DispatchQueue(label: "cc.configstore", qos: .utility)

    private init() {
        let support = FileManager.default.urls(for: .applicationSupportDirectory,
                                               in: .userDomainMask).first!
        let dir = support.appendingPathComponent("CommandCenter", isDirectory: true)
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        fileURL = dir.appendingPathComponent("config.json")

        encoder = JSONEncoder()
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
    }

    /// Load the saved config, or create + persist the sample config on first run.
    func load() -> AppConfig {
        if let data = try? Data(contentsOf: fileURL),
           let config = try? decoder.decode(AppConfig.self, from: data) {
            return config
        }
        let fresh = AppConfig.makeDefault()
        save(fresh)
        return fresh
    }

    /// Atomic write off the main thread.
    func save(_ config: AppConfig) {
        queue.async { [fileURL, encoder] in
            do {
                let data = try encoder.encode(config)
                try data.write(to: fileURL, options: .atomic)
            } catch {
                NSLog("ConfigStore save failed: \(error)")
            }
        }
    }
}
