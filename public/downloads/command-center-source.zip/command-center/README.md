# Command Center

A customizable macOS launcher + dashboard: Stream Deck-style tiles, Spotlight-style search, and a live system monitor — built entirely in Swift + SwiftUI.

**Requires:** macOS 14 Sonoma or later (uses `onKeyPress` for arrow-key navigation), Xcode 15+.

---

## Features

- **Tile dashboard** — grid of buttons with custom labels, SF Symbols or image icons, accent colors, hover/press animations, and drag & drop reordering (Launchpad-style live shuffle).
- **Actions** — launch apps, run shell commands (headless or visibly in Terminal), open files/folders, execute AppleScript, open URLs (including `owner/repo` GitHub shorthand), and multi-step **workflows** that chain any of the above.
- **Profiles & pages** — e.g. a *Work* profile with *Dev* and *Web* pages, plus a *Personal* profile. Switch from the sidebar.
- **Spotlight-style search** — one field searches installed apps, files (real Spotlight via `NSMetadataQuery`), and your own actions. Fully keyboard-driven: type → ↑/↓ → ↩.
- **Global hotkeys** — a summon hotkey (default **⌥Space**) toggles the window from anywhere; every tile can record its own system-wide shortcut.
- **System panel** — battery % + time remaining (IOKit), CPU (Mach tick deltas), memory (vm statistics), disk, and network status, refreshed every 2 s.
- **Menu bar mini version** — quick stats + your six most-used tiles in a popover.
- **Persistence** — everything saves automatically (debounced) to human-readable JSON at `~/Library/Application Support/CommandCenter/config.json`.
- **Dark mode** — native materials throughout; follows the system appearance.

---

## Project structure

```
CommandCenter/
├── project.yml                     # XcodeGen spec (optional shortcut)
├── README.md
└── CommandCenter/
    ├── CommandCenterApp.swift      # @main, windows, MenuBarExtra, AppDelegate
    ├── Models/
    │   ├── Models.swift            # Tile, Page, Profile, TileAction, KeyShortcut, AppConfig
    │   └── SampleData.swift        # First-launch tiles incl. "Code Setup" workflow
    ├── Persistence/
    │   └── ConfigStore.swift       # JSON load/save (atomic, off-main-thread)
    ├── Core/
    │   ├── ActionRegistry.swift    # Plugin registry — the extensibility seam
    │   ├── Executors.swift         # Built-in executors (app/shell/path/script/url/workflow)
    │   ├── HotkeyManager.swift     # Carbon global hotkeys + NSEvent→shortcut conversion
    │   ├── SystemMonitor.swift     # IOKit battery, Mach CPU/RAM, NWPathMonitor, disk
    │   └── SearchEngine.swift      # Unified app/file/action search with ranking
    ├── ViewModels/
    │   └── AppViewModel.swift      # Single source of truth, CRUD, hotkey sync, toasts
    ├── Views/
    │   ├── DashboardView.swift     # Main window layout
    │   ├── TileGridView.swift      # Grid + drag-reorder + TileView
    │   ├── SearchBarView.swift     # Search field + keyboard-navigable results
    │   ├── SystemInfoPanel.swift   # Live metric cards
    │   ├── EditTileSheet.swift     # Tile editor + workflow builder + shortcut recorder
    │   ├── MenuBarView.swift       # Menu-bar popover
    │   └── SettingsView.swift      # Preferences
    └── Resources/
        ├── CommandCenter.entitlements
        └── Info.plist
```

---

## Running in Xcode

### Option A — XcodeGen (fastest)

```bash
brew install xcodegen
cd CommandCenter
xcodegen generate
open CommandCenter.xcodeproj
```

Press **⌘R**.

### Option B — manual project

1. Xcode → **File → New → Project… → macOS → App**. Name it `CommandCenter`, Interface: **SwiftUI**, Language: **Swift**.
2. Delete the generated `ContentView.swift` and `CommandCenterApp.swift`.
3. Drag the `CommandCenter/` source folders (Models, Persistence, Core, ViewModels, Views, and `CommandCenterApp.swift`) into the project navigator. Check **"Copy items if needed"** and add to the app target.
4. **Signing & Capabilities** tab:
   - Remove **App Sandbox** (required for shell commands & AppleScript), *or* keep it and accept that shell/AppleScript actions will be restricted.
   - Add **Hardened Runtime** if you plan to notarize.
   - Set the entitlements file to `Resources/CommandCenter.entitlements`.
5. **Info** tab: add `NSAppleEventsUsageDescription` (string from `Resources/Info.plist`).
6. Set the deployment target to **macOS 14.0**.
7. **⌘R**.

### First run

- Sample **Work** and **Personal** profiles are created automatically, including the **Code Setup** tile (opens VS Code, writes `~/Scratch/scratch.swift` with template code, opens it).
- Press **⌥Space** anywhere to summon/dismiss the window.
- Right-click a tile to edit, run, or delete it. Drag tiles to reorder.
- The first time an AppleScript action targets another app, macOS will show an Automation permission prompt — approve it in **System Settings → Privacy & Security → Automation**.

---

## The "Code Setup" example

Stored as a `workflow` action with three steps:

1. `launchApp` → `/Applications/Visual Studio Code.app`
2. `shellCommand` → writes the template into `~/Scratch/scratch.swift` (the template is passed via an `env:` option, so no quoting headaches)
3. `shellCommand` → `open -a "Visual Studio Code" ~/Scratch/scratch.swift`

You can inspect/edit it in the tile editor, or directly in `config.json`.

---

## Extending with new action types

The plugin seam is `ActionRegistry`:

```swift
// 1. Add a case in Models.swift
enum ActionType { ... case httpRequest }

// 2. Implement the executor
struct HTTPRequestExecutor: ActionExecutor {
    let type: ActionType = .httpRequest
    func execute(_ action: TileAction) async -> ActionResult {
        guard let url = URL(string: action.payload) else { return .failure("Bad URL") }
        do { _ = try await URLSession.shared.data(from: url); return .ok }
        catch { return .failure(error.localizedDescription) }
    }
}

// 3. Register it (ActionRegistry.registerBuiltIns or app startup)
ActionRegistry.shared.register(HTTPRequestExecutor())
```

Nothing else changes — the editor picker, search, workflows, and persistence pick it up automatically (`ActionType` drives the UI via `CaseIterable`).

---

## Notes & limitations

- **Sandbox:** shell and AppleScript execution require the sandbox to be off; this matches how Raycast/Alfred-class tools ship (Developer ID, outside the App Store).
- **File search** uses the user's Spotlight index and only activates from 3 typed characters to avoid noise.
- **⌘Space** can't be claimed while Spotlight owns it; the recorder accepts it, but macOS will keep routing it to Spotlight unless you disable that shortcut in System Settings.
- **Menu-bar-only mode:** uncomment `LSUIElement` in `Info.plist` to hide the Dock icon.

---

## License

[MIT](LICENSE) — © 2025 Veeti Nurmikoski.

Use it, fork it, ship your own version. No third-party code is vendored here:
Command Center depends only on Apple system frameworks (SwiftUI, AppKit,
Combine, Foundation, IOKit, Carbon, Network, UniformTypeIdentifiers), so there
are no upstream licenses to carry forward.

Distributed as source rather than a signed binary — it runs shell commands and
AppleScript you configure, so it is deliberately unsandboxed. Build it yourself
and you can read exactly what it does first.
