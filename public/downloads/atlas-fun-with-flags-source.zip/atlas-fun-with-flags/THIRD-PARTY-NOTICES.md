# Third-party notices

Fun With Flags redistributes assets and depends on packages that other people
wrote. This file records what they are and the notices that must be kept with
any copy of this software.

The project's own licence is [MIT](LICENSE); nothing here is relicensed by it.

---

## Redistributed in this repository

These files are committed to the repo and ship inside any copy or archive of
it, so their notices travel with it.

### Flag SVGs — `public/flags/*.svg`

237 country flags copied from [flag-icons](https://github.com/lipis/flag-icons)
(`node_modules/flag-icons/flags/4x3/`). Unmodified. Licensed **MIT**, which
requires the notice below to be included in redistribution:

```
The MIT License (MIT)

Copyright (c) 2013 Panayiotis Lipiridis

Permission is hereby granted, free of charge, to any person obtaining a copy of
this software and associated documentation files (the "Software"), to deal in
the Software without restriction, including without limitation the rights to
use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies
of the Software, and to permit persons to whom the Software is furnished to do
so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```

### Country geometry — `public/data/countries.geojson`, `public/data/countries.json`

Derived from [Natural Earth](https://www.naturalearthdata.com) 50m admin-0
countries, filtered and simplified with mapshaper (see
[`scripts/prepare-data.md`](scripts/prepare-data.md) for the exact pipeline).

Natural Earth is **public domain**. In the project's own words: "No permission
is needed to use Natural Earth. Crediting the authors is unnecessary." Credited
here anyway — the dataset is the reason this game can work offline.

> Made with Natural Earth. Free vector and raster map data @ naturalearthdata.com.

---

## Runtime dependencies

Installed from npm at build time, bundled into a production build but **not**
committed to this repository. Full texts live in each package's own directory
under `node_modules/` after `npm install`.

| Package | Licence |
| --- | --- |
| [maplibre-gl](https://github.com/maplibre/maplibre-gl-js) | BSD-3-Clause |
| [react](https://github.com/facebook/react), [react-dom](https://github.com/facebook/react) | MIT |
| [zustand](https://github.com/pmndrs/zustand) | MIT |
| [polylabel](https://github.com/mapbox/polylabel) | ISC |
| [@fontsource-variable/archivo](https://github.com/fontsource/font-files) | OFL-1.1 |
| [@fontsource/jetbrains-mono](https://github.com/fontsource/font-files) | OFL-1.1 |

**Fonts are OFL-1.1.** That permits bundling and redistribution, including
commercially, but the fonts themselves may not be sold on their own and any
modified version must not use the reserved font names.

---

## Build-time only

Not distributed — these run on your machine and never reach a user.

| Package | Licence |
| --- | --- |
| [vite](https://github.com/vitejs/vite), [@vitejs/plugin-react](https://github.com/vitejs/vite-plugin-react), [tailwindcss](https://github.com/tailwindlabs/tailwindcss), [typescript](https://github.com/microsoft/TypeScript) | MIT / Apache-2.0 |
| [mapshaper](https://github.com/mbloch/mapshaper) | MPL-2.0 |
