// Smoke test: requires `npm i -D puppeteer-core @sparticuz/chromium` and a
// running `npm run preview` on port 4173. Run: node scripts/e2e-smoke.mjs
import puppeteer from "puppeteer-core";
import chromium from "@sparticuz/chromium";
const browser = await puppeteer.launch({
  args: [...chromium.args, "--enable-unsafe-swiftshader"],
  executablePath: await chromium.executablePath(),
  headless: true, defaultViewport: { width: 1280, height: 800 },
});
const page = await browser.newPage();
const logs = [];
page.on("pageerror", (e) => logs.push(`[pageerror] ${e.message}`));
await page.goto("http://localhost:4173", { waitUntil: "networkidle0" });
await page.evaluate(() => new Promise(r => setTimeout(r, 800)));
await page.evaluate(() => { [...document.querySelectorAll("button")].find(b => b.textContent.includes("Start game"))?.click(); });
await page.evaluate(() => new Promise(r => setTimeout(r, 4000)));

const geo = await page.evaluate(() => {
  const m = window.__map;
  const r = m.getContainer().getBoundingClientRect();
  return { h: r.height, rendered: m.queryRenderedFeatures({ layers: ["countries-fill"] }).length };
});
logs.push(`[map] ${JSON.stringify(geo)}`);
await page.screenshot({ path: "/tmp/e2e-1-map.png" });

// E2E: click the round's target country, then press Space
const clickPt = await page.evaluate(() => {
  const m = window.__map;
  // read the target from the flag card image src -> iso, then project its label anchor
  const state = JSON.parse(localStorage.getItem("fwf-settings") || "{}"); // noop, target via store not exposed; use querySourceFeatures
  const img = document.querySelector('img[alt="Flag to find"]');
  const iso = img.src.match(/flags\/(\w+)\.svg/)[1].toUpperCase();
  const feats = m.querySourceFeatures("countries");
  const f = feats.find(f => f.id === iso);
  // center of feature bbox from its geometry
  const coords = JSON.stringify(f.geometry).match(/-?\d+\.?\d*,-?\d+\.?\d*/g);
  // use maplibre project on first coordinate pair of the largest ring: simpler—use label from countries.json
  return fetch("/data/countries.json").then(r => r.json()).then(cs => {
    const c = cs.find(c => c.iso_code === iso);
    const p = m.project(c.label);
    return { iso, name: c.name, x: p.x, y: p.y };
  });
});
logs.push(`[target] ${JSON.stringify(clickPt)}`);
await page.mouse.click(clickPt.x, clickPt.y);
await page.evaluate(() => new Promise(r => setTimeout(r, 500)));
const sel = await page.evaluate(() => document.body.innerText.includes("Selected:"));
logs.push(`[selected shown] ${sel}`);
await page.keyboard.press("Space");
await page.evaluate(() => new Promise(r => setTimeout(r, 800)));
const correct = await page.evaluate(() => document.body.innerText.includes("CORRECT"));
logs.push(`[correct feedback] ${correct}`);
await page.screenshot({ path: "/tmp/e2e-2-correct.png" });
await browser.close();
console.log(logs.join("\n"));
