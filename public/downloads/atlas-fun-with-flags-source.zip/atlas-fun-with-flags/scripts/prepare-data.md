# Reproducing the dataset

```bash
# 1. Source: Natural Earth 50m admin-0 countries
curl -sL -o ne50m.geojson \
  https://raw.githubusercontent.com/nvkelso/natural-earth-vector/master/geojson/ne_50m_admin_0_countries.geojson

# 2. Filter + slim with mapshaper (dev dependency)
npx mapshaper ne50m.geojson \
  -filter 'ISO_A2_EH != "-99" && ADMIN != "Antarctica"' \
  -each 'name=NAME_EN||NAME, iso2=ISO_A2_EH, iso3=ISO_A3_EH, region=CONTINENT, subregion=SUBREGION, labelX=LABEL_X, labelY=LABEL_Y, minLabel=MIN_LABEL, tiny=(TINY>0?1:0)' \
  -filter-fields name,iso2,iso3,region,subregion,labelX,labelY,minLabel,tiny \
  -o precision=0.001 format=geojson public/data/countries.geojson

# 3. Two Australian micro-territories share iso2 "AU" — drop them so iso2 is a
#    unique key, then generate public/data/countries.json and copy the matching
#    SVGs from node_modules/flag-icons/flags/4x3/ into public/flags/.
#    (See README "Data pipeline"; the metadata shape is:
#     { name, iso_code, iso3, region, subregion, flag_path, label, min_label, tiny })
```
