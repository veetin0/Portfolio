// UX smoke test: requires `npm i -D puppeteer-core @sparticuz/chromium` and
// a running `npm run preview` on port 4173. Run: node scripts/e2e-ux.mjs
import puppeteer from "puppeteer-core";
import chromium from "@sparticuz/chromium";
const browser = await puppeteer.launch({
  args: [...chromium.args, "--enable-unsafe-swiftshader"],
  executablePath: await chromium.executablePath(),
  headless: true, defaultViewport: { width: 1280, height: 800 },
});
const page = await browser.newPage();
const logs = [];
page.on("pageerror", (e) => logs.push(`[pageerror] ${e.message}`));
await page.goto("http://localhost:4173", { waitUntil: "networkidle0" });
await page.evaluate(() => new Promise(r => setTimeout(r, 800)));
await page.evaluate(() => { [...document.querySelectorAll("button")].find(b => b.textContent.includes("Start game"))?.click(); });
await page.evaluate(() => new Promise(r => setTimeout(r, 4000)));

// cursor style on canvas
const cursor = await page.evaluate(() => document.querySelector(".maplibregl-canvas")?.style.cursor);
logs.push(`[cursor] ${cursor}`);
await page.screenshot({ path: "/tmp/ux-1-world.png" });

// Hitbox test: click 8px AWAY from Malta's actual pixel, inside the ring
const malta = await page.evaluate(async () => {
  const m = window.__map;
  const cs = await fetch("/data/countries.json").then(r => r.json());
  const c = cs.find(c => c.iso_code === "MT");
  const p = m.project(c.label);
  return { x: p.x + 8, y: p.y - 6 };
});
await page.mouse.click(malta.x, malta.y);
await page.evaluate(() => new Promise(r => setTimeout(r, 400)));
const selText = await page.evaluate(() => document.querySelector(".plate")?.innerText ?? "");
logs.push(`[after off-center click on Malta ring] ${selText.split("\n")[1] ?? selText}`);

// zoom into Europe to inspect label density/collisions
await page.evaluate(() => { window.__map.jumpTo({ center: [12, 48], zoom: 3.6 }); });
await page.evaluate(() => new Promise(r => setTimeout(r, 1500)));
const labelStats = await page.evaluate(() => {
  const els = [...document.querySelectorAll(".country-label")].filter(e => e.style.display !== "none");
  return { visible: els.length, fontSize: els[0]?.style.fontSize };
});
logs.push(`[europe labels] ${JSON.stringify(labelStats)}`);
await page.screenshot({ path: "/tmp/ux-2-europe.png" });
await browser.close();
console.log(logs.join("\n"));
