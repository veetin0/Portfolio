# Fun With Flags 🌍

An offline-first geography game: a flag appears, you pan/zoom an interactive vector world map, click the country, and confirm with **Space**. Built with React + TypeScript, MapLibre GL JS, Zustand and Tailwind CSS.

## Run locally

```bash
npm install
npm run dev        # http://localhost:5173
```

Production build + preview:

```bash
npm run build
npm run preview    # serves dist/ — service worker active, works offline after first load
```

Offline: the app makes **zero network requests at runtime** beyond its own origin (GeoJSON, flags and fonts are all bundled). In production a service worker (`public/sw.js`) caches everything cache-first, so after one visit the game runs with no connection at all. When you ship an update, bump the `CACHE` version string in `sw.js`.

## Project structure

```
public/
  data/countries.geojson   # 236 countries & territories, Natural Earth 50m (name, ISO, region, subregion, label anchor)
  data/countries.json      # metadata: { name, iso_code, region, subregion, flag_path, ... }
  flags/*.svg              # one SVG flag per ISO-3166 alpha-2 code (from flag-icons)
  sw.js                    # offline cache
scripts/prepare-data.md    # how the dataset was produced (reproducible)
src/
  types.ts                 # shared domain types
  store/settings.ts        # persisted user settings + per-mode presets
  store/game.ts            # game state machine, stats, local leaderboard
  game/scoring.ts          # pure scoring functions
  map/mapStyles.ts         # map theme presets (default/clean/learning/hardcore/dark/minimal)
  data/useCountries.ts     # dataset loader
  components/
    MapView.tsx            # MapLibre map: polygons, feature-state highlights, offline vector labels, tooltip
    FlagCard.tsx           # floating target card + confirm button + live score preview
    BottomBar.tsx          # round counter, timer bar, score, quit
    SidePanel.tsx          # players, hearts, streak, eliminated countries
    SettingsPanel.tsx      # scoring / gameplay / map / general sections
    MenuScreen.tsx         # mode select, region picker, leaderboard, lifetime stats
    Results.tsx            # round result toast + game-over summary
    controls.tsx           # Toggle / Slider / Segmented primitives
```

## Gameplay

1. A flag is shown in the floating card.
2. Click a country → it highlights in your chosen color.
3. Press **Space** (or the Confirm button).
4. Correct → green reveal, points awarded. By default the camera then eases back to the world view for the next flag ("Reset view each round" in Gameplay settings) — after a miss it first flies to the correct answer, then resets. Wrong → country flashes red, gets eliminated (dim red), costs a life if hearts are on, and you keep guessing until you hit it or the timer runs out.

### Scoring

```
score = max_score − max(0, time − full_score_time) × decay_rate − wrong_guesses × penalty
```

clamped to ≥ 0. Everything is configurable: max score, full-score threshold, decay rate, wrong-guess malus (on/off + amount), or switch to fixed points per round.

### Modes

| Mode | Twist |
|---|---|
| Classic | Your settings, unchanged |
| Timed | 15 s per flag |
| Survival | 3 hearts, infinite rounds |
| Endless | No limit, no lives |
| Region | One continent only |
| Hardcore | No labels, no borders, zoom locked |

Modes are just presets (`MODE_PRESETS` in `store/settings.ts`) layered over your settings — add a new mode by adding one entry.

## Map & labels

- Countries are **vector GeoJSON polygons** rendered by MapLibre — clicks hit real geometry, not tiles.
- Hover, selection, eliminated, and reveal states use MapLibre `feature-state`, so paint updates are GPU-cheap and animate smoothly.
- **Labels are DOM markers** placed at Natural Earth label anchors — fully offline (no glyph server), zoom-scaled, auto-hidden below each country's `MIN_LABEL` zoom, and `pointer-events: none` so they never block clicks. Toggles: names on/off, always-visible (learning), region-names-only, minimal.
- Map styles: Default, Clean (borders only), Learning (labels always + thicker borders), Hardcore, Dark, Minimal. Border width, border visibility, highlight color and cursor (crosshair / pointer / arrow) are user-adjustable on top of any style.
- **Small-country hitboxes**: 67 small countries and islands (Malta, Hong Kong, the Faroes, Caribbean islands, …) get a generous invisible circle hitbox, so they are clickable at world zoom. Hovering a hitbox highlights the island polygon itself; a ring appears only for game states (selected / eliminated / revealed). Passive hint rings are an opt-in toggle in Settings → Map.
- **Label placement**: labels use Natural Earth's per-country importance zoom (big countries first, small islands only up close) plus greedy collision culling, so names never overlap.

## Data pipeline (reproducible)

See `scripts/prepare-data.md`. In short: Natural Earth 50m admin-0 countries → mapshaper (drop Antarctica & duplicate micro-territories, keep `name/iso2/iso3/region/subregion/label anchor`, 3-decimal precision) → 1.6 MB GeoJSON; flags copied from the `flag-icons` npm package. Includes territories like Greenland, Hong Kong, Puerto Rico, Faroe Islands, New Caledonia, etc.

## Extending

- **New scoring rule** → `src/game/scoring.ts` (pure functions, easy to test).
- **New map style** → add a `MapTheme` to `src/map/mapStyles.ts`.
- **New mode** → one entry in `MODE_PRESETS` + a card in `MenuScreen`.
- **Different dataset** → drop in any GeoJSON whose features carry `iso2`, `name`, `labelX/labelY`; the map promotes `iso2` to the feature id.

## License

The code in this repository is [MIT](LICENSE) — © 2025 Veeti Nurmikoski.

That covers `src/`, the build config, the scripts and the docs. It does **not**
relicense the assets that ship alongside it: the 237 flag SVGs in
`public/flags/` come from [flag-icons](https://github.com/lipis/flag-icons)
(MIT, © 2013 Panayiotis Lipiridis) and the country geometry is derived from
[Natural Earth](https://www.naturalearthdata.com) (public domain).

If you redistribute this project, keep [`THIRD-PARTY-NOTICES.md`](THIRD-PARTY-NOTICES.md)
with it — flag-icons' MIT licence requires its notice to travel with the flags.
