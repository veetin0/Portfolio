export interface Country {
  name: string;
  iso_code: string; // ISO 3166-1 alpha-2
  iso3: string;
  region: string;
  subregion: string;
  flag_path: string;
  label: [number, number]; // [lng, lat] label anchor
  min_label: number; // Natural Earth min zoom for label
  tiny: boolean;
  small: boolean; // gets an extra click hitbox on the map
}

export type GameMode =
  | "classic"
  | "timed"
  | "survival"
  | "endless"
  | "region"
  | "hardcore";

export type MapStyleId = "default" | "clean" | "learning" | "hardcore" | "dark" | "minimal";

export type ScoreMode = "time" | "fixed";

export type CursorStyle = "crosshair" | "pointer" | "default";

export interface Settings {
  // Scoring
  teams: boolean;
  teamCount: number;
  scoreMode: ScoreMode;
  maxScorePerRound: number;
  fullScoreTime: number; // seconds with full score
  decayRate: number; // points lost per second after threshold
  wrongGuessMalus: boolean;
  wrongGuessPenalty: number;

  // Gameplay
  timePerRound: number; // seconds, 0 = unlimited
  delayBeforeNext: number; // seconds
  lives: number; // 0 = unlimited
  revealDelay: number; // seconds correct answer stays highlighted
  hideWrongGuesses: boolean;
  skipResultsScreen: boolean;
  hideTargetAfterStart: boolean;
  countdownAfterFirstGuess: boolean;
  resetViewEachRound: boolean;

  // Map
  mapStyle: MapStyleId;
  showBorders: boolean;
  borderWidth: number;
  highlightColor: string;
  cursorStyle: CursorStyle;
  showIslandRings: boolean;
  showLabels: boolean;
  labelsAlways: boolean; // learning aid: ignore zoom threshold
  regionLabelsOnly: boolean;

  // General
  rounds: number;
  infinite: boolean;
  region: string | "all";
}

export interface RoundRecord {
  iso: string;
  name: string;
  correct: boolean;
  timeTaken: number;
  wrongGuesses: number;
  score: number;
}

export interface Player {
  id: number;
  name: string;
  score: number;
  lives: number;
  streak: number;
  bestStreak: number;
}

export interface LeaderboardEntry {
  name: string;
  score: number;
  mode: GameMode;
  rounds: number;
  accuracy: number;
  date: string;
}

export interface Stats {
  gamesPlayed: number;
  roundsPlayed: number;
  roundsCorrect: number;
  totalTime: number;
  bestStreak: number;
}
