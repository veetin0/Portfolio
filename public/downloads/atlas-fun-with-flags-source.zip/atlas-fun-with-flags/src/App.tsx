import { useEffect, useState } from "react";
import MapView from "./components/MapView";
import FlagCard from "./components/FlagCard";
import BottomBar from "./components/BottomBar";
import SidePanel from "./components/SidePanel";
import MenuScreen from "./components/MenuScreen";
import SettingsPanel from "./components/SettingsPanel";
import { GameOver, RoundResult } from "./components/Results";
import { useGame } from "./store/game";
import { useCountries } from "./data/useCountries";
import { effectiveSettings, useSettings } from "./store/settings";

export default function App() {
  const phase = useGame((s) => s.phase);
  const userSettings = useSettings((s) => s.settings);

  // Changing settings mid-game applies immediately; mode presets still win.
  useEffect(() => {
    const g = useGame.getState();
    if (g.phase !== "menu") {
      useGame.setState({ settings: effectiveSettings(userSettings, g.mode) });
    }
  }, [userSettings]);
  const confirmGuess = useGame((s) => s.confirmGuess);
  const quitToMenu = useGame((s) => s.quitToMenu);
  const { error } = useCountries();
  const [showSettings, setShowSettings] = useState(false);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.code === "Space" && useGame.getState().phase === "playing") {
        e.preventDefault();
        confirmGuess();
      }
      if (e.code === "Escape") {
        if (showSettings) setShowSettings(false);
        else if (useGame.getState().phase !== "menu") quitToMenu();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [confirmGuess, quitToMenu, showSettings]);

  const inGame = phase !== "menu";

  return (
    <div className="relative h-screen w-screen overflow-hidden bg-[#0b111c] text-slate-200">
      {inGame && <MapView />}
      {inGame && (
        <>
          {(phase === "playing" || phase === "reveal") && <FlagCard />}
          <SidePanel />
          <BottomBar />
          <button
            onClick={() => setShowSettings(true)}
            className="absolute right-4 bottom-16 z-30 rounded-md border border-white/10 bg-[#0b111c]/80 px-3 py-1.5 font-mono text-[11px] tracking-widest text-slate-400 backdrop-blur transition-colors hover:text-white"
          >
            SETTINGS
          </button>
          {phase === "roundResult" && <RoundResult />}
          {phase === "gameOver" && <GameOver />}
        </>
      )}
      {phase === "menu" && <MenuScreen />}
      {showSettings && inGame && <SettingsPanel onClose={() => setShowSettings(false)} />}
      {error && (
        <div className="absolute inset-x-0 top-0 z-50 bg-[#e5484d] px-4 py-2 text-center text-sm text-white">
          Failed to load country data ({error}). Reload the page to retry.
        </div>
      )}
    </div>
  );
}
