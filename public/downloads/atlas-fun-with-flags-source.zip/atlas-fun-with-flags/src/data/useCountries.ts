import { useEffect, useState } from "react";
import type { Country } from "../types";
import { useGame } from "../store/game";

export function useCountries() {
  const loadCountries = useGame((s) => s.loadCountries);
  const loaded = useGame((s) => s.countries.length > 0);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (loaded) return;
    fetch("/data/countries.json")
      .then((r) => {
        if (!r.ok) throw new Error(`HTTP ${r.status}`);
        return r.json();
      })
      .then((data: Country[]) => loadCountries(data))
      .catch((e) => setError(String(e)));
  }, [loaded, loadCountries]);

  return { loaded, error };
}
