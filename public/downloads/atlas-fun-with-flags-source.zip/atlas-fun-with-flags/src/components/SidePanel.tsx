import { useGame } from "../store/game";

export default function SidePanel() {
  const players = useGame((s) => s.players);
  const currentPlayer = useGame((s) => s.currentPlayer);
  const wrongGuesses = useGame((s) => s.wrongGuesses);
  const byIso = useGame((s) => s.byIso);
  const settings = useGame((s) => s.settings);
  const history = useGame((s) => s.history);

  const correct = history.filter((h) => h.correct).length;

  return (
    <aside className="absolute right-4 top-4 z-30 w-60 space-y-3">
      <div className="panel">
        <div className="eyebrow mb-2">Players</div>
        {players.map((p, i) => (
          <div
            key={p.id}
            className={`flex items-center justify-between rounded-md px-2 py-1.5 ${
              i === currentPlayer && players.length > 1 ? "bg-white/8" : ""
            }`}
          >
            <span className="text-sm text-slate-200">{p.name}</span>
            <span className="flex items-center gap-2">
              {settings.lives > 0 && (
                <span className="font-mono text-xs text-[#e5484d]">
                  {"♥".repeat(Math.max(0, p.lives))}
                  <span className="text-white/15">{"♥".repeat(Math.max(0, settings.lives - p.lives))}</span>
                </span>
              )}
              <span className="font-mono text-sm tabular-nums text-white">{p.score}</span>
            </span>
          </div>
        ))}
        {history.length > 0 && (
          <div className="mt-2 border-t border-white/8 pt-2 font-mono text-[11px] tracking-wider text-slate-400">
            ACCURACY {Math.round((correct / history.length) * 100)}%
          </div>
        )}
      </div>

      {!settings.hideWrongGuesses && wrongGuesses.length > 0 && (
        <div className="panel">
          <div className="eyebrow mb-2">Eliminated</div>
          <div className="flex max-h-48 flex-wrap gap-1.5 overflow-y-auto">
            {wrongGuesses.map((iso) => (
              <span
                key={iso}
                className="flex items-center gap-1.5 rounded border border-[#e5484d]/30 bg-[#e5484d]/10 px-1.5 py-0.5 text-[11px] text-slate-300"
              >
                <img src={`/flags/${iso.toLowerCase()}.svg`} alt="" className="h-2.5 w-3.5 rounded-[1px]" />
                {byIso[iso]?.name ?? iso}
              </span>
            ))}
          </div>
        </div>
      )}
    </aside>
  );
}
