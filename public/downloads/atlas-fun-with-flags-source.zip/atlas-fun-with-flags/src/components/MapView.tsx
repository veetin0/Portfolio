import { useEffect, useRef, useState } from "react";
import maplibregl from "maplibre-gl";
import type { Map as MLMap, MapMouseEvent } from "maplibre-gl";
import "maplibre-gl/dist/maplibre-gl.css";
import { useGame } from "../store/game";
import { FEEDBACK, resolveTheme } from "../map/mapStyles";
import type { Country } from "../types";

const HOME = { center: [12, 25] as [number, number], zoom: 1.6 };
const SRC = "countries";
const HIT_SRC = "small-hits";
const FILL = "countries-fill";
const HIT = "small-hit";
const LINE = "countries-line";
const SEL_LINE = "countries-selected-line";

/** Continent label anchors for "region names only" mode. */
const REGION_ANCHORS: Record<string, [number, number]> = {
  Africa: [17, 6],
  Europe: [15, 52],
  Asia: [90, 45],
  "North America": [-100, 45],
  "South America": [-60, -15],
  Oceania: [140, -25],
};

function hitFeatures(): GeoJSON.FeatureCollection {
  const cs = useGame.getState().countries.filter((c) => c.small);
  return {
    type: "FeatureCollection",
    features: cs.map((c) => ({
      type: "Feature",
      properties: { iso2: c.iso_code },
      geometry: { type: "Point", coordinates: c.label },
    })),
  };
}

interface LabelRef {
  el: HTMLDivElement;
  marker: maplibregl.Marker;
  minLabel: number;
  iso: string;
}

export default function MapView() {
  const containerRef = useRef<HTMLDivElement>(null);
  const [mapError, setMapError] = useState<string | null>(null);
  const mapRef = useRef<MLMap | null>(null);
  const labelsRef = useRef<LabelRef[]>([]);
  const regionLabelsRef = useRef<LabelRef[]>([]);
  const hoverIso = useRef<string | null>(null);
  const tooltipRef = useRef<HTMLDivElement>(null);
  const readyRef = useRef(false);

  const countries = useGame((s) => s.countries);
  const settings = useGame((s) => s.settings);
  const phase = useGame((s) => s.phase);
  const selected = useGame((s) => s.selected);
  const wrongGuesses = useGame((s) => s.wrongGuesses);
  const target = useGame((s) => s.target);
  const lastRound = useGame((s) => s.lastRound);
  const round = useGame((s) => s.round);
  const selectCountry = useGame((s) => s.selectCountry);

  const theme = resolveTheme(settings);

  // ---- init once ------------------------------------------------------------
  useEffect(() => {
    if (mapRef.current || !containerRef.current) return;
    const map = new maplibregl.Map({
      container: containerRef.current,
      style: {
        version: 8,
        sources: {},
        layers: [
          { id: "bg", type: "background", paint: { "background-color": "#0d1420" } },
        ],
      },
      center: HOME.center,
      zoom: HOME.zoom,
      minZoom: 1.05,
      maxZoom: 8,
      attributionControl: false,
      dragRotate: false,
    });
    map.touchZoomRotate.disableRotation();
    map.addControl(new maplibregl.NavigationControl({ showCompass: false }), "top-left");
    mapRef.current = map;
    (window as any).__map = map; // debug handle

    map.on("error", (e) => {
      // Surface map failures instead of silently showing a blank screen.
      console.error("[map error]", e.error ?? e);
      setMapError(String((e as any).error?.message ?? "Unknown map error"));
    });

    map.on("load", () => {
      setMapError(null);
      map.addSource(SRC, {
        type: "geojson",
        data: "/data/countries.geojson",
        promoteId: "iso2",
      });
      map.addLayer({
        id: FILL,
        type: "fill",
        source: SRC,
        paint: { "fill-color": "#27303f", "fill-opacity": 1 },
      });
      map.addLayer({
        id: LINE,
        type: "line",
        source: SRC,
        paint: { "line-color": "#5b6b84", "line-width": 1 },
      });
      map.addLayer({
        id: SEL_LINE,
        type: "line",
        source: SRC,
        paint: {
          "line-color": "#ffffff",
          "line-width": [
            "case",
            ["any", ["boolean", ["feature-state", "selected"], false], ["boolean", ["feature-state", "reveal"], false]],
            2.2,
            0,
          ],
        },
      });
      // Extra hitboxes for small countries & islands: a generous invisible
      // circle with a faint ring, centered on each label anchor.
      map.addSource(HIT_SRC, { type: "geojson", promoteId: "iso2", data: hitFeatures() });
      map.addLayer({
        id: HIT,
        type: "circle",
        source: HIT_SRC,
        paint: {
          "circle-radius": ["interpolate", ["linear"], ["zoom"], 1, 9, 4, 13, 6, 20],
          "circle-color": "rgba(0,0,0,0)",
          "circle-stroke-width": [
            "case",
            ["boolean", ["feature-state", "selected"], false], 2,
            ["boolean", ["feature-state", "hover"], false], 1.5,
            1,
          ],
          "circle-stroke-color": [
            "case",
            ["boolean", ["feature-state", "reveal"], false], FEEDBACK.correct,
            ["boolean", ["feature-state", "eliminated"], false], FEEDBACK.wrong,
            ["boolean", ["feature-state", "selected"], false], "#ffffff",
            ["boolean", ["feature-state", "hover"], false], "rgba(255,255,255,0.75)",
            "rgba(255,255,255,0.28)",
          ],
          "circle-stroke-opacity": 0, // set by applyTheme from settings
          "circle-opacity": 0,
        },
      });
      readyRef.current = true;
      applyTheme();
      syncStates();
      buildLabels();
      updateLabels();
    });

    // interactions — one unified picker: small-country hitboxes beat polygons
    const pick = (point: { x: number; y: number }): string | null => {
      if (!map.getLayer(FILL)) return null;
      const layers = map.getLayer(HIT) ? [HIT, FILL] : [FILL];
      const feats = map.queryRenderedFeatures([point.x, point.y] as any, { layers });
      const hit = feats.find((f) => f.layer.id === HIT) ?? feats[0];
      return (hit?.id as string) ?? null;
    };
    const setHover = (iso: string | null) => {
      if (hoverIso.current === iso) return;
      if (hoverIso.current) {
        map.setFeatureState({ source: SRC, id: hoverIso.current }, { hover: false });
        if (map.getSource(HIT_SRC)) map.setFeatureState({ source: HIT_SRC, id: hoverIso.current }, { hover: false });
      }
      hoverIso.current = iso;
      if (iso) {
        map.setFeatureState({ source: SRC, id: iso }, { hover: true });
        if (map.getSource(HIT_SRC)) map.setFeatureState({ source: HIT_SRC, id: iso }, { hover: true });
      }
    };
    map.on("mousemove", (e: MapMouseEvent) => {
      if (!readyRef.current) return;
      const g = useGame.getState();
      const t = resolveTheme(g.settings);
      const iso = pick(e.point);
      if (tooltipRef.current) {
        const showName =
          t.labels !== "off" || g.phase === "reveal" || g.phase === "roundResult";
        if (iso && showName) {
          const c = g.byIso[iso];
          tooltipRef.current.textContent = c ? c.name : iso;
          tooltipRef.current.style.opacity = "1";
          tooltipRef.current.style.transform = `translate(${e.point.x + 14}px, ${e.point.y + 10}px)`;
        } else {
          tooltipRef.current.style.opacity = "0";
        }
      }
      if (!t.allowHover) return;
      setHover(iso);
    });
    map.getCanvas().addEventListener("mouseleave", () => {
      if (tooltipRef.current) tooltipRef.current.style.opacity = "0";
      if (readyRef.current) setHover(null);
    });
    map.on("click", (e: MapMouseEvent) => {
      if (!readyRef.current) return;
      const g = useGame.getState();
      if (g.phase !== "playing") return;
      const iso = pick(e.point);
      g.selectCountry(iso === g.selected ? null : iso);
    });
    map.on("move", () => requestAnimationFrame(updateLabels));

    return () => {
      map.remove();
      mapRef.current = null;
      readyRef.current = false;
      labelsRef.current = [];
      regionLabelsRef.current = [];
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // ---- labels ---------------------------------------------------------------
  function buildLabels() {
    const map = mapRef.current;
    if (!map || labelsRef.current.length) return;
    const cs: Country[] = useGame.getState().countries;
    labelsRef.current = cs.map((c) => {
      const el = document.createElement("div");
      el.className = "country-label";
      el.textContent = c.name;
      const marker = new maplibregl.Marker({ element: el, anchor: "center" })
        .setLngLat(c.label)
        .addTo(map);
      return { el, marker, minLabel: c.min_label, iso: c.iso_code };
    });
    regionLabelsRef.current = Object.entries(REGION_ANCHORS).map(([name, ll]) => {
      const el = document.createElement("div");
      el.className = "country-label region-label";
      el.textContent = name.toUpperCase();
      const marker = new maplibregl.Marker({ element: el, anchor: "center" })
        .setLngLat(ll as [number, number])
        .addTo(map);
      return { el, marker, minLabel: 0, iso: name };
    });
  }

  function updateLabels() {
    const map = mapRef.current;
    if (!map || !readyRef.current) return;
    const g = useGame.getState();
    const t = resolveTheme(g.settings);
    const zoom = map.getZoom();
    const bounds = map.getBounds();

    const showRegions = g.settings.regionLabelsOnly && g.settings.showLabels;
    for (const l of regionLabelsRef.current) {
      l.el.style.display = showRegions ? "block" : "none";
      l.el.style.color = t.labelColor;
    }
    // Candidates: past their zoom threshold and inside the viewport.
    // Natural Earth's MIN_LABEL staggers importance, so big countries appear
    // first and small islands only once you zoom in close.
    const size = Math.max(9, Math.min(13, 6.5 + zoom));
    const candidates: LabelRef[] = [];
    for (const l of labelsRef.current) {
      let visible = false;
      if (!showRegions && t.labels !== "off") {
        const threshold = t.labels === "always" ? Math.max(1.6, l.minLabel - 1.4) : l.minLabel;
        visible = zoom >= threshold;
      }
      if (visible && !bounds.contains(l.marker.getLngLat())) visible = false;
      if (visible) candidates.push(l);
      else l.el.style.display = "none";
    }

    // Collision culling: place important labels first, drop any that overlap.
    candidates.sort((a, b) => a.minLabel - b.minLabel);
    const placed: { x1: number; y1: number; x2: number; y2: number }[] = [];
    for (const l of candidates) {
      const p = map.project(l.marker.getLngLat());
      const w = (l.el.textContent?.length ?? 6) * size * 0.62 + 6;
      const h = size + 6;
      const r = { x1: p.x - w / 2, y1: p.y - h / 2, x2: p.x + w / 2, y2: p.y + h / 2 };
      const collides = placed.some(
        (o) => r.x1 < o.x2 && r.x2 > o.x1 && r.y1 < o.y2 && r.y2 > o.y1
      );
      if (collides) {
        l.el.style.display = "none";
        continue;
      }
      placed.push(r);
      l.el.style.display = "block";
      l.el.style.fontSize = `${size}px`;
      l.el.style.color = t.labelColor;
      l.el.style.setProperty("--halo", t.labelHalo);
    }
  }

  // ---- theme / paint --------------------------------------------------------
  function applyTheme() {
    const map = mapRef.current;
    if (!map || !readyRef.current) return;
    const g = useGame.getState();
    const t = resolveTheme(g.settings);
    map.setPaintProperty("bg", "background-color", t.ocean);

    const hideWrong = g.settings.hideWrongGuesses;
    map.setPaintProperty(FILL, "fill-color", [
      "case",
      ["boolean", ["feature-state", "reveal"], false], FEEDBACK.correct,
      ["boolean", ["feature-state", "wrongFlash"], false], FEEDBACK.wrong,
      ["boolean", ["feature-state", "eliminated"], false], hideWrong ? t.land : FEEDBACK.eliminated,
      ["boolean", ["feature-state", "selected"], false], g.settings.highlightColor,
      ["boolean", ["feature-state", "hover"], false], t.landHover,
      t.land,
    ]);
    map.setPaintProperty(LINE, "line-color", t.border);
    map.setPaintProperty(LINE, "line-width", t.borders ? t.borderWidth : 0);
    map.setPaintProperty(SEL_LINE, "line-color", "#ffffff");
    map.getCanvas().style.cursor = g.settings.cursorStyle ?? "crosshair";

    // Island hitbox rings: only earned game states get a ring (selected /
    // eliminated / revealed). Hover highlights the island polygon itself,
    // same as any other country. Passive hint rings remain opt-in.
    if (map.getLayer(HIT)) {
      const hasState = ["any",
        ["boolean", ["feature-state", "reveal"], false],
        ["boolean", ["feature-state", "eliminated"], false],
        ["boolean", ["feature-state", "selected"], false],
      ];
      map.setPaintProperty(HIT, "circle-stroke-opacity", [
        "case",
        hasState, 1,
        g.settings.showIslandRings
          ? (["interpolate", ["linear"], ["zoom"], 5, 0.6, 6.5, 0] as any)
          : 0,
      ]);
    }

    // hardcore: freeze zoom
    if (t.allowZoom) {
      map.scrollZoom.enable();
      map.doubleClickZoom.enable();
      map.touchZoomRotate.enable();
      map.touchZoomRotate.disableRotation();
      map.keyboard.enable();
    } else {
      map.scrollZoom.disable();
      map.doubleClickZoom.disable();
      map.touchZoomRotate.disable();
      map.keyboard.disable();
    }
    updateLabels();
  }

  // ---- feature-state sync ---------------------------------------------------
  const prevStates = useRef<Set<string>>(new Set());
  function syncStates() {
    const map = mapRef.current;
    if (!map || !readyRef.current || !map.getSource(SRC)) return;
    const g = useGame.getState();

    // clear previous
    const cleared = { selected: false, eliminated: false, reveal: false, wrongFlash: false };
    for (const iso of prevStates.current) {
      map.setFeatureState({ source: SRC, id: iso }, cleared);
      if (map.getSource(HIT_SRC)) map.setFeatureState({ source: HIT_SRC, id: iso }, cleared);
    }
    prevStates.current.clear();

    const mark = (iso: string, state: Record<string, boolean>) => {
      map.setFeatureState({ source: SRC, id: iso }, state);
      if (map.getSource(HIT_SRC)) map.setFeatureState({ source: HIT_SRC, id: iso }, state);
      prevStates.current.add(iso);
    };

    for (const iso of g.wrongGuesses) mark(iso, { eliminated: true });
    if (g.selected) mark(g.selected, { selected: true });
    if ((g.phase === "reveal" || g.phase === "roundResult") && g.target) {
      mark(g.target.iso_code, { reveal: true });
    }
  }

  // react to store changes
  useEffect(() => { applyTheme(); }, [settings]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => { syncStates(); }, [selected, wrongGuesses, phase, target]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => {
    if (countries.length && readyRef.current) {
      const src = mapRef.current?.getSource(HIT_SRC) as maplibregl.GeoJSONSource | undefined;
      src?.setData(hitFeatures() as any);
      if (!labelsRef.current.length) {
        buildLabels();
        updateLabels();
      }
    }
  }, [countries]); // eslint-disable-line react-hooks/exhaustive-deps

  // wrong-guess red flash on the most recent elimination
  const prevWrongCount = useRef(0);
  useEffect(() => {
    const map = mapRef.current;
    if (!map || !readyRef.current) return;
    if (wrongGuesses.length > prevWrongCount.current) {
      const iso = wrongGuesses[wrongGuesses.length - 1];
      map.setFeatureState({ source: SRC, id: iso }, { wrongFlash: true });
      window.setTimeout(() => {
        mapRef.current?.setFeatureState({ source: SRC, id: iso }, { wrongFlash: false });
      }, 650);
    }
    prevWrongCount.current = wrongGuesses.length;
  }, [wrongGuesses]);

  // return to the world view when a new round begins, so every flag starts
  // from the same vantage point (toggleable in Gameplay settings)
  const prevRound = useRef(0);
  useEffect(() => {
    const map = mapRef.current;
    if (!map || !readyRef.current) return;
    if (round > 1 && round !== prevRound.current && phase === "playing") {
      const g = useGame.getState();
      if (g.settings.resetViewEachRound ?? true) {
        map.easeTo({ ...HOME, duration: 550 });
      }
    }
    prevRound.current = round;
  }, [round, phase]);

  // on reveal after a miss, fly to the correct answer
  useEffect(() => {
    const map = mapRef.current;
    if (!map || phase !== "reveal" || !target || !lastRound) return;
    if (!lastRound.correct) {
      map.flyTo({ center: target.label, zoom: Math.max(map.getZoom(), 3), duration: 900 });
    }
  }, [phase, target, lastRound]);

  return (
    <div className="absolute inset-0">
      <div ref={containerRef} className="h-full w-full" style={{ position: "absolute", inset: 0 }} />
      {mapError && (
        <div className="absolute inset-x-0 top-0 z-40 bg-[#e5484d] px-4 py-2 text-center text-xs text-white">
          Map failed to load: {mapError}
        </div>
      )}
      <div
        ref={tooltipRef}
        className="pointer-events-none absolute left-0 top-0 z-20 rounded-md border border-white/10 bg-[#101826]/95 px-2.5 py-1 font-mono text-xs tracking-wide text-slate-200 opacity-0 shadow-lg transition-opacity duration-100"
      />
    </div>
  );
}
