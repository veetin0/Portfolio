import { useMemo, useState } from "react";
import { loadLeaderboard, loadStats, useGame } from "../store/game";
import { useSettings } from "../store/settings";
import type { GameMode } from "../types";
import SettingsPanel from "./SettingsPanel";

const MODES: { id: GameMode; name: string; desc: string }[] = [
  { id: "classic", name: "Classic", desc: "Flag shown, find it on the map. Configurable everything." },
  { id: "timed", name: "Timed", desc: "15 seconds per flag. Speed is the whole game." },
  { id: "survival", name: "Survival", desc: "Three hearts. Every miss costs one. How far can you go?" },
  { id: "endless", name: "Endless", desc: "No round limit, no lives. Pure practice." },
  { id: "region", name: "Region", desc: "Restrict the deck to one continent." },
  { id: "hardcore", name: "Hardcore", desc: "No labels. No borders. No zoom. No mercy." },
];

export default function MenuScreen() {
  const startGame = useGame((s) => s.startGame);
  const countries = useGame((s) => s.countries);
  const { settings, set } = useSettings();
  const [showSettings, setShowSettings] = useState(false);
  const [pickedMode, setPickedMode] = useState<GameMode>("classic");

  const regions = useMemo(
    () => [...new Set(countries.map((c) => c.region))].filter((r) => r !== "Seven seas (open ocean)").sort(),
    [countries]
  );
  const stats = loadStats();
  const board = loadLeaderboard();

  const start = () => {
    if (pickedMode !== "region") set("region", "all");
    startGame(pickedMode);
  };

  return (
    <div className="absolute inset-0 z-40 overflow-y-auto bg-[#0b111c]">
      <div className="mx-auto max-w-4xl px-6 py-12">
        <header className="mb-10">
          <div className="eyebrow">An offline atlas game</div>
          <h1 className="mt-1 font-display text-5xl font-bold tracking-tight text-white">
            Fun With <span className="text-[#e8b64c]">Flags</span>
          </h1>
          <p className="mt-2 max-w-lg text-sm text-slate-400">
            A flag appears. Pan, zoom, click the country it belongs to, and confirm with{" "}
            <kbd className="rounded border border-white/15 bg-white/5 px-1 font-mono text-[11px]">Space</kbd>.
            {" "}{countries.length} countries and territories, fully playable offline.
          </p>
        </header>

        <div className="grid gap-3 sm:grid-cols-3">
          {MODES.map((m) => (
            <button
              key={m.id}
              onClick={() => setPickedMode(m.id)}
              className={`rounded-lg border p-4 text-left transition-all ${
                pickedMode === m.id
                  ? "border-[#e8b64c]/70 bg-[#e8b64c]/8 shadow-[0_0_0_1px_rgba(232,182,76,0.3)]"
                  : "border-white/8 bg-white/[0.03] hover:border-white/20"
              }`}
            >
              <div className="font-display text-base font-semibold text-white">{m.name}</div>
              <div className="mt-1 text-xs leading-relaxed text-slate-400">{m.desc}</div>
            </button>
          ))}
        </div>

        {pickedMode === "region" && (
          <div className="mt-4 flex flex-wrap items-center gap-2">
            <span className="text-sm text-slate-400">Continent:</span>
            {regions.map((r) => (
              <button
                key={r}
                onClick={() => set("region", r)}
                className={`rounded-full border px-3 py-1 text-xs transition-colors ${
                  settings.region === r
                    ? "border-[#e8b64c] bg-[#e8b64c]/15 text-[#e8b64c]"
                    : "border-white/10 text-slate-300 hover:border-white/30"
                }`}
              >
                {r}
              </button>
            ))}
          </div>
        )}

        <div className="mt-8 flex items-center gap-3">
          <button
            onClick={start}
            disabled={countries.length === 0 || (pickedMode === "region" && settings.region === "all")}
            className="btn-primary px-8 py-3 text-base"
          >
            {countries.length === 0 ? "Loading map data…" : "Start game"}
          </button>
          <button onClick={() => setShowSettings(true)} className="btn-ghost px-5 py-3">
            Settings
          </button>
        </div>

        <div className="mt-12 grid gap-4 sm:grid-cols-2">
          <div className="panel">
            <div className="eyebrow mb-3">Local leaderboard</div>
            {board.length === 0 ? (
              <p className="text-sm text-slate-500">No games finished yet. Your top ten scores land here.</p>
            ) : (
              <ol className="space-y-1.5">
                {board.map((e, i) => (
                  <li key={i} className="flex items-center justify-between text-sm">
                    <span className="flex items-center gap-2 text-slate-300">
                      <span className="w-5 font-mono text-xs text-slate-500">{i + 1}.</span>
                      {e.name}
                      <span className="rounded bg-white/5 px-1.5 py-0.5 font-mono text-[10px] uppercase tracking-wider text-slate-500">
                        {e.mode}
                      </span>
                    </span>
                    <span className="font-mono tabular-nums text-white">{e.score}</span>
                  </li>
                ))}
              </ol>
            )}
          </div>
          <div className="panel">
            <div className="eyebrow mb-3">Lifetime stats</div>
            <dl className="grid grid-cols-2 gap-x-4 gap-y-2 text-sm">
              <dt className="text-slate-500">Games played</dt>
              <dd className="text-right font-mono tabular-nums text-white">{stats.gamesPlayed}</dd>
              <dt className="text-slate-500">Rounds</dt>
              <dd className="text-right font-mono tabular-nums text-white">{stats.roundsPlayed}</dd>
              <dt className="text-slate-500">Accuracy</dt>
              <dd className="text-right font-mono tabular-nums text-white">
                {stats.roundsPlayed ? Math.round((stats.roundsCorrect / stats.roundsPlayed) * 100) : 0}%
              </dd>
              <dt className="text-slate-500">Avg time / round</dt>
              <dd className="text-right font-mono tabular-nums text-white">
                {stats.roundsPlayed ? (stats.totalTime / stats.roundsPlayed).toFixed(1) : "0.0"}s
              </dd>
              <dt className="text-slate-500">Best streak</dt>
              <dd className="text-right font-mono tabular-nums text-white">{stats.bestStreak}</dd>
            </dl>
          </div>
        </div>
      </div>

      {showSettings && <SettingsPanel onClose={() => setShowSettings(false)} />}
    </div>
  );
}
