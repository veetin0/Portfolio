import { useEffect, useState } from "react";
import { useGame } from "../store/game";

export default function BottomBar() {
  const round = useGame((s) => s.round);
  const settings = useGame((s) => s.settings);
  const roundStart = useGame((s) => s.roundStart);
  const phase = useGame((s) => s.phase);
  const players = useGame((s) => s.players);
  const currentPlayer = useGame((s) => s.currentPlayer);
  const tick = useGame((s) => s.tick);
  const quitToMenu = useGame((s) => s.quitToMenu);

  const [, force] = useState(0);
  useEffect(() => {
    const id = window.setInterval(() => {
      tick();
      force((n) => n + 1);
    }, 100);
    return () => window.clearInterval(id);
  }, [tick]);

  const timed = settings.timePerRound > 0;
  const elapsed = roundStart ? (performance.now() - roundStart) / 1000 : 0;
  const left = Math.max(0, settings.timePerRound - elapsed);
  const frac = timed ? left / settings.timePerRound : 1;
  const waiting = roundStart === null && phase === "playing";
  const me = players[currentPlayer];

  return (
    <div className="absolute inset-x-0 bottom-0 z-30 flex h-14 items-center justify-between border-t border-white/8 bg-[#0b111c]/92 px-5 backdrop-blur">
      <div className="flex items-center gap-6">
        <div className="font-mono text-xs tracking-[0.18em] text-slate-400">
          ROUND{" "}
          <span className="text-base font-semibold tracking-normal text-white">
            {String(round).padStart(2, "0")}
          </span>
          {!settings.infinite && (
            <span className="text-slate-500"> / {String(settings.rounds).padStart(2, "0")}</span>
          )}
        </div>
        {me && (
          <div className="font-mono text-xs tracking-[0.18em] text-slate-400">
            SCORE <span className="text-base font-semibold tracking-normal text-white">{me.score}</span>
          </div>
        )}
        {me && me.streak > 1 && (
          <div className="font-mono text-xs tracking-widest text-[#e8b64c]">
            {me.streak}× STREAK
          </div>
        )}
      </div>

      {timed && (
        <div className="flex flex-1 items-center justify-center gap-3 px-8">
          <div className="h-1 w-full max-w-md overflow-hidden rounded-full bg-white/10">
            <div
              className="h-full rounded-full transition-[width] duration-100 ease-linear"
              style={{
                width: `${frac * 100}%`,
                background: frac < 0.25 ? "#e5484d" : frac < 0.5 ? "#e8b64c" : "#5b8def",
              }}
            />
          </div>
          <div className="w-16 text-right font-mono text-sm tabular-nums text-slate-200">
            {waiting ? "—:—" : `${Math.floor(left / 60)}:${String(Math.floor(left % 60)).padStart(2, "0")}`}
          </div>
        </div>
      )}

      <button
        onClick={quitToMenu}
        className="rounded-md border border-white/10 px-3 py-1.5 font-mono text-[11px] tracking-widest text-slate-400 transition-colors hover:border-white/25 hover:text-white"
      >
        QUIT
      </button>
    </div>
  );
}
