import { useEffect, useState } from "react";
import { useGame } from "../store/game";
import { potentialScore } from "../game/scoring";

export default function FlagCard() {
  const target = useGame((s) => s.target);
  const selected = useGame((s) => s.selected);
  const byIso = useGame((s) => s.byIso);
  const phase = useGame((s) => s.phase);
  const settings = useGame((s) => s.settings);
  const wrongGuesses = useGame((s) => s.wrongGuesses);
  const roundStart = useGame((s) => s.roundStart);
  const targetHidden = useGame((s) => s.targetHidden);
  const confirmGuess = useGame((s) => s.confirmGuess);
  const lastRound = useGame((s) => s.lastRound);

  const [preview, setPreview] = useState(settings.maxScorePerRound);
  useEffect(() => {
    const id = window.setInterval(() => {
      const elapsed = roundStart ? (performance.now() - roundStart) / 1000 : 0;
      setPreview(potentialScore(settings, elapsed, wrongGuesses.length));
    }, 250);
    return () => window.clearInterval(id);
  }, [settings, roundStart, wrongGuesses]);

  if (!target) return null;
  const revealing = phase === "reveal";
  const selName = selected ? byIso[selected]?.name : null;

  return (
    <div className="pointer-events-none absolute bottom-24 left-1/2 z-30 -translate-x-1/2">
      <div
        className={`plate pointer-events-auto flex items-center gap-5 px-5 py-4 transition-colors duration-300 ${
          revealing ? (lastRound?.correct ? "plate-correct" : "plate-wrong") : ""
        }`}
      >
        {targetHidden && !revealing ? (
          <div className="flex h-[72px] w-24 items-center justify-center rounded-sm border border-dashed border-white/20 font-mono text-2xl text-white/40">
            ?
          </div>
        ) : (
          <img
            src={target.flag_path}
            alt="Flag to find"
            className="h-[72px] w-24 rounded-sm object-cover shadow-[0_2px_12px_rgba(0,0,0,0.5)] ring-1 ring-white/15"
            draggable={false}
          />
        )}

        <div className="min-w-[190px]">
          <div className="eyebrow">Find this country</div>
          {revealing ? (
            <div className="mt-0.5 font-display text-xl font-semibold text-white">
              {target.name}
            </div>
          ) : (
            <div className="mt-0.5 font-display text-lg font-medium text-slate-200">
              {selName ? (
                <>
                  <span className="text-white/50">Selected: </span>
                  <span style={{ color: settings.highlightColor }}>{selName}</span>
                </>
              ) : (
                <span className="text-white/40">Click a country on the map</span>
              )}
            </div>
          )}
          <div className="mt-1 font-mono text-[11px] tracking-wider text-slate-400">
            {revealing ? (
              lastRound?.correct ? (
                <span className="text-[#3ecf8e]">CORRECT · +{lastRound.score} PTS</span>
              ) : (
                <span className="text-[#e5484d]">MISSED · THE ANSWER IS SHOWN</span>
              )
            ) : (
              <>WORTH <span className="text-slate-200">{preview}</span> PTS</>
            )}
          </div>
        </div>

        {!revealing && (
          <button
            onClick={confirmGuess}
            disabled={!selected}
            className="btn-primary"
            title="Confirm (Space)"
          >
            Confirm
            <span className="ml-2 rounded border border-black/25 bg-black/10 px-1.5 py-0.5 font-mono text-[10px]">
              SPACE
            </span>
          </button>
        )}
      </div>
    </div>
  );
}
