import { useSettings } from "../store/settings";
import { MAP_THEMES } from "../map/mapStyles";
import type { CursorStyle, MapStyleId } from "../types";
import { Row, Section, Segmented, Slider, Toggle } from "./controls";

const HIGHLIGHT_COLORS = ["#e8b64c", "#5b8def", "#b56bdc", "#3ecf8e", "#e5716b", "#e2e8f0"];

export default function SettingsPanel({ onClose }: { onClose: () => void }) {
  const { settings: s, set, reset } = useSettings();
  const sec = (v: number) => `${v}s`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm" onClick={onClose}>
      <div
        className="max-h-[90vh] w-full max-w-2xl overflow-y-auto rounded-xl border border-white/10 bg-[#0e1522] p-5 shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mb-4 flex items-center justify-between">
          <h2 className="font-display text-xl font-semibold text-white">Settings</h2>
          <div className="flex gap-2">
            <button onClick={reset} className="btn-ghost">Reset defaults</button>
            <button onClick={onClose} className="btn-primary">Done</button>
          </div>
        </div>

        <div className="grid gap-4 sm:grid-cols-2">
          <Section title="Scoring">
            <Row label="Play as">
              <Segmented
                options={[{ value: "single", label: "Single" }, { value: "teams", label: "Teams" }]}
                value={s.teams ? "teams" : "single"}
                onChange={(v) => set("teams", v === "teams")}
              />
            </Row>
            {s.teams && (
              <Row label="Teams">
                <Slider value={s.teamCount} min={2} max={6} onChange={(v) => set("teamCount", v)} />
              </Row>
            )}
            <Row label="Score mode">
              <Segmented
                options={[{ value: "time", label: "By time" }, { value: "fixed", label: "Fixed" }]}
                value={s.scoreMode}
                onChange={(v) => set("scoreMode", v)}
              />
            </Row>
            <Row label="Max score per round">
              <Slider value={s.maxScorePerRound} min={100} max={2000} step={50} onChange={(v) => set("maxScorePerRound", v)} />
            </Row>
            {s.scoreMode === "time" && (
              <>
                <Row label="Full score within" hint="Answer this fast for max points">
                  <Slider value={s.fullScoreTime} min={1} max={30} onChange={(v) => set("fullScoreTime", v)} format={sec} />
                </Row>
                <Row label="Decay rate" hint="Points lost per second after that">
                  <Slider value={s.decayRate} min={5} max={100} step={5} onChange={(v) => set("decayRate", v)} />
                </Row>
              </>
            )}
            <Row label="Wrong guess malus">
              <Toggle value={s.wrongGuessMalus} onChange={(v) => set("wrongGuessMalus", v)} />
            </Row>
            {s.wrongGuessMalus && (
              <Row label="Penalty per wrong guess">
                <Slider value={s.wrongGuessPenalty} min={25} max={500} step={25} onChange={(v) => set("wrongGuessPenalty", v)} />
              </Row>
            )}
          </Section>

          <Section title="Gameplay">
            <Row label="Time per round" hint="0 = unlimited">
              <Slider value={s.timePerRound} min={0} max={120} step={5} onChange={(v) => set("timePerRound", v)} format={(v) => (v === 0 ? "∞" : sec(v))} />
            </Row>
            <Row label="Delay before next round">
              <Slider value={s.delayBeforeNext} min={0} max={5} step={0.5} onChange={(v) => set("delayBeforeNext", v)} format={sec} />
            </Row>
            <Row label="Lives" hint="0 = unlimited hearts">
              <Slider value={s.lives} min={0} max={10} onChange={(v) => set("lives", v)} format={(v) => (v === 0 ? "∞" : "♥".repeat(Math.min(v, 5)) + (v > 5 ? `+${v - 5}` : ""))} />
            </Row>
            <Row label="Reveal delay" hint="How long the answer stays highlighted">
              <Slider value={s.revealDelay} min={0.5} max={6} step={0.5} onChange={(v) => set("revealDelay", v)} format={sec} />
            </Row>
            <Row label="Reset view each round" hint="Zoom back out when the next flag appears">
              <Toggle value={s.resetViewEachRound ?? true} onChange={(v) => set("resetViewEachRound", v)} />
            </Row>
            <Row label="Hide wrong guesses">
              <Toggle value={s.hideWrongGuesses} onChange={(v) => set("hideWrongGuesses", v)} />
            </Row>
            <Row label="Skip results screen">
              <Toggle value={s.skipResultsScreen} onChange={(v) => set("skipResultsScreen", v)} />
            </Row>
            <Row label="Hide target after first click">
              <Toggle value={s.hideTargetAfterStart} onChange={(v) => set("hideTargetAfterStart", v)} />
            </Row>
          </Section>

          <Section title="Map">
            <Row label="Map style">
              <select
                className="select"
                value={s.mapStyle}
                onChange={(e) => set("mapStyle", e.target.value as MapStyleId)}
              >
                {Object.values(MAP_THEMES).map((t) => (
                  <option key={t.id} value={t.id}>{t.label}</option>
                ))}
              </select>
            </Row>
            <Row label="Show borders">
              <Toggle value={s.showBorders} onChange={(v) => set("showBorders", v)} />
            </Row>
            {s.showBorders && (
              <Row label="Border thickness">
                <Slider value={s.borderWidth} min={0.5} max={3} step={0.25} onChange={(v) => set("borderWidth", v)} format={(v) => `${v}×`} />
              </Row>
            )}
            <Row label="Show country names" hint="Labels appear as you zoom in">
              <Toggle value={s.showLabels} onChange={(v) => set("showLabels", v)} />
            </Row>
            {s.showLabels && (
              <>
                <Row label="Labels always visible" hint="Learning aid, easier gameplay">
                  <Toggle value={s.labelsAlways} onChange={(v) => set("labelsAlways", v)} />
                </Row>
                <Row label="Region names only">
                  <Toggle value={s.regionLabelsOnly} onChange={(v) => set("regionLabelsOnly", v)} />
                </Row>
              </>
            )}
            <Row label="Show island hints" hint="Faint rings marking small countries">
              <Toggle value={s.showIslandRings ?? false} onChange={(v) => set("showIslandRings", v)} />
            </Row>
            <Row label="Cursor">
              <Segmented
                options={[
                  { value: "crosshair", label: "Crosshair" },
                  { value: "pointer", label: "Pointer" },
                  { value: "default", label: "Arrow" },
                ]}
                value={(s.cursorStyle ?? "crosshair") as CursorStyle}
                onChange={(v) => set("cursorStyle", v)}
              />
            </Row>
            <Row label="Highlight color">
              <div className="flex gap-1.5">
                {HIGHLIGHT_COLORS.map((c) => (
                  <button
                    key={c}
                    onClick={() => set("highlightColor", c)}
                    className={`h-6 w-6 rounded-full ring-2 ring-offset-2 ring-offset-[#0e1522] transition-transform hover:scale-110 ${
                      s.highlightColor === c ? "ring-white" : "ring-transparent"
                    }`}
                    style={{ background: c }}
                    aria-label={`Highlight color ${c}`}
                  />
                ))}
              </div>
            </Row>
          </Section>

          <Section title="General">
            <Row label="Rounds per game">
              <Slider value={s.rounds} min={3} max={50} onChange={(v) => set("rounds", v)} />
            </Row>
            <Row label="Infinite mode" hint="Play until you quit or run out of lives">
              <Toggle value={s.infinite} onChange={(v) => set("infinite", v)} />
            </Row>
            <Row label="Countdown after first guess" hint="Timer starts on your first click">
              <Toggle value={s.countdownAfterFirstGuess} onChange={(v) => set("countdownAfterFirstGuess", v)} />
            </Row>
          </Section>
        </div>
      </div>
    </div>
  );
}
