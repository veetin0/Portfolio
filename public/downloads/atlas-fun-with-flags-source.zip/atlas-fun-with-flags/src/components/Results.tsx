import { useEffect } from "react";
import { useGame } from "../store/game";

export function RoundResult() {
  const lastRound = useGame((s) => s.lastRound);
  const settings = useGame((s) => s.settings);
  const continueFromResult = useGame((s) => s.continueFromResult);

  // auto-continue after delayBeforeNext
  useEffect(() => {
    const id = window.setTimeout(
      () => continueFromResult(),
      Math.max(600, settings.delayBeforeNext * 1000)
    );
    return () => window.clearTimeout(id);
  }, [continueFromResult, settings.delayBeforeNext]);

  if (!lastRound) return null;
  return (
    <div className="pointer-events-none absolute inset-x-0 top-16 z-40 flex justify-center">
      <div className={`plate px-6 py-4 text-center ${lastRound.correct ? "plate-correct" : "plate-wrong"}`}>
        <div className="eyebrow">{lastRound.correct ? "Correct" : "Missed"}</div>
        <div className="mt-0.5 font-display text-2xl font-bold text-white">{lastRound.name}</div>
        <div className="mt-1 font-mono text-xs tracking-wider text-slate-300">
          +{lastRound.score} PTS · {lastRound.timeTaken.toFixed(1)}s
          {lastRound.wrongGuesses > 0 && ` · ${lastRound.wrongGuesses} wrong`}
        </div>
      </div>
    </div>
  );
}

export function GameOver() {
  const players = useGame((s) => s.players);
  const history = useGame((s) => s.history);
  const mode = useGame((s) => s.mode);
  const quitToMenu = useGame((s) => s.quitToMenu);
  const startGame = useGame((s) => s.startGame);

  const correct = history.filter((h) => h.correct).length;
  const avg = history.length ? history.reduce((a, h) => a + h.timeTaken, 0) / history.length : 0;
  const ranked = [...players].sort((a, b) => b.score - a.score);

  return (
    <div className="absolute inset-0 z-40 flex items-center justify-center bg-black/70 backdrop-blur-sm">
      <div className="w-full max-w-md rounded-xl border border-white/10 bg-[#0e1522] p-6 shadow-2xl">
        <div className="eyebrow">Game over</div>
        <h2 className="mt-1 font-display text-3xl font-bold text-white">
          {ranked[0].score} <span className="text-base font-normal text-slate-400">points</span>
        </h2>

        {players.length > 1 && (
          <div className="mt-3 space-y-1">
            {ranked.map((p, i) => (
              <div key={p.id} className="flex justify-between text-sm">
                <span className="text-slate-300">{i === 0 ? "🏆 " : ""}{p.name}</span>
                <span className="font-mono text-white">{p.score}</span>
              </div>
            ))}
          </div>
        )}

        <dl className="mt-4 grid grid-cols-3 gap-3 border-t border-white/8 pt-4 text-center">
          <div>
            <dt className="text-[11px] uppercase tracking-wider text-slate-500">Accuracy</dt>
            <dd className="mt-0.5 font-mono text-lg text-white">
              {history.length ? Math.round((correct / history.length) * 100) : 0}%
            </dd>
          </div>
          <div>
            <dt className="text-[11px] uppercase tracking-wider text-slate-500">Avg time</dt>
            <dd className="mt-0.5 font-mono text-lg text-white">{avg.toFixed(1)}s</dd>
          </div>
          <div>
            <dt className="text-[11px] uppercase tracking-wider text-slate-500">Best streak</dt>
            <dd className="mt-0.5 font-mono text-lg text-white">
              {Math.max(...players.map((p) => p.bestStreak))}
            </dd>
          </div>
        </dl>

        <div className="mt-4 max-h-40 space-y-1 overflow-y-auto border-t border-white/8 pt-3">
          {history.map((h, i) => (
            <div key={i} className="flex items-center justify-between text-xs">
              <span className="flex items-center gap-2 text-slate-400">
                <img src={`/flags/${h.iso.toLowerCase()}.svg`} alt="" className="h-2.5 w-3.5 rounded-[1px]" />
                {h.name}
              </span>
              <span className={h.correct ? "text-[#3ecf8e]" : "text-[#e5484d]"}>
                {h.correct ? `+${h.score}` : "✕"}
              </span>
            </div>
          ))}
        </div>

        <div className="mt-5 flex gap-2">
          <button onClick={() => startGame(mode)} className="btn-primary flex-1 py-2.5">Play again</button>
          <button onClick={quitToMenu} className="btn-ghost flex-1 py-2.5">Menu</button>
        </div>
      </div>
    </div>
  );
}
