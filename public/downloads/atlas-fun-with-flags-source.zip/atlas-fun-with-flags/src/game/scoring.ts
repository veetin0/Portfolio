import type { Settings } from "../types";

/**
 * score = max_score - (time over threshold * decay_rate) - (wrong_guesses * penalty)
 * Clamped to [0, max]. "fixed" mode ignores time entirely.
 */
export function computeScore(
  s: Settings,
  timeTakenSec: number,
  wrongGuesses: number
): number {
  let score = s.maxScorePerRound;

  if (s.scoreMode === "time") {
    const over = Math.max(0, timeTakenSec - s.fullScoreTime);
    score -= over * s.decayRate;
  }
  if (s.wrongGuessMalus) {
    score -= wrongGuesses * s.wrongGuessPenalty;
  }
  return Math.max(0, Math.round(score));
}

/** Live preview of what a correct answer would currently be worth. */
export function potentialScore(
  s: Settings,
  elapsedSec: number,
  wrongGuesses: number
): number {
  return computeScore(s, elapsedSec, wrongGuesses);
}
