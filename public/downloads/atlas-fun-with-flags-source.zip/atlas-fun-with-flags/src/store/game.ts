import { create } from "zustand";
import type {
  Country,
  GameMode,
  LeaderboardEntry,
  Player,
  RoundRecord,
  Settings,
  Stats,
} from "../types";
import { computeScore } from "../game/scoring";
import { effectiveSettings, useSettings } from "./settings";

export type Phase = "menu" | "playing" | "reveal" | "roundResult" | "gameOver";

interface GameStore {
  phase: Phase;
  mode: GameMode;
  settings: Settings; // frozen effective settings for the running game
  countries: Country[];
  pool: Country[]; // remaining targets
  byIso: Record<string, Country>;

  round: number;
  target: Country | null;
  selected: string | null;
  wrongGuesses: string[];
  roundStart: number | null; // null until countdown actually starts
  timeLeft: number;
  lastRound: RoundRecord | null;
  history: RoundRecord[];
  players: Player[];
  currentPlayer: number;
  targetHidden: boolean;

  // actions
  loadCountries: (c: Country[]) => void;
  startGame: (mode: GameMode) => void;
  selectCountry: (iso: string | null) => void;
  confirmGuess: () => void;
  tick: () => void;
  nextRound: () => void;
  continueFromResult: () => void;
  quitToMenu: () => void;
}

function shuffle<T>(arr: T[]): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

// ---- local persistence helpers ----------------------------------------------
const STATS_KEY = "fwf-stats";
const LB_KEY = "fwf-leaderboard";

export function loadStats(): Stats {
  try {
    return {
      gamesPlayed: 0,
      roundsPlayed: 0,
      roundsCorrect: 0,
      totalTime: 0,
      bestStreak: 0,
      ...JSON.parse(localStorage.getItem(STATS_KEY) || "{}"),
    };
  } catch {
    return { gamesPlayed: 0, roundsPlayed: 0, roundsCorrect: 0, totalTime: 0, bestStreak: 0 };
  }
}
function saveStats(s: Stats) {
  localStorage.setItem(STATS_KEY, JSON.stringify(s));
}
export function loadLeaderboard(): LeaderboardEntry[] {
  try {
    return JSON.parse(localStorage.getItem(LB_KEY) || "[]");
  } catch {
    return [];
  }
}
function saveLeaderboard(entries: LeaderboardEntry[]) {
  localStorage.setItem(LB_KEY, JSON.stringify(entries.slice(0, 10)));
}

// -----------------------------------------------------------------------------

export const useGame = create<GameStore>((set, get) => ({
  phase: "menu",
  mode: "classic",
  settings: useSettings.getState().settings,
  countries: [],
  pool: [],
  byIso: {},
  round: 0,
  target: null,
  selected: null,
  wrongGuesses: [],
  roundStart: null,
  timeLeft: 0,
  lastRound: null,
  history: [],
  players: [],
  currentPlayer: 0,
  targetHidden: false,

  loadCountries: (c) =>
    set({
      countries: c,
      byIso: Object.fromEntries(c.map((x) => [x.iso_code, x])),
    }),

  startGame: (mode) => {
    const base = useSettings.getState().settings;
    const s = effectiveSettings(base, mode);
    const all = get().countries;
    let pool = s.region === "all" ? all : all.filter((c) => c.region === s.region);
    if (mode !== "region") pool = s.region === "all" ? all : pool;
    pool = shuffle(pool);

    const n = s.teams ? s.teamCount : 1;
    const players: Player[] = Array.from({ length: n }, (_, i) => ({
      id: i,
      name: s.teams ? `Team ${i + 1}` : "You",
      score: 0,
      lives: s.lives,
      streak: 0,
      bestStreak: 0,
    }));

    set({
      mode,
      settings: s,
      pool,
      players,
      currentPlayer: 0,
      round: 0,
      history: [],
      lastRound: null,
      phase: "playing",
    });
    get().nextRound();
  },

  nextRound: () => {
    const { pool, settings, round } = get();
    let nextPool = pool;
    if (nextPool.length === 0) {
      // endless: reshuffle full pool
      const all = get().countries;
      nextPool = shuffle(
        settings.region === "all" ? all : all.filter((c) => c.region === settings.region)
      );
    }
    const [target, ...rest] = nextPool;
    set({
      pool: rest,
      target,
      round: round + 1,
      selected: null,
      wrongGuesses: [],
      targetHidden: false,
      roundStart: settings.countdownAfterFirstGuess ? null : performance.now(),
      timeLeft: settings.timePerRound,
      phase: "playing",
    });
  },

  selectCountry: (iso) => {
    const g = get();
    if (g.phase !== "playing") return;
    if (iso && g.wrongGuesses.includes(iso)) return; // already eliminated
    // first interaction can start the countdown & hide the target
    const patch: Partial<GameStore> = { selected: iso };
    if (iso && g.roundStart === null) patch.roundStart = performance.now();
    if (iso && g.settings.hideTargetAfterStart) patch.targetHidden = true;
    set(patch as GameStore);
  },

  confirmGuess: () => {
    const g = get();
    if (g.phase !== "playing" || !g.selected || !g.target) return;
    const elapsed = g.roundStart ? (performance.now() - g.roundStart) / 1000 : 0;

    if (g.selected === g.target.iso_code) {
      const score = computeScore(g.settings, elapsed, g.wrongGuesses.length);
      finishRound(set, get, { correct: true, elapsed, score });
    } else {
      const wrong = [...g.wrongGuesses, g.selected];
      const players = [...g.players];
      const p = players[g.currentPlayer];
      if (g.settings.lives > 0) {
        p.lives -= 1;
        if (p.lives <= 0) {
          set({ wrongGuesses: wrong, selected: null, players });
          finishRound(set, get, { correct: false, elapsed, score: 0, outOfLives: true });
          return;
        }
      }
      set({ wrongGuesses: wrong, selected: null, players });
    }
  },

  tick: () => {
    const g = get();
    if (g.phase !== "playing" || g.settings.timePerRound <= 0) return;
    if (g.roundStart === null) return; // countdown not started yet
    const elapsed = (performance.now() - g.roundStart) / 1000;
    const left = Math.max(0, g.settings.timePerRound - elapsed);
    if (left !== g.timeLeft) set({ timeLeft: left });
    if (left <= 0) {
      finishRound(set, get, { correct: false, elapsed: g.settings.timePerRound, score: 0 });
    }
  },

  continueFromResult: () => {
    const g = get();
    if (g.phase === "gameOver") return;
    const over = isGameOver(g);
    if (over) endGame(set, get);
    else g.nextRound();
  },

  quitToMenu: () => set({ phase: "menu", target: null, selected: null }),
}));

interface FinishOpts {
  correct: boolean;
  elapsed: number;
  score: number;
  outOfLives?: boolean;
}

function finishRound(
  set: (p: Partial<GameStore>) => void,
  get: () => GameStore,
  opts: FinishOpts
) {
  const g = get();
  if (!g.target) return;
  const players = [...g.players];
  const p = players[g.currentPlayer];
  p.score += opts.score;
  if (opts.correct) {
    p.streak += 1;
    p.bestStreak = Math.max(p.bestStreak, p.streak);
  } else {
    p.streak = 0;
    if (g.settings.lives > 0 && !opts.outOfLives) p.lives -= 1;
  }

  const rec: RoundRecord = {
    iso: g.target.iso_code,
    name: g.target.name,
    correct: opts.correct,
    timeTaken: opts.elapsed,
    wrongGuesses: g.wrongGuesses.length,
    score: opts.score,
  };

  set({
    players,
    lastRound: rec,
    history: [...g.history, rec],
    phase: "reveal",
    selected: null,
  });

  // stats
  const stats = loadStats();
  stats.roundsPlayed += 1;
  if (opts.correct) stats.roundsCorrect += 1;
  stats.totalTime += opts.elapsed;
  stats.bestStreak = Math.max(stats.bestStreak, p.bestStreak);
  saveStats(stats);

  const revealMs = Math.max(0.4, g.settings.revealDelay) * 1000;
  window.setTimeout(() => {
    const now = useGame.getState();
    if (now.phase !== "reveal") return;
    const over = isGameOver(now);
    if (over) {
      endGame(set, () => now);
    } else if (now.settings.skipResultsScreen) {
      // rotate player, brief delay, straight to next round
      rotatePlayer(set, now);
      window.setTimeout(
        () => useGame.getState().phase !== "menu" && useGame.getState().nextRound(),
        Math.max(0, now.settings.delayBeforeNext - now.settings.revealDelay) * 1000
      );
    } else {
      rotatePlayer(set, now);
      set({ phase: "roundResult" });
    }
  }, revealMs);
}

function rotatePlayer(set: (p: Partial<GameStore>) => void, g: GameStore) {
  if (g.players.length > 1) {
    set({ currentPlayer: (g.currentPlayer + 1) % g.players.length });
  }
}

function isGameOver(g: GameStore): boolean {
  const anyAlive = g.players.some((p) => g.settings.lives === 0 || p.lives > 0);
  if (g.settings.lives > 0 && !anyAlive) return true;
  if (!g.settings.infinite && g.round >= g.settings.rounds) return true;
  return false;
}

function endGame(set: (p: Partial<GameStore>) => void, get: () => GameStore) {
  const g = get();
  const stats = loadStats();
  stats.gamesPlayed += 1;
  saveStats(stats);

  const correct = g.history.filter((h) => h.correct).length;
  const lb = loadLeaderboard();
  for (const p of g.players) {
    lb.push({
      name: p.name,
      score: p.score,
      mode: g.mode,
      rounds: g.history.length,
      accuracy: g.history.length ? correct / g.history.length : 0,
      date: new Date().toISOString().slice(0, 10),
    });
  }
  lb.sort((a, b) => b.score - a.score);
  saveLeaderboard(lb);

  set({ phase: "gameOver" });
}
