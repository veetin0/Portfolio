import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { GameMode, Settings } from "../types";

export const DEFAULT_SETTINGS: Settings = {
  teams: false,
  teamCount: 2,
  scoreMode: "time",
  maxScorePerRound: 1000,
  fullScoreTime: 5,
  decayRate: 25,
  wrongGuessMalus: true,
  wrongGuessPenalty: 150,

  timePerRound: 60,
  delayBeforeNext: 1.5,
  lives: 0,
  revealDelay: 2,
  hideWrongGuesses: false,
  skipResultsScreen: false,
  hideTargetAfterStart: false,
  countdownAfterFirstGuess: false,
  resetViewEachRound: true,

  mapStyle: "default",
  showBorders: true,
  borderWidth: 1,
  highlightColor: "#e8b64c",
  cursorStyle: "crosshair",
  showIslandRings: false,
  showLabels: true,
  labelsAlways: false,
  regionLabelsOnly: false,

  rounds: 10,
  infinite: false,
  region: "all",
};

/** Per-mode overrides applied on top of the user's settings when a game starts. */
export const MODE_PRESETS: Record<GameMode, Partial<Settings>> = {
  classic: {},
  timed: { timePerRound: 15, scoreMode: "time" },
  survival: { lives: 3, infinite: true },
  endless: { infinite: true, lives: 0 },
  region: {}, // region picked in the menu
  hardcore: {
    mapStyle: "hardcore",
    showLabels: false,
    showBorders: false,
    timePerRound: 20,
  },
};

interface SettingsStore {
  settings: Settings;
  set: <K extends keyof Settings>(key: K, value: Settings[K]) => void;
  reset: () => void;
}

export const useSettings = create<SettingsStore>()(
  persist(
    (set) => ({
      settings: DEFAULT_SETTINGS,
      set: (key, value) =>
        set((s) => ({ settings: { ...s.settings, [key]: value } })),
      reset: () => set({ settings: DEFAULT_SETTINGS }),
    }),
    {
      name: "fwf-settings",
      version: 2,
      // new keys get defaults when loading older persisted settings
      migrate: (persisted: any) => ({
        ...persisted,
        settings: { ...DEFAULT_SETTINGS, ...(persisted?.settings ?? {}) },
      }),
    }
  )
);

/** Effective settings for a running game = user settings + mode preset. */
export function effectiveSettings(base: Settings, mode: GameMode): Settings {
  return { ...base, ...MODE_PRESETS[mode] };
}
