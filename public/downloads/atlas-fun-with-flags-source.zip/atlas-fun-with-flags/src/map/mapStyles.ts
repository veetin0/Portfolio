import type { MapStyleId, Settings } from "../types";

export interface MapTheme {
  id: MapStyleId;
  label: string;
  ocean: string;
  land: string;
  landHover: string;
  border: string;
  borderWidth: number; // multiplier base
  labelColor: string;
  labelHalo: string;
  labels: "auto" | "always" | "off";
  borders: boolean;
  allowZoom: boolean;
  allowHover: boolean;
}

export const MAP_THEMES: Record<MapStyleId, MapTheme> = {
  default: {
    id: "default",
    label: "Default",
    ocean: "#0d1420",
    land: "#27303f",
    landHover: "#39465c",
    border: "#5b6b84",
    borderWidth: 1,
    labelColor: "#c9d4e4",
    labelHalo: "rgba(13,20,32,0.9)",
    labels: "auto",
    borders: true,
    allowZoom: true,
    allowHover: true,
  },
  clean: {
    id: "clean",
    label: "Clean",
    ocean: "#0d1420",
    land: "#27303f",
    landHover: "#39465c",
    border: "#5b6b84",
    borderWidth: 1,
    labelColor: "#c9d4e4",
    labelHalo: "rgba(13,20,32,0.9)",
    labels: "off",
    borders: true,
    allowZoom: true,
    allowHover: true,
  },
  learning: {
    id: "learning",
    label: "Learning",
    ocean: "#0e1626",
    land: "#2b3547",
    landHover: "#3d4b63",
    border: "#7a8ca8",
    borderWidth: 1.6,
    labelColor: "#e6edf7",
    labelHalo: "rgba(13,20,32,0.95)",
    labels: "always",
    borders: true,
    allowZoom: true,
    allowHover: true,
  },
  hardcore: {
    id: "hardcore",
    label: "Hardcore",
    ocean: "#0a0d13",
    land: "#1c222c",
    landHover: "#1c222c",
    border: "#252d3a",
    borderWidth: 0.4,
    labelColor: "#c9d4e4",
    labelHalo: "rgba(13,20,32,0.9)",
    labels: "off",
    borders: false,
    allowZoom: false,
    allowHover: false,
  },
  dark: {
    id: "dark",
    label: "Dark",
    ocean: "#05070c",
    land: "#141a24",
    landHover: "#242e3f",
    border: "#3a4558",
    borderWidth: 0.8,
    labelColor: "#8fa1ba",
    labelHalo: "rgba(0,0,0,0.9)",
    labels: "auto",
    borders: true,
    allowZoom: true,
    allowHover: true,
  },
  minimal: {
    id: "minimal",
    label: "Minimal",
    ocean: "#10151d",
    land: "#232a36",
    landHover: "#323c4d",
    border: "#232a36",
    borderWidth: 0,
    labelColor: "#c9d4e4",
    labelHalo: "rgba(13,20,32,0.9)",
    labels: "off",
    borders: false,
    allowZoom: true,
    allowHover: true,
  },
};

export const FEEDBACK = {
  correct: "#3ecf8e",
  wrong: "#e5484d",
  eliminated: "#4a3236",
};

/** Merge a theme with the user's map overrides from settings. */
export function resolveTheme(s: Settings): MapTheme {
  const t = MAP_THEMES[s.mapStyle] ?? MAP_THEMES.default;
  return {
    ...t,
    borders: t.borders && s.showBorders,
    borderWidth: t.borderWidth * (s.borderWidth || 1),
    labels: !s.showLabels ? "off" : s.labelsAlways ? "always" : t.labels,
  };
}
